PRIME SANCTUMS P-1 + P-2 v4 — Minecraft 1.20.1

P-1:
  /function p1:start

P-2:
  /function p2:start

V4 PANOPTICON -> SISYPHUS SEQUENCE
=================================
Panopticon reaches 0 HP:
1. Panopticon is marked dead, but its model remains visible.
2. Its AnimatedJava shake death animation begins.
3. While it is STILL shaking and has NOT exploded:
     "This prison…"
     "To hold..."
     "ME?"
   is played/spoken by Sisyphus.
4. The uploaded Sp_thisprison.ogg (~4.81 s) is allowed to finish fully.
5. At death tick 101, Panopticon finally explodes.
6. Only then is the yellow Sisyphus Prime orb spawned 2.25 blocks above
   the exact Panopticon position.
7. The normal orb fall/reveal then continues into the full Sisyphus intro.

CHAT CLEANUP
============
- Removed the inherited Minos spawn monologue from P-2:
    Ahhh...
    Free at last...
    Oh Gabriel...
    Now dawns thy reckoning...
    etc.
- Removed every remaining "say" command from the P-2 Sisyphus function tree.
- Only the custom timed Sisyphus Prime chat monologue remains.

OTHER V3 FIXES REMAIN
=====================
- P-1 and P-2 are independent.
- Sisyphus uses p2:sisyphus bossbar.
- Panopticon uses p2:panopticon bossbar.
- Sisyphus orb and attacks are gold/yellow.
- Panopticon visual is an obsidian cube.
- Sisyphus voice mappings and WAR/Pandemonium music remain.
- P-2 title remains "Minecraft - Wait of the World".
