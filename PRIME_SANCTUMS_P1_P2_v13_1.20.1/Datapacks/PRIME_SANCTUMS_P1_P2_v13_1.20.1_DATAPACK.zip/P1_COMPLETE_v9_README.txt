P1 COMPLETE v9 — Minecraft 1.20.1

CINEMATIC TITLE FADE
====================
The Minos Orb reveal still displays:

Minecraft - Soul Survivor

at the TOP of the screen with no visible fake health bar.

After the typewriter finishes:
- the complete text holds for about 2.25 seconds;
- then its colors darken smoothly through 10 steps over about 1 second;
- then the bossbar is hidden completely.

Minecraft text components do not support true alpha opacity here, so the fade
is simulated by smoothly interpolating both text colors toward black.

Use:
- P1_COMPLETE_v9_1.20.1_DATAPACK.zip
- P1_COMPLETE_v3_1.20.1_RESOURCEPACK.zip

Normal start:
  /reload
  /function p1:start
