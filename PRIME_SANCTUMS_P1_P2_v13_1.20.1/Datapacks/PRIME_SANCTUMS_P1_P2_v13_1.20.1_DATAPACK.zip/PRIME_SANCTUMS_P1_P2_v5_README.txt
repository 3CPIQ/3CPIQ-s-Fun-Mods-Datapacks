PRIME SANCTUMS P-1 + P-2 v5 — Minecraft 1.20.1

P-1:
  /function p1:start

P-2:
  /function p2:start

V5 INTRO
========
- Sp_intro.ogg starts at Sisyphus boss_timer 110.
- The uploaded file lasts ~39.65 seconds.
- Intro ends around timer 903.
- At timer 905 the speech animation is explicitly stopped.
- Any remaining intro voice tail is stopped.
- Sisyphus immediately enters idle/combat-ready animation.
- NoAI/Invulnerable are removed by spawn/end.
- WAR battle music starts immediately.
- No more extra ~2.3 seconds stuck in the monologue pose.

V5 DEATH / OUTRO
================
Death chat is timed to Sp_outro.ogg:

  Ahh…
  So concludes the life and times of King Sisyphus
  A fitting end to an existence defined by futile struggle,
  Doomed from the very start…
  And I don't regret a SECOND of it!

- WAR stops when death starts.
- Intro/breakout speech is forcibly stopped if still playing.
- Death animation + outro begin together.
- Old shatter timing at tick 480 (~24s) is removed.
- New shatter timing is tick 585 (~29.25s), after the ~29.02s outro.
- At the exact shatter moment, intro/outro/breakout sounds are stopped.
- Death animation is explicitly stopped.
- Encounter cleanup/time/weather restore happens after the shatter.

All previous P-1/P-2 fixes remain.
