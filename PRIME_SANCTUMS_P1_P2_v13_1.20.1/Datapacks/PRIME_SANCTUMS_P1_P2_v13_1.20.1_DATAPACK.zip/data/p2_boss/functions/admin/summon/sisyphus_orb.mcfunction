function p2_boss:bosses/sisyphus/spawn/orb_spawn
