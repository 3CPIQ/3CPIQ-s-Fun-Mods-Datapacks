execute align xyz positioned ~.5 ~ ~.5 run function p2_boss:bosses/panopticon/spawn/spawn
