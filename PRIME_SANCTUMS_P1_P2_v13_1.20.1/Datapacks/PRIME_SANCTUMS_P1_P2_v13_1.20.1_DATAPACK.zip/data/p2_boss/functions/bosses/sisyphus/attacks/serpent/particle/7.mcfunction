#Particle
execute rotated ~90 ~0 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~10 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~20 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~30 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~40 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~50 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~60 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~70 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~80 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~90 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~100 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~110 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~120 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~130 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~140 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~150 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~160 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~170 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~180 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~190 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~200 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~210 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~220 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~230 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~240 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~250 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~260 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~270 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~280 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~290 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~300 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~310 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~320 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~330 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~340 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force

execute rotated ~90 ~350 run particle dust 1 0.933 0 1 ^ ^ ^0.8 0 0 0 0 1 force
