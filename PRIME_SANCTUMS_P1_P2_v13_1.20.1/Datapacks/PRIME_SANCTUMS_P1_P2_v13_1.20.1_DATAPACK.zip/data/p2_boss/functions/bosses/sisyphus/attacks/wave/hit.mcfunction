#Damage
execute if score $difficulty boss_id matches 1 run scoreboard players set $damage boss_id 2500

execute if score $difficulty boss_id matches 2 run scoreboard players set $damage boss_id 3750

execute if score $difficulty boss_id matches 3 run scoreboard players set $damage boss_id 5000

#For some reason this doesn't work?? vvv
#scoreboard players operation $damage boss_id = @s boss_attack

execute positioned ~-1.5 ~ ~-1.5 as @e[type=!#adr_boss:non_living,team=!humanitarian,dx=2,dy=0,dz=2] run function adr_boss:main/damage
