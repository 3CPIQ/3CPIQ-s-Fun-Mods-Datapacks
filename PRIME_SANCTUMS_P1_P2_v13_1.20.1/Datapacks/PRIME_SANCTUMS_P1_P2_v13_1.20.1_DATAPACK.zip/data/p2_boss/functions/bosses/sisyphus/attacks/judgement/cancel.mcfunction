# No terrain found below: safely cancel to DIE or Overhead
scoreboard players set $min boss_rng 1

scoreboard players set $max boss_rng 2

function adr_boss:rng/rng_load

execute if score $random boss_rng matches 1 if score @s boss_stamina matches 20.. run scoreboard players set @s boss_attack 5

execute if score $random boss_rng matches 1 unless score @s boss_stamina matches 20.. run scoreboard players set $random boss_rng 2

execute if score $random boss_rng matches 2 if score @s boss_stamina matches 10.. run scoreboard players set @s boss_attack 7

execute if score $random boss_rng matches 2 unless score @s boss_stamina matches 10.. run scoreboard players set $random boss_rng 3

execute if score $random boss_rng matches 1..2 run scoreboard players set @s boss_timer 0

execute if score $random boss_rng matches 3 run function p2_boss:bosses/sisyphus/attacks/judgement/ray2

tag @s remove dropkicked
