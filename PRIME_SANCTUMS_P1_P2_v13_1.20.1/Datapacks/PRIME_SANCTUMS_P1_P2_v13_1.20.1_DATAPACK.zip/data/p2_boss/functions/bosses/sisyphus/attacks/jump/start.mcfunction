#Start
data modify entity @s NoAI set value 1b

execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/uppercut_hit/play
