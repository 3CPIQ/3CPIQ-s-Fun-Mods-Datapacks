##Sisyphus Prime
#Just Spawned
execute if entity @s[tag=spawned] run function p2_boss:bosses/sisyphus/spawn/main

#Bossbar
execute store result score @s boss_hp run data get entity @s Health 1

function p2:sisy_damage_voice

execute store result bossbar p2:sisyphus max run attribute @s generic.max_health get

execute store result bossbar p2:sisyphus value run scoreboard players get @s boss_hp

#Choose Attack
execute on attacker unless score @s boss_id = @e[type=iron_golem,tag=adr_hitbox,tag=sisyphus,sort=nearest,distance=..4,limit=1] boss_id run tag @s add target

execute unless entity @s[tag=exhausted] if entity @e[type=!#adr_boss:non_living,tag=target] run tag @s add in_combat

execute if score @s[tag=in_combat] boss_attack matches 0 unless block ~ ~-1 ~ #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/ground_attack

execute if score @s[tag=in_combat] boss_attack matches 0 if block ~ ~-2 ~ #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/air_attack

tag @s remove in_combat

#Attacks
execute if score @s boss_attack matches 1 run function p2_boss:bosses/sisyphus/attacks/prepare_thyself/main

execute if score @s boss_attack matches 2 run function p2_boss:bosses/sisyphus/attacks/thy_end_is_now/main

execute if score @s boss_attack matches 3 run function p2_boss:bosses/sisyphus/attacks/judgement/main

execute if score @s boss_attack matches 4 run function p2_boss:bosses/sisyphus/attacks/crush/main

execute if score @s boss_attack matches 5 run function p2_boss:bosses/sisyphus/attacks/die/main

execute if score @s boss_attack matches 6 run function p2_boss:bosses/sisyphus/attacks/uppercut/main

execute if score @s boss_attack matches 7 run function p2_boss:bosses/sisyphus/attacks/overhead/main

execute if score @s boss_attack matches 8 run function p2_boss:bosses/sisyphus/attacks/serpent/main

execute if score @s boss_attack matches 9 run function p2_boss:bosses/sisyphus/attacks/jump/main

#Check movement
function adr_boss:main/move_check

#Idle & Walk
execute unless score @s[tag=!walking,tag=moving,tag=!spawned] boss_attack matches 1.. run function p2_boss:bosses/sisyphus/walk

execute unless score @s[tag=!idle,tag=!moving,tag=!spawned] boss_attack matches 1.. run function p2_boss:bosses/sisyphus/idle

#Exhaustion
execute unless score @s boss_attack matches 1.. if score @s boss_stamina matches ..0 run tag @s add exhausted

execute if entity @s[tag=exhausted,tag=!spawned] unless score @s boss_stamina = @s boss_stamina_max run function p2_boss:bosses/sisyphus/stamina

execute if score @s boss_stamina = @s boss_stamina_max run tag @s remove exhausted

#Phase 2
execute unless entity @s[tag=phase2] if score @s boss_hp <= @s boss_half_hp run function p2_boss:bosses/sisyphus/phase2


execute if entity @s[tag=phase2] run scoreboard players set @s boss_stamina 100
