#Raycast
execute positioned ~ ~-.1 ~ if block ~ ~ ~ #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/attacks/judgement/ray2

execute unless block ~ ~-.1 ~ #adr_boss:pseudo_air run tp @s ~ ~ ~
