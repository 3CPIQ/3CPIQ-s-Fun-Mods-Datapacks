#Cancel into Uppercut
execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/jab_hit/stop

execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/hook_hit/stop

execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/chop_hit/stop

scoreboard players set @s boss_timer 1

scoreboard players set @s boss_attack 6

scoreboard players set @s boss_previous_attack 6
