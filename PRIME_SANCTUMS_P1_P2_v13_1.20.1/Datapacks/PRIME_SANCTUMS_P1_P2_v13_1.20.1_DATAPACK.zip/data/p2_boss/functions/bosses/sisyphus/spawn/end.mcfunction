#Spawn
tag @s remove spawned

scoreboard players set @s boss_timer 0

data modify entity @s NoAI set value 0b

data modify entity @s Invulnerable set value 0b



setblock ~ ~ ~ air

#Bossbar
bossbar add p2:sisyphus {"text": "Sisyphus Prime","color": "white","bold": true}

bossbar set p2:sisyphus color red

bossbar set p2:sisyphus style progress

bossbar set p2:sisyphus players @a

bossbar set p2:sisyphus visible true


# Monologue is over: leave the speech pose immediately.
execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/speech/stop

# Kill any tiny leftover tail from the intro voice.
stopsound @a voice minecraft:boss.sisyphus.intro

# Enter a normal combat-ready pose immediately.
execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/idle/play

function p2:music_sisyphus_battle
