##Sisyphus Prime
execute as @e[type=villager,team=!humanitarian,distance=..20] run team join humanitarian @s

#Dead
execute if entity @s[tag=dead] run function p2_boss:bosses/sisyphus/death/ai

#Targeting
execute if score @e[type=iron_golem,tag=adr_hitbox,tag=sisyphus,sort=nearest,distance=..4,limit=1] boss_stamina matches 1.. on target run tag @s[tag=!target] add target
