#Attacks while grounded
scoreboard players set $min boss_rng 1

scoreboard players set $max boss_rng 14

function adr_boss:rng/rng_load

tag @s remove idle

execute as @e[type=item_display,tag=adr_model,tag=sisyphus,sort=nearest,limit=1] run function animated_java:sisyphus/animations/idle/stop

tag @s remove walking

execute as @e[type=item_display,tag=adr_model,tag=sisyphus,sort=nearest,limit=1] run function animated_java:sisyphus/animations/walk/stop

#Prepare thyself
execute if score $random boss_rng matches 1..3 unless score @s boss_previous_attack matches 1 if score @s boss_stamina matches 30.. run scoreboard players set @s boss_attack 1

execute if score $random boss_rng matches 1..3 unless score @s boss_stamina matches 30.. run scoreboard players set $random boss_rng 4

execute if score $random boss_rng matches 1..3 if score @s boss_previous_attack matches 1 run scoreboard players set $random boss_rng 4

#Thy end is now
execute if score $random boss_rng matches 4..6 unless score @s boss_previous_attack matches 2 if score @s boss_stamina matches 20.. run scoreboard players set @s boss_attack 2

execute if score $random boss_rng matches 4..6 unless score @s boss_stamina matches 20.. run scoreboard players set $random boss_rng 10

execute if score $random boss_rng matches 4..6 if score @s boss_previous_attack matches 2 run scoreboard players set $random boss_rng 10

#Judgement
execute if score $random boss_rng matches 7..9 unless score @s boss_previous_attack matches 3 if score @s boss_stamina matches 20.. run scoreboard players set @s boss_attack 3

execute if score $random boss_rng matches 7..9 unless score @s boss_stamina matches 20.. run scoreboard players set $random boss_rng 10

execute if score $random boss_rng matches 7..9 if score @s boss_previous_attack matches 3 run scoreboard players set $random boss_rng 10

#Uppercut
execute if score $random boss_rng matches 10..12 unless score @s boss_previous_attack matches 7 if score @s boss_stamina matches 10.. run scoreboard players set @s boss_attack 6

execute if score $random boss_rng matches 10..12 unless score @s boss_stamina matches 10.. run scoreboard players set $random boss_rng 13

execute if score $random boss_rng matches 10..12 if score @s boss_previous_attack matches 7 run scoreboard players set $random boss_rng 13

#Serpent
execute if score $random boss_rng matches 13 unless score @s boss_previous_attack matches 8 run scoreboard players set @s boss_attack 8

execute if score $random boss_rng matches 13 if score @s boss_previous_attack matches 8 run scoreboard players set $random boss_rng 14

#Jump
execute if score $random boss_rng matches 14 unless score @s boss_previous_attack matches 9 run scoreboard players set @s boss_attack 9

execute if score $random boss_rng matches 14 if score @s boss_previous_attack matches 9 run function p2_boss:bosses/sisyphus/ground_attack

scoreboard players operation @s boss_previous_attack = @s boss_attack
