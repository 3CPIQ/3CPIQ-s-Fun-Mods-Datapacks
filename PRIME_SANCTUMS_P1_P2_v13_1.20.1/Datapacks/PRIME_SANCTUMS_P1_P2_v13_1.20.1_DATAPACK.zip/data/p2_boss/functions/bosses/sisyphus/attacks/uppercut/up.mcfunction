#Go up
execute unless block ~ ~4 ~ #adr_boss:pseudo_air unless score @s boss_timer matches 40.. run scoreboard players set @s boss_timer 40

execute if block ~ ~4 ~ #adr_boss:pseudo_air if block ~ ~3 ~ #adr_boss:pseudo_air if block ~ ~2 ~ #adr_boss:pseudo_air if block ~ ~1 ~ #adr_boss:pseudo_air run tp @s ~ ~1 ~

execute positioned ^ ^ ^1 positioned ~-1.75 ~-1.5 ~-1.75 as @e[type=!#adr_boss:non_living,team=!humanitarian,dx=2.5,dy=4,dz=2.5] positioned ~1.75 ~1.5 ~1.75 rotated ~ 0 run tp @s ^ ^2 ^1

execute positioned ^ ^ ^1 positioned ~-1.75 ~-1.5 ~-1.75 as @e[type=!#adr_boss:non_living,team=!humanitarian,dx=2.5,dy=4,dz=2.5] run effect give @s levitation 1 0 true
