#Initialize
team join humanitarian @s

effect give @s invisibility infinite 0 true

effect give @s fire_resistance infinite 0 true

tag @s remove no_id

scoreboard players set @s boss_attack 0

#Attributes based on Difficulty
execute if score $difficulty boss_id matches 1 run function p2_boss:bosses/sisyphus/difficulty/vanilla

execute if score $difficulty boss_id matches 2 run function p2_boss:bosses/sisyphus/difficulty/modded

execute if score $difficulty boss_id matches 3 run function p2_boss:bosses/sisyphus/difficulty/boss

effect give @s instant_health 1 200 true

execute store result score @s boss_half_hp run attribute @s generic.max_health get

scoreboard players set $int boss_id 2

scoreboard players operation @s boss_half_hp /= $int boss_id

#Player count adjusted protection level
execute store result score $player_count boss_id if entity @a[tag=in_boss_sisyphus,tag=inside]

function adr_boss:difficulty/player_count

scoreboard players set @s p2_sisy_prev_hp 1000
scoreboard players set @s p2_sisy_damage 0
scoreboard players set @s p2_sisy_voice_cd 0
