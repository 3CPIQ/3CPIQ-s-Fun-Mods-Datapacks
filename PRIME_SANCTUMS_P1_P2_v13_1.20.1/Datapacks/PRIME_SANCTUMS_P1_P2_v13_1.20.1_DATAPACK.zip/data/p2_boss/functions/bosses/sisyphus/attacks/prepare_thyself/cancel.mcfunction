#Cancel to uppercut
execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/axe_kick_start/stop

execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/serpent_start/stop

scoreboard players set @s boss_timer 1

scoreboard players set @s boss_attack 6

scoreboard players set @s boss_previous_attack 6
