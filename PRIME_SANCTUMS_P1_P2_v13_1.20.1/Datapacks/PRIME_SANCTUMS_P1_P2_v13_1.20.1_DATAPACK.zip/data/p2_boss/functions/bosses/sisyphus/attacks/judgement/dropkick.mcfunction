# DESTROY / aerial dropkick.

# Prevent main.mcfunction from calling this twice during the same attack.
tag @s add dropkicked

# Reset successful-ground flag from previous uses.
tag @s remove destroy_grounded

# Find the actual terrain Sisyphus is about to hit.
function p2_boss:bosses/sisyphus/attacks/judgement/ground_snap

# If terrain was found, commit to DESTROY instead of cancelling.
execute if entity @s[tag=destroy_grounded] run function p2_boss:bosses/sisyphus/attacks/judgement/impact

# Only cancel if there genuinely is no terrain within 48 blocks below.
execute unless entity @s[tag=destroy_grounded] run function p2_boss:bosses/sisyphus/attacks/judgement/cancel

# Cleanup success marker. dropkicked remains until the normal attack end.
tag @s remove destroy_grounded
