#Start
execute as @a at @s run playsound minecraft:boss.sisyphus.thiswillhurt voice @s ~ ~ ~ 0.90 1 0



data modify entity @s NoAI set value 1b

execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/crush/play

scoreboard players remove @s boss_stamina 10

tag @e[type=!#adr_boss:non_living,tag=target] remove target
