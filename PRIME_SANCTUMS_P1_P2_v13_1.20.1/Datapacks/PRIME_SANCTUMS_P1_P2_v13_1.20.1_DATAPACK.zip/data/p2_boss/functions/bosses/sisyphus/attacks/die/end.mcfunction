#End
data modify entity @s NoAI set value 0b

tag @s remove slammed

execute unless block ~ ~-1 ~ #adr_boss:pseudo_air on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/land/stop

scoreboard players set @s boss_attack 0

scoreboard players set @s boss_timer 0
