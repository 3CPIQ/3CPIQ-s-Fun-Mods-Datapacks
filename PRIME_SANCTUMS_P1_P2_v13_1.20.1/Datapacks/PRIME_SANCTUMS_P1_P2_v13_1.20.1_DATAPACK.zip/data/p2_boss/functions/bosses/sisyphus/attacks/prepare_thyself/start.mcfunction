#Start
execute unless entity @s[tag=phase2] run execute as @a at @s run playsound minecraft:boss.sisyphus.youcantescape voice @s ~ ~ ~ 0.90 1 0
execute if entity @s[tag=phase2] run execute as @a at @s run playsound minecraft:boss.sisyphus.youcantescape2 voice @s ~ ~ ~ 0.90 1 0


scoreboard players set $min boss_rng 1

scoreboard players set $max boss_rng 2

function adr_boss:rng/rng_load





execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/kick_start/play

data modify entity @s NoAI set value 1b

scoreboard players remove @s boss_stamina 30

#Look at target
tp @s ~ ~ ~ facing entity @e[type=!#adr_boss:non_living,tag=target,limit=1] feet

tag @e[type=!#adr_boss:non_living,tag=target] remove target
