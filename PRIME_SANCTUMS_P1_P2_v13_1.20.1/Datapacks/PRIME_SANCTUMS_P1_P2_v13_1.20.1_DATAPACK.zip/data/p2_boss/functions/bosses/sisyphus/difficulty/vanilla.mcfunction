#Vanilla Difficulty
attribute @s generic.max_health base set 600

attribute @s generic.movement_speed base set 0.4

attribute @s generic.armor base set 10

attribute @s generic.armor_toughness base set 20

attribute @s generic.attack_damage base set 10

scoreboard players set @s boss_stamina_max 60

tag @s add diff_1
