#Blast size based on difficulty
execute as @e[type=!#adr_boss:non_living,team=!humanitarian,distance=..15] run function adr_boss:main/damage

particle flame ^ ^ ^ 5 5 5 0.1 10000 normal

particle flash ^ ^ ^ 5 5 5 0 100 normal

particle block yellow_stained_glass ~ ~ ~ 5 5 5 1 600 normal

particle explosion ^ ^ ^ 5 5 5 0 100 normal

particle block stone ~ ~ ~ 0.8 1.0 0.8 0 300 normal

particle block stone ~ ~ ~ 0.8 1.0 0.8 1 300 normal
