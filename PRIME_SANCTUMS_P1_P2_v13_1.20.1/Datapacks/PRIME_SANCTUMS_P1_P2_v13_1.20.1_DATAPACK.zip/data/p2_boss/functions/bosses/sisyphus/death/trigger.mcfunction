#Death
scoreboard players operation $temp boss_id = @s boss_id

execute as @e[type=vindicator,tag=adr_ai,tag=sisyphus,distance=..10] if score @s boss_id = $temp boss_id run tag @s add dead

tag @s add dead

tag @e[type=marker,tag=p1_trigger,distance=..100,sort=nearest,limit=1] add death

execute unless entity @e[type=iron_golem,tag=adr_hitbox,tag=sisyphus] run bossbar remove p2:sisyphus

scoreboard players set @s boss_timer 0
