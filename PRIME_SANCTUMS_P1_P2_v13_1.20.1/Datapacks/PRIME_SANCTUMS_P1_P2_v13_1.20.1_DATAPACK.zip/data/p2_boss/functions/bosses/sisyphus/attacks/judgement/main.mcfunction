#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1 run function p2_boss:bosses/sisyphus/attacks/judgement/start

#Make start up and recovery faster on boss difficulty
scoreboard players add @s[tag=diff_3] boss_timer 1

#Make start up faster on phase 2
execute unless score @s[tag=phase2] boss_timer matches 40.. run scoreboard players add @s boss_timer 1

#Dropkick
execute if score @s boss_timer matches 30 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/drop_kick_start/stop

execute if score @s boss_timer matches 30 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/drop_kick_mid/play

execute if score @s boss_timer matches 30 anchored feet run function p2_boss:bosses/sisyphus/attacks/judgement/ray

execute if score @s boss_timer matches 36 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/drop_kick_mid/stop

execute if score @s boss_timer matches 36 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/drop_kick_hit/play

execute if score @s[tag=!dropkicked] boss_timer matches 38..39 run function p2_boss:bosses/sisyphus/attacks/judgement/dropkick

execute if score @s boss_timer matches 42 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/drop_kick_end/play

#Make recover faster on modded difficulty
execute if score @s[tag=diff_2] boss_timer matches 42.. run scoreboard players add @s boss_timer 1

#Make recover faster on phase 2
execute if score @s[tag=phase2] boss_timer matches 42.. run scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 80.. run function p2_boss:bosses/sisyphus/attacks/judgement/end
