#Walk
tag @s add idle

tag @s remove walking

execute as @e[type=item_display,tag=adr_model,tag=sisyphus,sort=nearest,limit=1] run function animated_java:sisyphus/animations/idle/play

execute as @e[type=item_display,tag=adr_model,tag=sisyphus,sort=nearest,limit=1] run function animated_java:sisyphus/animations/walk/stop
