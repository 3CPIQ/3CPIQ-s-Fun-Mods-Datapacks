#Damage based on difficulty
scoreboard players operation $damage boss_id = @s boss_attack

particle dust 1 0.933 0 1 ^ ^ ^ 2 2 2 0 500 force

particle flash ~ ~ ~ 1 1 1 0 1 force

particle block yellow_stained_glass ~ ~1 ~ 1 1 1 1 200 normal

playsound minecraft:block.respawn_anchor.deplete hostile @a ~ ~ ~ 10 0 0

execute positioned ~-2.5 ~-2.5 ~-2.5 as @e[type=!#adr_boss:non_living,dx=4,dy=4,dz=4,team=!humanitarian] run function adr_boss:main/damage

kill @s

# P1 COMPLETE DESTRUCTIVE PATCH
function p2:destruction/r3

# P-2 phase-2 impact lightning
execute if entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,tag=phase2,limit=1] if predicate adr_boss:rng/50 run function p2:sisy_phase2_lightning_impact
