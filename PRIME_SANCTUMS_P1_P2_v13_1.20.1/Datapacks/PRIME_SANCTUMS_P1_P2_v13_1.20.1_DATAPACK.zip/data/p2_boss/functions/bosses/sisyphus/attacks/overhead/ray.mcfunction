#Raycast
execute positioned ~ ~-.5 ~ if block ~ ~ ~ #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/attacks/overhead/ray

execute unless block ~ ~-.5 ~ #adr_boss:pseudo_air run tp @s ~ ~ ~

execute anchored feet unless block ~ ~-1 ~ #adr_boss:pseudo_air run particle block stone ~ ~ ~ 0.4 0.6 0.4 2 100 normal

particle cloud ~ ~ ~ 0.3 0.3 0.3 0.1 1 normal
