#Spawn wave
execute rotated ~90 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 10 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 20 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 30 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 40 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 50 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 60 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 70 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 80 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 90 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 100 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 110 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 120 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 130 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 140 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 150 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 160 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 170 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 180 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 190 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 200 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 210 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 220 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 230 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 240 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 250 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 260 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 270 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 280 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 290 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 300 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 310 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 320 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 330 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 340 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated ~90 350 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute as @e[type=marker,tag=p2_boss_wave,distance=..4] positioned as @s run tp @s ~ ~ ~ facing entity @e[type=iron_golem,tag=adr_hitbox,tag=sisyphus,sort=nearest,distance=..4,limit=1]

execute store result score @e[type=marker,tag=p2_boss_wave,distance=..4] boss_attack run attribute @s generic.attack_damage get 250
