#Start
execute unless entity @s[tag=phase2] run execute as @a at @s run playsound minecraft:boss.sisyphus.nicetry voice @s ~ ~ ~ 0.86 1 0
execute if entity @s[tag=phase2] run execute as @a at @s run playsound minecraft:boss.sisyphus.nicetry2 voice @s ~ ~ ~ 0.86 1 0

data modify entity @s NoAI set value 1b

execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/serpent_start/play

#Look at target
execute anchored eyes run tp @s ~ ~ ~ facing entity @e[type=!#adr_boss:non_living,tag=target,limit=1] feet

tag @e[type=!#adr_boss:non_living,tag=target] remove target
