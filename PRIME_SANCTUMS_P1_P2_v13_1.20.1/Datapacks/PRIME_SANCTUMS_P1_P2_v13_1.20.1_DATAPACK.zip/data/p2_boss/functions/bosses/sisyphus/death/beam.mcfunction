#Beam
execute positioned ^ ^ ^.5 if block ~ ~ ~ #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/death/beam

particle instant_effect ~ ~ ~ 0.2 0.2 0.2 0 1 force
