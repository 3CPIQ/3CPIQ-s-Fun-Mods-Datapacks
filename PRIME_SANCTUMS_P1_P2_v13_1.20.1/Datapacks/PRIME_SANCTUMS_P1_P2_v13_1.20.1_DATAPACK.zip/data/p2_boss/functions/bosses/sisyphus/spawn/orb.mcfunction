#Orb
execute if block ~ ~-.05 ~ #adr_boss:pseudo_air run tp @s ~ ~-.05 ~

execute unless block ~ ~-.05 ~ #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/spawn/spawn

#Particle
particle dust 1.000 0.780 0.120 1 ~ ~ ~ 0.3 0.3 0.3 0 50 force

particle flash ~ ~ ~ 0 0 0 0 1 force
