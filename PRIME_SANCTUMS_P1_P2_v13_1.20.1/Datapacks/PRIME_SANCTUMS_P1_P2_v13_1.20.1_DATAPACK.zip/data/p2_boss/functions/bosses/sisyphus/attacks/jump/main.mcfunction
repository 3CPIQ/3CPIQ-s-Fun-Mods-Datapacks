#Jump
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1 run function p2_boss:bosses/sisyphus/attacks/jump/start

execute if score @s boss_timer matches 1..20 if block ~ ~4 ~ #adr_boss:pseudo_air if block ~ ~3 ~ #adr_boss:pseudo_air if block ~ ~2 ~ #adr_boss:pseudo_air if block ~ ~1 ~ #adr_boss:pseudo_air run tp @s ~ ~1 ~

execute if score @s boss_timer matches 20.. run function p2_boss:bosses/sisyphus/attacks/jump/end
