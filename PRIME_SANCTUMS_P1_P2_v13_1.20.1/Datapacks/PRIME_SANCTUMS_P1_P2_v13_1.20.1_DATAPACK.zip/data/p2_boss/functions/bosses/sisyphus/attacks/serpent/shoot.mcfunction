#Shoot serpent projectile
summon marker ^ ^ ^ {Tags: ["p2_boss_serpent", "sisyphus", "init"]}

execute as @e[type=marker,tag=p2_boss_serpent,tag=init,distance=..4,sort=nearest,limit=1] at @s rotated as @e[type=iron_golem,tag=adr_hitbox,tag=sisyphus,sort=nearest,limit=1] run tp @s ~ ~ ~ ~ 0

execute store result score @e[type=marker,tag=p2_boss_serpent,tag=init,distance=..4,sort=nearest,limit=1] boss_attack run attribute @s generic.attack_damage get 250

tag @e[type=marker,tag=p2_boss_serpent,tag=init,distance=..4,sort=nearest,limit=1] remove init

particle flash ~ ~1 ~ 0 0 0 1 1 force

playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 10 0.7 0
