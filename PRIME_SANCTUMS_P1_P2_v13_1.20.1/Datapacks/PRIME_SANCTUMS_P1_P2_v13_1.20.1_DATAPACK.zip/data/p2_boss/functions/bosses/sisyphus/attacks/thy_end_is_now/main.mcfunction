#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1 run function p2_boss:bosses/sisyphus/attacks/thy_end_is_now/start

#Cancel to upper cut if target is in air
execute if score @s boss_timer matches 23..29 run function p2_boss:bosses/sisyphus/attacks/thy_end_is_now/cancel_check

execute if score @s boss_timer matches 43..49 run function p2_boss:bosses/sisyphus/attacks/thy_end_is_now/cancel_check

execute if score @s boss_timer matches 63..69 run function p2_boss:bosses/sisyphus/attacks/thy_end_is_now/cancel_check

#Make start up and recovery faster on boss difficulty
scoreboard players add @s[tag=diff_3] boss_timer 1

#Make start up faster on phase 2
execute if score @s[tag=phase2] boss_timer matches 11..15 run scoreboard players add @s boss_timer 1

execute if score @s[tag=phase2] boss_timer matches 31..35 run scoreboard players add @s boss_timer 1

execute if score @s[tag=phase2] boss_timer matches 51..55 run scoreboard players add @s boss_timer 1

execute if score @s[tag=phase2] boss_timer matches 71..75 run scoreboard players add @s boss_timer 1

#Jab
execute if score @s boss_timer matches 10 run function p2_boss:bosses/sisyphus/attacks/dash/main

execute if score @s boss_timer matches 10 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/jab_start/play

execute if score @s boss_timer matches 18 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/jab_hit/play

execute if score @s boss_timer matches 18 run playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 10 0.7 0

execute if score @s boss_timer matches 17..22 rotated ~ 0 run function p2_boss:bosses/sisyphus/attacks/thy_end_is_now/jab

execute if score @s boss_timer matches 17..22 rotated ~ 0 if block ^ ^ ^1 #adr_boss:pseudo_air run tp @s ^ ^ ^1

execute if score @s[tag=diff_3] boss_timer matches 17..22 rotated ~ 0 if block ^ ^ ^1 #adr_boss:pseudo_air run tp @s ^ ^ ^1

#Particles
execute if score @s boss_timer matches 17..22 anchored eyes rotated ~ 0 run particle dust 1.000 0.780 0.120 2 ^.5 ^ ^3 0.2 0.2 0.2 0 10 force

#Hook
execute if score @s boss_timer matches 30 at @s run function p2_boss:bosses/sisyphus/attacks/dash/main

execute if score @s boss_timer matches 30 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/hook_start/play

execute if score @s boss_timer matches 38 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/hook_hit/play

execute if score @s boss_timer matches 38 run playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 10 0.7 0

execute if score @s boss_timer matches 40..42 rotated ~ 0 run function p2_boss:bosses/sisyphus/attacks/thy_end_is_now/hook

execute if score @s boss_timer matches 31..36 rotated ~ 0 if block ^-.25 ^ ^.25 #adr_boss:pseudo_air run tp @s ^-.25 ^ ^.25

execute if score @s[tag=diff_3] boss_timer matches 31..36 rotated ~ 0 if block ^-.25 ^ ^.25 #adr_boss:pseudo_air run tp @s ^-.25 ^ ^.25

#Particles
execute if score @s boss_timer matches 37 anchored eyes rotated ~75 75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 38 anchored eyes rotated ~60 60 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 38 anchored eyes rotated ~45 45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 39 anchored eyes rotated ~30 30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 39 anchored eyes rotated ~15 15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 40 anchored eyes rotated ~ 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 40 anchored eyes rotated ~-15 -15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 41 anchored eyes rotated ~-30 -30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 41 anchored eyes rotated ~-45 -45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 42 anchored eyes rotated ~-60 -60 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 42 anchored eyes rotated ~-75 -75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 38 anchored eyes rotated ~75 75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 40 anchored eyes rotated ~30 30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 40 anchored eyes rotated ~15 15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 42 anchored eyes rotated ~-30 -30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 42 anchored eyes rotated ~-45 -45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

#Chop
execute if score @s boss_timer matches 50 run function p2_boss:bosses/sisyphus/attacks/dash/main

execute if score @s boss_timer matches 50 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/chop_start/play

execute if score @s boss_timer matches 58 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/chop_hit/play

execute if score @s boss_timer matches 58 run playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 10 0.7 0

execute if score @s boss_timer matches 60..62 rotated ~ 0 run function p2_boss:bosses/sisyphus/attacks/thy_end_is_now/chop

execute if score @s boss_timer matches 51..56 rotated ~ 0 if block ^.25 ^ ^.25 #adr_boss:pseudo_air run tp @s ^.25 ^ ^.25

execute if score @s[tag=diff_3] boss_timer matches 51..56 rotated ~ 0 if block ^.25 ^ ^.25 #adr_boss:pseudo_air run tp @s ^.25 ^ ^.25

#Particles
execute if score @s boss_timer matches 57 anchored eyes rotated ~-75 -75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 58 anchored eyes rotated ~-60 -60 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 58 anchored eyes rotated ~-45 -45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 59 anchored eyes rotated ~-30 -30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 59 anchored eyes rotated ~-15 -15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 60 anchored eyes rotated ~ 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 60 anchored eyes rotated ~15 15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 61 anchored eyes rotated ~30 30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 61 anchored eyes rotated ~45 45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 62 anchored eyes rotated ~60 60 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 62 anchored eyes rotated ~75 75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 58 anchored eyes rotated ~-75 -75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 60 anchored eyes rotated ~-30 -30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 60 anchored eyes rotated ~-15 -15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 62 anchored eyes rotated ~30 30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 62 anchored eyes rotated ~45 45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

#Final
execute if score @s boss_timer matches 70 run function p2_boss:bosses/sisyphus/attacks/dash/main

execute if score @s boss_timer matches 70 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/final_start/play

execute if score @s boss_timer matches 78 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/final_hit/play

execute if score @s boss_timer matches 78 run playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 10 0.7 0

execute if score @s boss_timer matches 80..82 rotated ~ 0 run function p2_boss:bosses/sisyphus/attacks/thy_end_is_now/final

execute if score @s boss_timer matches 80..82 rotated ~ 0 if block ^ ^ ^.5 #adr_boss:pseudo_air run tp @s ^ ^ ^.5

execute if score @s[tag=diff_3] boss_timer matches 80..82 rotated ~ 0 if block ^ ^ ^.5 #adr_boss:pseudo_air run tp @s ^ ^ ^.5

#Particles
execute if score @s boss_timer matches 77 anchored eyes rotated ~ -75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 78 anchored eyes rotated ~ -60 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 78 anchored eyes rotated ~ -45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 79 anchored eyes rotated ~ -30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 79 anchored eyes rotated ~ -15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 80 anchored eyes rotated ~ 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 80 anchored eyes rotated ~ 15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 81 anchored eyes rotated ~ 30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 81 anchored eyes rotated ~ 45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 82 anchored eyes rotated ~ 60 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 82 anchored eyes rotated ~ 75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 78 anchored eyes rotated ~ -75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 80 anchored eyes rotated ~ -30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 80 anchored eyes rotated ~ -15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 82 anchored eyes rotated ~ 30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 82 anchored eyes rotated ~ 45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 94 rotated ~ 0 run particle block stone ^ ^ ^2 0.4 0.6 0.4 2 100 normal

execute if score @s boss_timer matches 94 rotated ~ 0 positioned ~ ~2 ~ run particle dust 1.000 0.780 0.120 1 ^ ^ ^2 0.4 2 0.4 0 50 normal

execute if score @s boss_timer matches 94 rotated ~ 0 positioned ~ ~2 ~ run particle dust 1.000 0.780 0.120 1 ^ ^ ^2 0.4 2 0.4 0 50 normal

execute if score @s boss_timer matches 94 run playsound entity.generic.explode hostile @a ~ ~ ~ 10 1 0


#Make recovery faster on modded difficulty
execute if score @s[tag=diff_2] boss_timer matches 82.. run scoreboard players add @s boss_timer 1

#Make recover faster on phase 2
execute if score @s[tag=phase2] boss_timer matches 82.. run scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 100.. run function p2_boss:bosses/sisyphus/attacks/thy_end_is_now/end
