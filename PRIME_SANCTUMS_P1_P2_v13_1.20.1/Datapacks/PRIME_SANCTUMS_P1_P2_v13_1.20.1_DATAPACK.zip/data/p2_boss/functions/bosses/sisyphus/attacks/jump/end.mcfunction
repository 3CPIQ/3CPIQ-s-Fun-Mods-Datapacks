#End
data modify entity @s NoAI set value 0b

scoreboard players set @s boss_attack 0

scoreboard players set @s boss_timer 0
