#Boss Difficulty
attribute @s generic.max_health base set 1000

attribute @s generic.movement_speed base set 0.6

attribute @s generic.armor base set 40

attribute @s generic.armor_toughness base set 60

attribute @s generic.attack_damage base set 20

scoreboard players set @s boss_stamina_max 180

tag @s add diff_3
