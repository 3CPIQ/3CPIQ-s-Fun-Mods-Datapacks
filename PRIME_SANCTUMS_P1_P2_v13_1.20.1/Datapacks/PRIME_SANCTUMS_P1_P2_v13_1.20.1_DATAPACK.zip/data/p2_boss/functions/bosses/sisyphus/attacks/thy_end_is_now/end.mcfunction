#End
data modify entity @s NoAI set value 0b

execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/final_hit/stop

scoreboard players set @s boss_attack 0

tag @s remove attacking

scoreboard players set @s boss_timer 0
