#Damage hit
execute store result score $damage boss_id run attribute @s generic.attack_damage get 300

execute positioned ^ ^ ^1 positioned ~-1.75 ~-1.5 ~-1.75 as @e[type=!#adr_boss:non_living,team=!humanitarian,dx=2.5,dy=4,dz=2.5] run function adr_boss:main/damage

# P1 COMPLETE DESTRUCTIVE PATCH
execute positioned ^ ^ ^1 run function p2:destruction/r3

# P-2 phase-2 impact lightning
execute positioned ^ ^ ^1 run if entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,tag=phase2,limit=1] if predicate adr_boss:rng/50 run function p2:sisy_phase2_lightning_impact
