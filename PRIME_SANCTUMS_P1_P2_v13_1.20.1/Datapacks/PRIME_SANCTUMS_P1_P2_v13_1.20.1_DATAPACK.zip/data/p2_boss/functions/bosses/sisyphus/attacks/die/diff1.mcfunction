#Blast size based on difficulty
execute as @e[type=!#adr_boss:non_living,team=!humanitarian,distance=..2] run function adr_boss:main/damage

particle flash ^ ^ ^ 1 1 1 0 10 normal

particle explosion ^ ^ ^ 1 1 1 0 10 normal

particle block stone ~ ~ ~ 0.4 0.6 0.4 0 100 normal

particle block stone ~ ~ ~ 0.4 0.6 0.4 1 100 normal
