#Damage hit
execute store result score $damage boss_id run attribute @s generic.attack_damage get 300

execute positioned ^ ^ ^1 positioned ~-1.75 ~-3 ~-1.75 as @e[type=!#adr_boss:non_living,team=!humanitarian,dx=2.5,dy=5,dz=2.5] run function adr_boss:main/damage

execute positioned ^ ^ ^1 positioned ~-1.75 ~-3 ~-1.75 as @e[type=!#adr_boss:non_living,team=!humanitarian,dx=2.5,dy=5,dz=2.5] at @s run function p2_boss:bosses/sisyphus/attacks/overhead/ray

# P1 COMPLETE DESTRUCTIVE PATCH
execute positioned ^ ^ ^1.5 positioned ~ ~-1 ~ run function p2:destruction/r4

# P-2 phase-2 impact lightning
execute positioned ^ ^ ^1.5 positioned ~ ~-1 ~ run if entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,tag=phase2,limit=1] if predicate adr_boss:rng/50 run function p2:sisy_phase2_lightning_impact
