# DESTROY actual ground impact.

# Damage blast.
execute store result score $damage boss_id run attribute @s generic.attack_damage get 500

execute positioned ^ ^ ^1 if entity @s[tag=diff_1] run function p2_boss:bosses/sisyphus/attacks/judgement/diff1
execute positioned ^ ^ ^1 if entity @s[tag=diff_2] run function p2_boss:bosses/sisyphus/attacks/judgement/diff2
execute positioned ^ ^ ^1 if entity @s[tag=diff_3] run function p2_boss:bosses/sisyphus/attacks/judgement/diff3

playsound entity.generic.explode master @a ~ ~ ~ 10 0.75 0
playsound entity.generic.explode master @a ~ ~ ~ 10 0.5 0

# Massive terrain crater happens at the REAL landing point.
execute positioned ^ ^ ^1 if entity @s[tag=diff_1] run function p2:destruction/minos_blast_r4
execute positioned ^ ^ ^1 if entity @s[tag=diff_2] run function p2:destruction/minos_blast_r6
execute positioned ^ ^ ^1 if entity @s[tag=diff_3] run function p2:destruction/minos_blast_r8

# Phase-2 lightning also happens at the REAL impact/crater point.
execute positioned ^ ^ ^1 if entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,tag=phase2,limit=1] if predicate adr_boss:rng/50 run function p2:sisy_phase2_lightning_impact
