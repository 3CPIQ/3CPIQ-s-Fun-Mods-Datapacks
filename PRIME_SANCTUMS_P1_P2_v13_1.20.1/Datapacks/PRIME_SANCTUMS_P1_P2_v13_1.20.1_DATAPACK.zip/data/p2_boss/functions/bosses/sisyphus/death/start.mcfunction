# Sisyphus Prime death/outro begins.

# Battle music cuts out for the death speech.
function p2:music_stop

# Never allow the intro/breakout speech to overlap the death monologue.
stopsound @a voice minecraft:boss.sisyphus.intro
stopsound @a voice minecraft:boss.sisyphus.thisprison
stopsound @a voice minecraft:boss.sisyphus.outro

# End every combat animation and enter the dedicated death animation.
function animated_java:sisyphus/animations/pause_all
function animated_java:sisyphus/animations/death/play

# Full uploaded Sisyphus death speech (~29.02 s).
execute as @a at @s run playsound minecraft:boss.sisyphus.outro voice @s ~ ~ ~ 0.88 1 0
