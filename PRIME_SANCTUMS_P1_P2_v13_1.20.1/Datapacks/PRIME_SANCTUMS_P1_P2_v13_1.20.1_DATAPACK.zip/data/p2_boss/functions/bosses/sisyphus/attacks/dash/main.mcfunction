#Look at target
execute as @e[type=vindicator,tag=adr_ai,tag=sisyphus,distance=..4,sort=nearest,limit=1] if score @s boss_id = @e[type=iron_golem,tag=adr_hitbox,tag=sisyphus,distance=..4,sort=nearest,limit=1] boss_id on target run tag @s add target

execute unless entity @e[type=!#adr_boss:non_living,tag=target] on attacker unless score @s boss_id = @e[type=iron_golem,tag=adr_hitbox,tag=sisyphus,sort=nearest,distance=..4,limit=1] boss_id run tag @s add target

execute anchored feet run tp @s ~ ~ ~ facing entity @e[type=!#adr_boss:non_living,tag=target,limit=1] feet

execute unless block ~ ~-1 ~ #adr_boss:pseudo_air run particle block stone ~ ~ ~ 0.3 0.3 0.3 2 100 normal

execute anchored feet facing entity @e[type=!#adr_boss:non_living,tag=target,limit=1] feet run function p2_boss:bosses/sisyphus/attacks/dash/ray

tag @e[type=!#adr_boss:non_living,tag=target] remove target
