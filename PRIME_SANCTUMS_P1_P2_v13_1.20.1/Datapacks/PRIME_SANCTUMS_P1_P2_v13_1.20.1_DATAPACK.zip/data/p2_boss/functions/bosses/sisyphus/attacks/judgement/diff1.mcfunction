#Blast size based on difficulty
execute as @e[type=!#adr_boss:non_living,team=!humanitarian,distance=..5] run function adr_boss:main/damage

particle flame ^ ^ ^ 2 2 2 0.1 2000 normal

particle flash ^ ^ ^ 2 2 2 0 20 normal

particle block yellow_stained_glass ~ ~1 ~ 2 2 2 1 200 normal

particle explosion ^ ^ ^ 2 2 2 0 20 normal

particle block stone ~ ~ ~ 0.4 0.6 0.4 0 100 normal

particle block stone ~ ~ ~ 0.4 0.6 0.4 1 100 normal
