#Raycast
execute unless block ^ ^ ^.5 #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/attacks/dash/dash

execute positioned ^ ^ ^.5 positioned ~-1.5 ~-1.5 ~-1.5 if entity @e[type=!#adr_boss:non_living,tag=target,dx=2,dy=2,dz=2] positioned ~1.5 ~1.5 ~1.5 run function p2_boss:bosses/sisyphus/attacks/dash/dash

execute positioned ^ ^ ^.5 if block ~ ~ ~ #adr_boss:pseudo_air positioned ~-1.5 ~-1.5 ~-1.5 unless entity @e[type=!#adr_boss:non_living,tag=target,dx=2,dy=2,dz=2] positioned ~1.5 ~1.5 ~1.5 run function p2_boss:bosses/sisyphus/attacks/dash/ray

#Effects
execute anchored feet unless block ~ ~-1 ~ #adr_boss:pseudo_air run particle block stone ~ ~ ~ 0.2 0.2 0.2 1 50 normal

particle dust 1.000 0.780 0.120 1 ~ ~3 ~ 0.4 2 0.4 0 10 normal

particle dust 1.000 0.780 0.120 1 ~ ~3 ~ 0.4 2 0.4 0 10 normal
