#Walk
tag @s add walking

tag @s remove idle

execute as @e[type=item_display,tag=adr_model,tag=sisyphus,sort=nearest,limit=1] run function animated_java:sisyphus/animations/walk/play

execute as @e[type=item_display,tag=adr_model,tag=sisyphus,sort=nearest,limit=1] run function animated_java:sisyphus/animations/idle/stop
