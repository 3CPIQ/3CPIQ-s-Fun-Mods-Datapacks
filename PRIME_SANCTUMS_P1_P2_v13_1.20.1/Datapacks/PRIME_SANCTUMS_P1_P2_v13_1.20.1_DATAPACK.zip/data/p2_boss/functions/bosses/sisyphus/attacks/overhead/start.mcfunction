#Start
data modify entity @s NoAI set value 1b

execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/overhead_start/play

scoreboard players remove @s boss_stamina 10

#Look at target
tp @s ~ ~ ~ facing entity @e[type=!#adr_boss:non_living,tag=target,limit=1] feet

tag @e[type=!#adr_boss:non_living,tag=target] remove target
