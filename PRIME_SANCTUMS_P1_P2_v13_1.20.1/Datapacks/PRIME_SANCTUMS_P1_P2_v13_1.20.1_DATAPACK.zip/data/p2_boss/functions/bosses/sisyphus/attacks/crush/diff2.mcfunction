#Blast size based on difficulty
execute as @e[type=!#adr_boss:non_living,team=!humanitarian,distance=..10] run function adr_boss:main/damage

particle flame ^ ^ ^ 3 3 3 0.1 5000 normal

particle flash ^ ^ ^ 3 3 3 0 50 normal

particle block yellow_stained_glass ~ ~ ~ 3 3 3 1 400 normal

particle explosion ^ ^ ^ 3 3 3 0 50 normal

particle block stone ~ ~ ~ 0.6 0.8 0.6 0 200 normal

particle block stone ~ ~ ~ 0.6 0.8 0.6 1 200 normal
