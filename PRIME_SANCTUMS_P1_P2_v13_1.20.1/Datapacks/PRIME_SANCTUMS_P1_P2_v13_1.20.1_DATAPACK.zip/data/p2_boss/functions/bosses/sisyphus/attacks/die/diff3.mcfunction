#Blast size based on difficulty
execute as @e[type=!#adr_boss:non_living,team=!humanitarian,distance=..6] run function adr_boss:main/damage

particle flash ^ ^ ^ 3 3 3 0 50 normal

particle explosion ^ ^ ^ 3 3 3 0 50 normal

particle block stone ~ ~ ~ 0.8 1.0 0.8 0 300 normal

particle block stone ~ ~ ~ 0.8 1.0 0.8 1 300 normal
