#Regain stamina
execute if entity @s[tag=diff_1] run scoreboard players add @s boss_stamina 1

execute if entity @s[tag=diff_2] run scoreboard players add @s boss_stamina 2

execute if entity @s[tag=diff_3] run scoreboard players add @s boss_stamina 3

execute if score @s boss_stamina > @s boss_stamina_max run scoreboard players operation @s boss_stamina = @s boss_stamina_max
