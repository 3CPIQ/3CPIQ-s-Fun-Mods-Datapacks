#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1 run function p2_boss:bosses/sisyphus/attacks/crush/start

#Make start up and recovery faster on boss difficulty
scoreboard players add @s[tag=diff_3] boss_timer 1

#Make start up faster on phase 2
execute unless score @s[tag=phase2] boss_timer matches 20.. run scoreboard players add @s boss_timer 1

#Slam down
execute if score @s boss_timer matches 20 run function p2_boss:bosses/sisyphus/attacks/crush/ray

#Make recover faster on modded difficulty
execute if score @s[tag=diff_2] boss_timer matches 22.. run scoreboard players add @s boss_timer 1

#Make recover faster on phase 2
execute if score @s[tag=phase2] boss_timer matches 22.. run scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 40.. run function p2_boss:bosses/sisyphus/attacks/crush/end
