#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1 run function p2_boss:bosses/sisyphus/attacks/serpent/start

#Make start up and recovery faster on boss difficulty
scoreboard players add @s[tag=diff_3] boss_timer 1

#Make start up faster on phase 2
execute unless score @s[tag=phase2] boss_timer matches 18.. run scoreboard players add @s boss_timer 1

#Particles
execute if score @s boss_timer matches 3..4 rotated ~ 0 positioned ^-1 ^1.5 ^.2 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/1

execute if score @s boss_timer matches 5..6 rotated ~ 0 positioned ^-1 ^1.5 ^.3 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/2

execute if score @s boss_timer matches 7..8 rotated ~ 0 positioned ^-1 ^1.5 ^.4 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/3

execute if score @s boss_timer matches 9..10 rotated ~ 0 positioned ^-1 ^1.5 ^.5 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/4

execute if score @s boss_timer matches 11..12 rotated ~ 0 positioned ^-1 ^1.5 ^.6 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/5

execute if score @s boss_timer matches 13..14 rotated ~ 0 positioned ^-1 ^1.5 ^.7 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/6

execute if score @s boss_timer matches 15..16 rotated ~ 0 positioned ^-1 ^1.5 ^.8 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/7

execute if score @s boss_timer matches 17..18 rotated ~ 0 positioned ^-1 ^1.5 ^.9 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/8

execute if score @s boss_timer matches 19..20 rotated ~ 0 positioned ^-1 ^1.5 ^1 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/9

#Shoot serpent
execute if score @s boss_timer matches 18 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/serpent_hit/play

execute if score @s boss_timer matches 20 rotated ~ 0 positioned ^-1 ^1.5 ^1 run function p2_boss:bosses/sisyphus/attacks/serpent/shoot

execute if score @s boss_timer matches 22 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/serpent_end/play

#Make recover faster on modded difficulty
execute if score @s[tag=diff_2] boss_timer matches 22.. run scoreboard players add @s boss_timer 1

#Make recover faster on phase 2
execute if score @s[tag=phase2] boss_timer matches 22.. run scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 40.. run function p2_boss:bosses/sisyphus/attacks/serpent/end
