#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1 run function p2_boss:bosses/sisyphus/attacks/uppercut/start

#Make start up and recovery faster on boss difficulty
execute if score @s[tag=diff_3] boss_timer matches 1..19 run scoreboard players add @s boss_timer 1

execute if score @s[tag=diff_3] boss_timer matches 41.. run scoreboard players add @s boss_timer 1

#Make start up faster on phase 2
execute unless score @s[tag=phase2] boss_timer matches 8.. run scoreboard players add @s boss_timer 1

#Uppercut
execute if score @s boss_timer matches 10 run function p2_boss:bosses/sisyphus/attacks/dash/main

execute if score @s boss_timer matches 18 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/uppercut_hit/play

execute if score @s boss_timer matches 18 run playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 10 0.7 0

execute if score @s boss_timer matches 20..22 run function p2_boss:bosses/sisyphus/attacks/uppercut/hit

execute if score @s boss_timer matches 20..40 run function p2_boss:bosses/sisyphus/attacks/uppercut/up

#Particles
execute if score @s boss_timer matches 20..50 anchored eyes rotated ~ 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^2 0.2 0.2 0.2 0 10 force

#Make recover faster on modded difficulty
execute if score @s[tag=diff_2] boss_timer matches 42.. run scoreboard players add @s boss_timer 1

#Make recover faster on phase 2
execute if score @s[tag=phase2] boss_timer matches 42.. run scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 50.. run function p2_boss:bosses/sisyphus/attacks/uppercut/end
