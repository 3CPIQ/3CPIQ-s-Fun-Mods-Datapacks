#Initialize
function adr_boss:main/give_id

tag @s remove no_id

team join humanitarian @s

effect give @s invisibility infinite 0 true

effect give @s resistance infinite 255 true

effect give @s weakness infinite 255 true

scoreboard players operation @e[type=iron_golem,distance=..10,tag=adr_hitbox,tag=sisyphus,tag=no_id,limit=1] boss_id = @s boss_id

scoreboard players operation @e[type=item_display,distance=..10,tag=adr_model,tag=sisyphus,tag=no_id,limit=1] boss_id = @s boss_id

execute as @e[type=iron_golem,distance=..10,tag=adr_hitbox,tag=sisyphus,tag=no_id,limit=1] run function p2_boss:bosses/sisyphus/spawn/init_hitbox

tag @e[type=item_display,distance=..10,tag=adr_model,tag=sisyphus,tag=no_id,limit=1] remove no_id
