#Summon Orb
summon marker ~ ~ ~ {Tags: ["sisyphus_orb"]}
