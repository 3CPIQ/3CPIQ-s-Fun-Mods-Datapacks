#Spawn wave
execute rotated 0 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 10 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 20 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 30 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 40 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 50 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 60 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 70 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 80 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 90 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 100 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 110 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 120 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 130 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 140 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 150 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 160 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 170 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 180 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 190 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 200 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 210 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 220 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 230 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 240 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 250 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 260 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 270 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 280 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 290 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 300 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 310 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 320 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 330 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 340 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute rotated 350 0 run summon marker ^ ^ ^.5 {Tags: ["p2_boss_wave"]}

execute as @e[type=marker,tag=p2_boss_wave,distance=..4] positioned as @s run tp @s ~ ~ ~ facing entity @e[type=iron_golem,tag=adr_hitbox,tag=sisyphus,sort=nearest,distance=..4,limit=1]

execute store result score @e[type=marker,tag=p2_boss_wave,distance=..5] boss_attack run attribute @s generic.attack_damage get 250
