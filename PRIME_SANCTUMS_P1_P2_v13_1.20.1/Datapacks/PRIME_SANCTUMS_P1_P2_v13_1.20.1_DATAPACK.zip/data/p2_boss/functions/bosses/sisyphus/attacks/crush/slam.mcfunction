#Slam
tp @s ~ ~ ~

tp @e[type=!#adr_boss:non_living,tag=crushed] ~ ~ ~

tag @e[type=!#adr_boss:non_living,tag=crushed] remove crushed

execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/land/play

#Damage blast
execute store result score $damage boss_id run attribute @s generic.attack_damage get 500

execute if entity @s[tag=diff_1] run function p2_boss:bosses/sisyphus/attacks/crush/diff1

execute if entity @s[tag=diff_2] run function p2_boss:bosses/sisyphus/attacks/crush/diff2

execute if entity @s[tag=diff_3] run function p2_boss:bosses/sisyphus/attacks/crush/diff3

playsound entity.generic.explode master @a ~ ~ ~ 10 0.75 0

playsound entity.generic.explode master @a ~ ~ ~ 10 0.5 0

#Summon damage wave
#function p2_boss:bosses/sisyphus/attacks/wave/horizontal
summon ultracraft:shockwave ~ ~ ~

# P1 COMPLETE v2 MASSIVE CRATER PATCH
execute positioned ~ ~-1 ~ if entity @s[tag=diff_1] run function p2:destruction/minos_crater_r6
execute positioned ~ ~-1 ~ if entity @s[tag=diff_2] run function p2:destruction/minos_crater_r8
execute positioned ~ ~-1 ~ if entity @s[tag=diff_3] run function p2:destruction/minos_crater_r10

# P-2 phase-2 impact lightning
execute positioned ~ ~-1 ~ run if entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,tag=phase2,limit=1] if predicate adr_boss:rng/50 run function p2:sisy_phase2_lightning_impact
