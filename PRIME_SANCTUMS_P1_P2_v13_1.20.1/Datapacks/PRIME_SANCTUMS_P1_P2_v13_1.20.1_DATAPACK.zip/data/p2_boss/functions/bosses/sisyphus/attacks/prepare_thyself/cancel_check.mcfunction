#Cancel to uppercut
execute at @e[type=!#adr_boss:non_living,tag=target] if block ~ ~-1 ~ #adr_boss:pseudo_air if block ~ ~-2 ~ #adr_boss:pseudo_air if block ~ ~-3 ~ #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/attacks/prepare_thyself/cancel
