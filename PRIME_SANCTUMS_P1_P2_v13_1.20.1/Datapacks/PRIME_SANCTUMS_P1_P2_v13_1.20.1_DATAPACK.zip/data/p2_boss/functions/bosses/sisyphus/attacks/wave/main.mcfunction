#Damaging wave
scoreboard players add @s boss_timer 1

#Damage
execute unless entity @s[tag=no_damage] positioned ~-1.5 ~ ~-1.5 as @e[type=!#adr_boss:non_living,team=!humanitarian,dx=2,dy=0,dz=2] positioned ~1.5 ~ ~1.5 run function p2_boss:bosses/sisyphus/attacks/wave/hit

#Visual
particle crit ^ ^ ^ 0.75 0.75 0.75 0 10 force

execute if score @s boss_timer matches 1..20 run tp @s ^ ^ ^-.5

execute if score @s boss_timer matches 21..40 run tp @s ^ ^ ^-.25

execute if score @s boss_timer matches 41..60 run tp @s ^ ^ ^-.125

execute if score @s boss_timer matches 60 run kill @s
