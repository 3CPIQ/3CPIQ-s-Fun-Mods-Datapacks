#Blast size based on difficulty
execute as @e[type=!#adr_boss:non_living,team=!humanitarian,distance=..4] run function adr_boss:main/damage

particle flash ^ ^ ^ 2 2 2 0 10 normal

particle explosion ^ ^ ^ 2 2 2 0 10 normal

particle block stone ~ ~ ~ 0.6 0.8 0.6 0 200 normal

particle block stone ~ ~ ~ 0.6 0.8 0.6 1 200 normal
