# DESTROY ground detection.
# Recursively scan downward until real terrain is found, up to 48 blocks.

# Continue downward while the next quarter-block is pseudo-air and still
# within 48 blocks of Sisyphus's original aerial position.
execute positioned ~ ~-0.25 ~ if entity @s[distance=..48] if block ~ ~ ~ #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/attacks/judgement/ground_snap

# When the next quarter-block is solid, snap Sisyphus to this position.
execute positioned ~ ~-0.25 ~ unless block ~ ~ ~ #adr_boss:pseudo_air run tp @s ~ ~ ~

# Mark the dropkick as having a valid terrain impact.
execute positioned ~ ~-0.25 ~ unless block ~ ~ ~ #adr_boss:pseudo_air run tag @s add destroy_grounded
