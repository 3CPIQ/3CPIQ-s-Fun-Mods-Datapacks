#Raycast
execute positioned ~-2 ~-2 ~-2 run tag @e[type=!#adr_boss:non_living,team=!humanitarian,dx=3,dy=3,dz=3] add crushed

execute positioned ^ ^ ^.5 if block ~ ~ ~ #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/attacks/die/ray

execute unless entity @s[tag=slammed] unless block ^ ^ ^.5 #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/attacks/die/slam

#Effects
particle dust 1.000 0.780 0.120 1 ~ ~1 ~ 0.2 0.5 0.2 0 20 normal
