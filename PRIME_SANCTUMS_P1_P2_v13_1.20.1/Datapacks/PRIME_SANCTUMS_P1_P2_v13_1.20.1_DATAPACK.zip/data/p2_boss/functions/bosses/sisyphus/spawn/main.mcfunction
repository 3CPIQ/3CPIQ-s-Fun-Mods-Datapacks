#Spawn animation
scoreboard players add @s boss_timer 1

# P2_MONOLOGUE — synchronized to Sp_intro.ogg; audio begins at boss_timer 110
execute if score @s boss_timer matches 110 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"A visitor?","color":"yellow"}]
execute if score @s boss_timer matches 145 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"Hmm\u2026","color":"yellow","italic":true}]
execute if score @s boss_timer matches 168 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"Indeed,","color":"yellow"}]
execute if score @s boss_timer matches 192 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"I have slept long enough.","color":"yellow"}]
execute if score @s boss_timer matches 244 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"The kingdom of Heaven has long since forgotten my name,","color":"yellow"}]
execute if score @s boss_timer matches 318 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"and I am ","color":"yellow"},{"text":"EAGER","color":"gold","bold":true}]
execute if score @s boss_timer matches 362 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"to make them remember.","color":"yellow"}]
execute if score @s boss_timer matches 429 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"However,","color":"yellow"}]
execute if score @s boss_timer matches 455 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"the blood of Minos stains your hands,","color":"yellow"}]
execute if score @s boss_timer matches 515 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"and I must admit\u2026","color":"yellow"}]
execute if score @s boss_timer matches 554 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"I'm curious about your skills,","color":"yellow"}]
execute if score @s boss_timer matches 603 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"weapon.","color":"yellow"}]
execute if score @s boss_timer matches 630 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"And so,","color":"yellow"}]
execute if score @s boss_timer matches 650 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"before I tear down the cities and ","color":"yellow"},{"text":"CRUSH","color":"gold","bold":true},{"text":" the armies of Heaven\u2026","color":"yellow"}]
execute if score @s boss_timer matches 740 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"You shall","color":"yellow"}]
execute if score @s boss_timer matches 752 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"do as an appetizer.","color":"yellow"}]
execute if score @s boss_timer matches 809 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"Come forth,","color":"yellow"}]
execute if score @s boss_timer matches 826 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"Child of Man\u2026","color":"yellow","italic":true}]
execute if score @s boss_timer matches 859 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"And ","color":"yellow"},{"text":"DIE.","color":"red","bold":true}]


# Full Sisyphus intro begins after the breakout line
execute if score @s boss_timer matches 110 run execute as @a at @s run playsound minecraft:boss.sisyphus.intro voice @s ~ ~ ~ 0.80 1 0

execute if score @s boss_timer matches 1..904 run effect give @s resistance 1 255 true

execute if score @s boss_timer matches 1..904 run effect give @s slowness 1 255 true

execute if score @s boss_timer matches 1 run function p2_boss:bosses/sisyphus/spawn/start
















execute if score @s boss_timer matches 905.. run function p2_boss:bosses/sisyphus/spawn/end
