#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1 run function p2_boss:bosses/sisyphus/attacks/prepare_thyself/start

#Cancel to upper cut if target is in air
execute if score @s boss_timer matches 23..29 run function p2_boss:bosses/sisyphus/attacks/prepare_thyself/cancel_check

execute if score @s boss_timer matches 43..49 run function p2_boss:bosses/sisyphus/attacks/prepare_thyself/cancel_check

#Make start up and recovery faster on boss difficulty
scoreboard players add @s[tag=diff_3] boss_timer 1

#Make start up faster on phase 2
execute if score @s[tag=phase2] boss_timer matches 11..15 run scoreboard players add @s boss_timer 1

execute if score @s[tag=phase2] boss_timer matches 31..35 run scoreboard players add @s boss_timer 1

execute if score @s[tag=phase2] boss_timer matches 51..55 run scoreboard players add @s boss_timer 1

#Kick
execute if score @s boss_timer matches 10 run function p2_boss:bosses/sisyphus/attacks/dash/main

execute if score @s boss_timer matches 18 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/kick_hit/play

execute if score @s boss_timer matches 18 run playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 10 0.7 0

execute if score @s boss_timer matches 18..22 rotated ~ 0 run function p2_boss:bosses/sisyphus/attacks/prepare_thyself/kick

execute if score @s boss_timer matches 18..22 rotated ~ 0 if block ^ ^ ^.5 #adr_boss:pseudo_air run tp @s ^ ^ ^.5

execute if score @s[tag=diff_3] boss_timer matches 20..22 rotated ~ 0 if block ^ ^ ^.5 #adr_boss:pseudo_air run tp @s ^ ^ ^.5

#Particles
execute if score @s boss_timer matches 17 anchored eyes rotated ~75 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 18 anchored eyes rotated ~60 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 18 anchored eyes rotated ~45 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 19 anchored eyes rotated ~30 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 19 anchored eyes rotated ~15 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 20 anchored eyes rotated ~0 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 20 anchored eyes rotated ~-15 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 21 anchored eyes rotated ~-30 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 21 anchored eyes rotated ~-45 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 22 anchored eyes rotated ~-60 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 22 anchored eyes rotated ~-75 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 18 anchored eyes rotated ~75 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 20 anchored eyes rotated ~30 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 20 anchored eyes rotated ~15 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 22 anchored eyes rotated ~-30 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 22 anchored eyes rotated ~-45 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

#Axe kick
execute if score @s boss_timer matches 22 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/axe_kick_start/play

execute if score @s boss_timer matches 30 run function p2_boss:bosses/sisyphus/attacks/dash/main

execute if score @s boss_timer matches 38 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/axe_kick_hit/play

execute if score @s boss_timer matches 38 run playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 10 0.7 0

execute if score @s boss_timer matches 38..42 rotated ~ 0 run function p2_boss:bosses/sisyphus/attacks/prepare_thyself/axe_kick

execute if score @s boss_timer matches 38..42 rotated ~ 0 if block ^ ^ ^.5 #adr_boss:pseudo_air run tp @s ^ ^ ^.5

execute if score @s[tag=diff_3] boss_timer matches 40..42 rotated ~ 0 if block ^ ^ ^.5 #adr_boss:pseudo_air run tp @s ^ ^ ^.5

#Particles
execute if score @s boss_timer matches 37 anchored eyes rotated ~ -75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 38 anchored eyes rotated ~ -60 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 38 anchored eyes rotated ~ -45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 39 anchored eyes rotated ~ -30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 39 anchored eyes rotated ~ -15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 40 anchored eyes rotated ~ 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 40 anchored eyes rotated ~ 15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 41 anchored eyes rotated ~ 30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 41 anchored eyes rotated ~ 45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 42 anchored eyes rotated ~ 60 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 42 anchored eyes rotated ~ 75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 38 anchored eyes rotated ~ -75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 40 anchored eyes rotated ~ -30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 40 anchored eyes rotated ~ -15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 42 anchored eyes rotated ~ 30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 42 anchored eyes rotated ~ 45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

#Serpent
execute if score @s boss_timer matches 42 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/serpent_start/play

execute if score @s boss_timer matches 50 run function p2_boss:bosses/sisyphus/attacks/dash/main

execute if score @s boss_timer matches 58 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/serpent_hit/play

execute if score @s boss_timer matches 60 anchored eyes run function p2_boss:bosses/sisyphus/attacks/serpent/shoot

execute if score @s boss_timer matches 62 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/serpent_end/play

#Particles
execute if score @s boss_timer matches 43..44 rotated ~ 0 positioned ^-1 ^1.5 ^.2 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/1

execute if score @s boss_timer matches 45..46 rotated ~ 0 positioned ^-1 ^1.5 ^.3 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/2

execute if score @s boss_timer matches 47..48 rotated ~ 0 positioned ^-1 ^1.5 ^.4 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/3

execute if score @s boss_timer matches 49..50 rotated ~ 0 positioned ^-1 ^1.5 ^.5 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/4

execute if score @s boss_timer matches 51..52 rotated ~ 0 positioned ^-1 ^1.5 ^.6 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/5

execute if score @s boss_timer matches 53..54 rotated ~ 0 positioned ^-1 ^1.5 ^.7 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/6

execute if score @s boss_timer matches 55..56 rotated ~ 0 positioned ^-1 ^1.5 ^.8 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/7

execute if score @s boss_timer matches 57..58 rotated ~ 0 positioned ^-1 ^1.5 ^.9 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/8

execute if score @s boss_timer matches 59..60 rotated ~ 0 positioned ^-1 ^1.5 ^1 run function p2_boss:bosses/sisyphus/attacks/serpent/particle/9

#Make recover faster on modded difficulty
execute if score @s[tag=diff_2] boss_timer matches 62.. run scoreboard players add @s boss_timer 1

#Make recover faster on phase 2
execute if score @s[tag=phase2] boss_timer matches 62.. run scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 80.. run function p2_boss:bosses/sisyphus/attacks/prepare_thyself/end
