#Spawn start
effect give @s regeneration 47 255 true


#Summon wave
function p2_boss:bosses/sisyphus/attacks/wave/no_dmg

execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/speech/play
