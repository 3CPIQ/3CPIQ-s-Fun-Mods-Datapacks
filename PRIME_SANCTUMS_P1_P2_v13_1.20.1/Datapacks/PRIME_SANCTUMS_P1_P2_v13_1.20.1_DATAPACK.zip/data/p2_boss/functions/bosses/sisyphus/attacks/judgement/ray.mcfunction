#Raycast
execute unless block ^ ^ ^.5 #adr_boss:pseudo_air run tp @s ~ ~ ~ ~ ~-10

execute positioned ^ ^ ^.5 if entity @s[distance=..40] if block ~ ~ ~ #adr_boss:pseudo_air positioned ~-1.25 ~-1.25 ~-1.25 unless entity @e[type=!#adr_boss:non_living,team=!humanitarian,dx=1.5,dy=1.5,dz=1.5] positioned ~1.25 ~1.25 ~1.25 run function p2_boss:bosses/sisyphus/attacks/judgement/ray

execute unless block ^ ^ ^.5 #adr_boss:pseudo_air run tp @s ^ ^ ^-1

execute positioned ^ ^ ^.5 positioned ~-1.25 ~-1.25 ~-1.25 if entity @e[type=!#adr_boss:non_living,team=!humanitarian,dx=1.5,dy=1.5,dz=1.5] positioned ~1.25 ~1.25 ~1.25 run tp @s ^ ^ ^-1

execute positioned ^ ^ ^.5 unless entity @s[distance=..40] run tp @s ^ ^ ^-1

#Effects
particle dust 1.000 0.780 0.120 1 ~ ~1 ~ 0.2 0.5 0.2 0 20 normal

execute anchored feet unless block ~ ~-1 ~ #adr_boss:pseudo_air run particle block stone ~ ~ ~ 0.2 0.2 0.2 1 50 normal

particle dust 1.000 0.780 0.120 1 ~ ~3 ~ 0.4 2 0.4 0 10 normal

particle dust 1.000 0.780 0.120 1 ~ ~3 ~ 0.4 2 0.4 0 10 normal
