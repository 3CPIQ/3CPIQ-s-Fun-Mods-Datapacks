#Death
scoreboard players add @s boss_timer 1

# P2_DEATH_MONOLOGUE — synchronized to the uploaded Sp_outro.ogg
execute if score @s boss_timer matches 2 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"Ahh\u2026","color":"yellow","italic":true}]
execute if score @s boss_timer matches 35 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"So concludes the life and times of King Sisyphus","color":"yellow"}]
execute if score @s boss_timer matches 129 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"A fitting end to an existence defined by futile struggle,","color":"yellow"}]
execute if score @s boss_timer matches 244 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"Doomed from the very start\u2026","color":"yellow","italic":true}]
execute if score @s boss_timer matches 317 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"And I don't regret a ","color":"yellow"},{"text":"SECOND","color":"gold","bold":true},{"text":" of it!","color":"yellow"}]


execute if score @s boss_timer matches 2 run function p2_boss:bosses/sisyphus/death/start









execute if score @s boss_timer matches 320 run function animated_java:sisyphus/animations/scream/play

execute if score @s boss_timer matches 320.. if block ~ ~4 ~ #adr_boss:pseudo_air run tp @s ~ ~.1 ~

execute if score @s boss_timer matches 320.. run particle flash ~ ~ ~ 0 0 0 0 1 force

execute if score @s boss_timer matches 340.. rotated 190 -20 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 340 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 360.. rotated 30 30 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 360 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 380.. rotated 220 90 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 380 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 400.. rotated 0 -30 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 400 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 410.. rotated 350 -50 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 410 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 420.. rotated -40 80 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 420 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 430.. rotated 200 60 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 430 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 440.. rotated -20 10 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 440 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 445.. rotated 230 30 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 445 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 450.. rotated 80 -0 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 450 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 455.. rotated -210 70 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 455 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 460.. rotated -240 -70 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 460 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 462.. rotated 90 40 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 462 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 464.. rotated -260 -10 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 464 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 466.. rotated -70 50 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 466 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 468.. rotated -230 20 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 468 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 470.. rotated -10 -80 run function p2_boss:bosses/sisyphus/death/beam

execute if score @s boss_timer matches 470 run playsound minecraft:entity.allay.item_thrown master @a ~ ~ ~ 10 1 0

execute if score @s boss_timer matches 585.. run function p2_boss:bosses/sisyphus/death/end
