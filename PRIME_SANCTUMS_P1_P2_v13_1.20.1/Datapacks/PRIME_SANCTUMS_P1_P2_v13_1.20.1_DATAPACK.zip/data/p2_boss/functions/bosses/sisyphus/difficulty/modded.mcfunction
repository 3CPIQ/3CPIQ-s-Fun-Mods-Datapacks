#Modded Difficulty
attribute @s generic.max_health base set 800

attribute @s generic.movement_speed base set 0.5

attribute @s generic.armor base set 20

attribute @s generic.armor_toughness base set 30

attribute @s generic.attack_damage base set 15

scoreboard players set @s boss_stamina_max 120

tag @s add diff_2
