# Sisyphus shatters only after his full outro has finished.

# Absolutely no voice is allowed to continue after the soul explodes.
stopsound @a voice minecraft:boss.sisyphus.intro
stopsound @a voice minecraft:boss.sisyphus.thisprison
stopsound @a voice minecraft:boss.sisyphus.outro

# End the death animation at the shatter moment.
function animated_java:sisyphus/animations/death/stop

particle flash ~ ~ ~ 0.7 0.7 0.7 0 20 force
particle explosion ~ ~ ~ 0.7 0.7 0.7 0 20 force
particle dust 1.000 0.780 0.120 1 ~ ~2 ~ 1.4 2.4 1.4 0.12 180 force

playsound entity.generic.explode master @a ~ ~ ~ 10 0 0
playsound minecraft:block.respawn_anchor.deplete hostile @a ~ ~ ~ 10 0 0

execute if block ~ ~ ~ light run setblock ~ ~ ~ air

# Final shockwave.
function p2_boss:bosses/sisyphus/attacks/wave/no_dmg

# Now the encounter is truly over.
function p2:sisyphus_dead

# Remove the visual model last.
function animated_java:sisyphus/remove/this
