#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1 run function p2_boss:bosses/sisyphus/attacks/overhead/start

#Make start up and recovery faster on boss difficulty
scoreboard players add @s[tag=diff_3] boss_timer 1

#Make start up faster on phase 2
execute if score @s[tag=phase2] boss_timer matches 7..18 run scoreboard players add @s boss_timer 1

#Overhead
execute if score @s boss_timer matches 6 run function p2_boss:bosses/sisyphus/attacks/dash/main

execute if score @s boss_timer matches 18 on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/overhead_hit/play

execute if score @s boss_timer matches 18 run playsound minecraft:entity.wither.shoot hostile @a ~ ~ ~ 10 0.7 0

execute if score @s boss_timer matches 20..22 run function p2_boss:bosses/sisyphus/attacks/overhead/hit

#Particles
execute if score @s boss_timer matches 17 anchored eyes rotated ~ -75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 18 anchored eyes rotated ~ -60 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 18 anchored eyes rotated ~ -45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 19 anchored eyes rotated ~ -30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 19 anchored eyes rotated ~ -15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 20 anchored eyes rotated ~ 0 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 20 anchored eyes rotated ~ 15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 21 anchored eyes rotated ~ 30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 21 anchored eyes rotated ~ 45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 22 anchored eyes rotated ~ 60 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s boss_timer matches 22 anchored eyes rotated ~ 75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 18 anchored eyes rotated ~ -75 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 20 anchored eyes rotated ~ -30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 20 anchored eyes rotated ~ -15 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 22 anchored eyes rotated ~ 30 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

execute if score @s[tag=diff_3] boss_timer matches 22 anchored eyes rotated ~ 45 run particle dust 1.000 0.780 0.120 2 ^ ^ ^3 0.2 0.2 0.2 0 10 force

#Make recover faster on modded difficulty
execute if score @s[tag=diff_2] boss_timer matches 22.. run scoreboard players add @s boss_timer 1

#Make recover faster on phase 2
execute if score @s[tag=phase2] boss_timer matches 22.. run scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 30.. run function p2_boss:bosses/sisyphus/attacks/overhead/end
