#Raycast
execute positioned ~-2 ~-2 ~-2 run tag @e[type=!#adr_boss:non_living,team=!humanitarian,dx=3,dy=3,dz=3] add crushed

execute positioned ~ ~-1 ~ if block ~ ~ ~ #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/attacks/crush/ray

execute unless block ~ ~-1 ~ #adr_boss:pseudo_air run function p2_boss:bosses/sisyphus/attacks/crush/slam

#Effects
particle dust 1.000 0.780 0.120 1 ~ ~ ~ 0.3 0.3 0.3 0 20 normal
