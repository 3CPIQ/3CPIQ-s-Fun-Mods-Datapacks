#Dash
execute anchored eyes run tp @s ~ ~ ~ facing entity @e[type=!#adr_boss:non_living,tag=target,limit=1] feet

execute if block ^ ^ ^1 #adr_boss:pseudo_air run tp @s ^ ^ ^1

particle dust 1.000 0.780 0.120 1 ~ ~3 ~ 0.4 2 0.4 0 50 normal

particle dust 1.000 0.780 0.120 1 ~ ~3 ~ 0.4 2 0.4 0 50 normal

playsound minecraft:entity.allay.death master @a ~ ~ ~ 10 2 0
