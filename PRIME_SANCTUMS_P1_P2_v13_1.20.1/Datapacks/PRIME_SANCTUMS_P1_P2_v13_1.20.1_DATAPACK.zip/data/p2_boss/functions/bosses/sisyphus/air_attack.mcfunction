#Attacks while in-air
scoreboard players set $min boss_rng 1

scoreboard players set $max boss_rng 6

function adr_boss:rng/rng_load

tag @s remove idle

execute as @e[type=item_display,tag=adr_model,tag=sisyphus,sort=nearest,limit=1] run function animated_java:sisyphus/animations/idle/stop

tag @s remove walking

execute as @e[type=item_display,tag=adr_model,tag=sisyphus,sort=nearest,limit=1] run function animated_java:sisyphus/animations/walk/stop

#Crush / Die
execute if score $random boss_rng matches 1..3 unless score @s boss_previous_attack matches 4..5 if score @s boss_stamina matches 10.. positioned ~-3.5 ~-100 ~-3.5 if entity @e[type=!#adr_boss:non_living,tag=target,dx=6,dy=105,dz=6] run scoreboard players set @s boss_attack 4

execute if score $random boss_rng matches 1..3 unless score @s boss_previous_attack matches 4..5 if score @s boss_stamina matches 10.. positioned ~-3.5 ~-100 ~-3.5 unless entity @e[type=!#adr_boss:non_living,tag=target,dx=6,dy=105,dz=6] run scoreboard players set @s boss_attack 5

execute if score $random boss_rng matches 1..3 unless score @s boss_stamina matches 10.. run scoreboard players set $random boss_rng 5

execute if score $random boss_rng matches 1..3 if score @s boss_previous_attack matches 4..5 run scoreboard players set $random boss_rng 5

#Overhead
execute if score $random boss_rng matches 4..5 unless score @s boss_previous_attack matches 7 if score @s boss_stamina matches 10.. run scoreboard players set @s boss_attack 7

execute if score $random boss_rng matches 4..5 unless score @s boss_stamina matches 10.. run scoreboard players set $random boss_rng 6

execute if score $random boss_rng matches 4..5 if score @s boss_previous_attack matches 7 run scoreboard players set $random boss_rng 6

#Serpent
execute if score $random boss_rng matches 6 unless score @s boss_previous_attack matches 8 positioned ~-3 ~-3 ~-3 unless entity @e[type=!#adr_boss:non_living,tag=target,dx=5,dy=5,dz=5] run scoreboard players set @s boss_attack 8

execute if score $random boss_rng matches 6 positioned ~-3 ~-3 ~-3 if entity @e[type=!#adr_boss:non_living,tag=target,dx=5,dy=5,dz=5] run function p2_boss:bosses/sisyphus/air_attack

execute if score $random boss_rng matches 6 if score @s boss_previous_attack matches 8 run function p2_boss:bosses/sisyphus/air_attack

scoreboard players operation @s boss_previous_attack = @s boss_attack
