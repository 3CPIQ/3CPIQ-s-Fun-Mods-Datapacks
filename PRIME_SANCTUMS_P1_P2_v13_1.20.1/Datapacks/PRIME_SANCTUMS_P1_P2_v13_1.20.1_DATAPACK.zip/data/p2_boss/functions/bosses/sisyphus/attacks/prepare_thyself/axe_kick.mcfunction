#Axe kick
execute positioned ^ ^ ^2 run summon area_effect_cloud ~ ~1 ~ {Radius: 2f, RadiusPerTick: 0, Duration: 6, Particle: "block air", Effects: [{Id: 25, Duration: 10, Amplifier: 20, ShowParticles: 0b}]}

#Damage hit
execute store result score $damage boss_id run attribute @s generic.attack_damage get 300

execute positioned ^ ^ ^1.5 positioned ~-2 ~-.5 ~-2 as @e[type=!#adr_boss:non_living,team=!humanitarian,dx=3,dy=4,dz=3] run function adr_boss:main/damage

# P1 COMPLETE DESTRUCTIVE PATCH
execute positioned ^ ^ ^1.5 positioned ~ ~-1 ~ run function p2:destruction/r4

# P-2 phase-2 impact lightning
execute positioned ^ ^ ^1.5 positioned ~ ~-1 ~ run if entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,tag=phase2,limit=1] if predicate adr_boss:rng/50 run function p2:sisy_phase2_lightning_impact
