#Phase 2
tag @s add phase2

# Sisyphus phase-two reaction
execute as @a at @s run playsound minecraft:boss.sisyphus.yesthatsit voice @s ~ ~ ~ 0.90 1 0
