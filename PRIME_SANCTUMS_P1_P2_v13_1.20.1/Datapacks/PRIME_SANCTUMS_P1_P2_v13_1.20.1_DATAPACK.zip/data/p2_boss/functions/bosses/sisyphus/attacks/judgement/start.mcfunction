#Start
execute unless entity @s[tag=phase2] run execute as @a at @s run playsound minecraft:boss.sisyphus.destroy voice @s ~ ~ ~ 0.90 1 0
execute if entity @s[tag=phase2] run execute as @a at @s run playsound minecraft:boss.sisyphus.destroy2 voice @s ~ ~ ~ 0.90 1 0


scoreboard players set $min boss_rng 1

scoreboard players set $max boss_rng 2

function adr_boss:rng/rng_load





data modify entity @s NoAI set value 1b

execute on passengers if entity @s[type=item_display,tag=adr_model,tag=sisyphus] run function animated_java:sisyphus/animations/drop_kick_start/play

scoreboard players remove @s boss_stamina 20

#Look at target
execute anchored feet facing entity @e[type=!#adr_boss:non_living,tag=target,limit=1] feet run tp @s ~ ~ ~ ~ ~-1

tag @e[type=!#adr_boss:non_living,tag=target] remove target
