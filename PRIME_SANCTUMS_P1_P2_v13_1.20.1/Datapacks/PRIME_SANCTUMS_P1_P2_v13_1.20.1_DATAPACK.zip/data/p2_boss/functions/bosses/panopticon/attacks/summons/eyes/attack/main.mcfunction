#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1..10 run tp @s ~ ~ ~ facing entity @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,type=!ultracraft:shotgun_pellet,type=!ultracraft:thrown_machinesword,type=!ultracraft:ejected_core,type=!ultracraft:magnet,type=!ultracraft:soap,type=!ultracraft:retaliation,type=!ultracraft:interruptable_charge,distance=..30,tag=!panopticon,sort=nearest,limit=1] eyes

execute if score @s boss_timer matches 1..20 anchored eyes run function p2_boss:bosses/panopticon/attacks/summons/eyes/attack/aim

execute if score @s boss_timer matches 20 anchored eyes run function p2_boss:bosses/panopticon/attacks/summons/eyes/attack/shoot

execute if score @s boss_timer matches 20 run function p2_boss:bosses/panopticon/attacks/summons/eyes/attack/end
