#Damage
scoreboard players operation $temp boss_id = @s boss_id

execute as @e[type=slime,tag=adr_boss,tag=adr_hitbox,tag=panopticon,distance=..100] if score @s boss_id = $temp boss_id run tag @s remove has_blackhole

scoreboard players operation $damage boss_id = @s boss_attack

particle smoke ^ ^ ^ 1 1 1 0.1 100 force

particle flash ^ ^ ^ 0 0 0 0 1 force

playsound minecraft:entity.wither.hurt hostile @a ~ ~ ~ 10 0 0

execute positioned ~-1.5 ~-1.5 ~-1.5 as @e[type=!#adr_boss:non_living,dx=2,dy=2,dz=2,tag=!panopticon] run function adr_boss:main/damage

kill @s

# P1 COMPLETE DESTRUCTIVE PATCH
function p2:destruction/r2
