#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1..10 run playsound entity.husk.death hostile @a ~ ~ ~ 20 0 0

execute if score @s boss_timer matches 1 run function p2_boss:bosses/panopticon/attacks/divine_lights/wave/vertical

execute if score @s boss_timer matches 1 on passengers if entity @s[type=item_display,tag=adr_model,tag=panopticon] run function animated_java:panopticon/animations/open/play

#Make start up faster on boss difficulty
execute if score @s[tag=diff_3] boss_timer matches 1..20 run scoreboard players add @s boss_timer 1

#Summon beam of light
execute if score @s boss_timer matches 20 at @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,type=!ultracraft:shotgun_pellet,type=!ultracraft:thrown_machinesword,type=!ultracraft:ejected_core,type=!ultracraft:magnet,type=!ultracraft:soap,type=!ultracraft:retaliation,type=!ultracraft:interruptable_charge,tag=!panopticon,sort=nearest,distance=..50,limit=1] run function p2_boss:bosses/panopticon/attacks/divine_lights/summon

execute if score @s boss_timer matches 80 at @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,type=!ultracraft:shotgun_pellet,type=!ultracraft:thrown_machinesword,type=!ultracraft:ejected_core,type=!ultracraft:magnet,type=!ultracraft:soap,type=!ultracraft:retaliation,type=!ultracraft:interruptable_charge,tag=!panopticon,sort=nearest,distance=..50,limit=1] run function p2_boss:bosses/panopticon/attacks/divine_lights/summon

execute if score @s boss_timer matches 140 at @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,tag=!panopticon,sort=nearest,distance=..50,limit=1] run function p2_boss:bosses/panopticon/attacks/divine_lights/summon

execute if score @s[tag=phase2] boss_timer matches 200 at @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,type=!ultracraft:shotgun_pellet,type=!ultracraft:thrown_machinesword,type=!ultracraft:ejected_core,type=!ultracraft:magnet,type=!ultracraft:soap,type=!ultracraft:retaliation,type=!ultracraft:interruptable_charge,tag=!panopticon,sort=nearest,distance=..50,limit=1] run function p2_boss:bosses/panopticon/attacks/divine_lights/summon

#Make recover faster on modded and boss difficulty
execute if score @s[tag=!phase2,tag=diff_2] boss_timer matches 140.. run scoreboard players add @s boss_timer 1

execute if score @s[tag=phase2,tag=diff_2] boss_timer matches 200.. run scoreboard players add @s boss_timer 1

execute if score @s[tag=!phase2,tag=diff_3] boss_timer matches 140.. run scoreboard players add @s boss_timer 1

execute if score @s[tag=phase2,tag=diff_3] boss_timer matches 200.. run scoreboard players add @s boss_timer 1

#Shoot one more on phase 2 before ending
execute if score @s[tag=!phase2] boss_timer matches 180.. run function p2_boss:bosses/panopticon/attacks/divine_lights/end

execute if score @s[tag=phase2] boss_timer matches 220.. run function p2_boss:bosses/panopticon/attacks/divine_lights/end
