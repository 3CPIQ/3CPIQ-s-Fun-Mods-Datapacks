#Damage
execute store result score $damage boss_id run attribute @s generic.attack_damage get 150

playsound entity.generic.explode hostile @a ~ ~ ~ 10 1 0

execute positioned ~-2 ~-2 ~-2 as @e[type=!#adr_boss:non_living,dx=3,dy=3,dz=3,tag=!panopticon] run function adr_boss:main/damage

particle dust 1 1 0 1 ~ ~ ~ 1 1 1 1 50 force

particle flash ~ ~ ~ 0 0 0 0 1 force

# P1 COMPLETE DESTRUCTIVE PATCH
function p2:destruction/r2
