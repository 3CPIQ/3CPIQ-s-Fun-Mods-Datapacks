#Death
tag @e[type=marker,tag=p1_trigger,distance=..100,sort=nearest,limit=1] add death

scoreboard players set @s boss_timer 0

execute unless entity @e[type=slime,tag=adr_hitbox,tag=panopticon,tag=!panopticon_summon] run bossbar remove p2:panopticon

tp @e[type=slime,tag=!panopticon,name="Panopticon",distance=..10] ~ ~-1000 ~

tag @s add dead
