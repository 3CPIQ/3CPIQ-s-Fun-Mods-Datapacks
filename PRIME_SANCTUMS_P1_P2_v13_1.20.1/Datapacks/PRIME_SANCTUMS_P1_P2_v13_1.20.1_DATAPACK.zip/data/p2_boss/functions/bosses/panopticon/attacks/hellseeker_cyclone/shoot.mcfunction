#Shoot hellseeker projectile
summon item_display ^ ^ ^ {Tags: ["p2_boss_hellseeker", "panopticon", "init"], billboard: "center", item: {id: "minecraft:black_dye", Count: 1, tag: {CustomModelData: 1}}, CustomName: "{\"text\": \"Panopticon\"}"}

execute as @e[type=item_display,distance=..4,sort=nearest,limit=1] at @s rotated as @e[type=slime,tag=adr_hitbox,tag=panopticon,tag=!panopticon_summon,sort=nearest,limit=1] run tp @s ~ ~ ~ ~ 0

execute store result score @e[type=item_display,tag=p2_boss_hellseeker,tag=init,distance=..4,sort=nearest,limit=1] boss_attack run attribute @s generic.attack_damage get 300

tag @e[type=item_display,tag=p2_boss_hellseeker,tag=init,distance=..4,sort=nearest,limit=1] remove init

playsound block.honey_block.fall hostile @a ~ ~ ~ 10 0 0
