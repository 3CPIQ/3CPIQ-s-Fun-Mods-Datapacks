#Summon amount based on phase
execute if entity @s[tag=!phase2] run function p2_boss:bosses/panopticon/attacks/summons/summon/phase1

execute if entity @s[tag=phase2] run function p2_boss:bosses/panopticon/attacks/summons/summon/phase2
