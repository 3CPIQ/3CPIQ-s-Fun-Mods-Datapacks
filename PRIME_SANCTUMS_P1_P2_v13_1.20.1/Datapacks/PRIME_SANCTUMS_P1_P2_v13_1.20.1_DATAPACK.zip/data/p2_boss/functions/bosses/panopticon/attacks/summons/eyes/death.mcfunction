#Death
particle block nether_wart_block ~ ~ ~ 1 1 1 1 100 force

playsound minecraft:block.gravel.place hostile @a ~ ~ ~ 5 0 0

kill @s
