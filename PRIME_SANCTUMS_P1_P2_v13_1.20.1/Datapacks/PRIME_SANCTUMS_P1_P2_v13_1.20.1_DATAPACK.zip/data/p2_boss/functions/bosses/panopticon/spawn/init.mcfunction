#Initialize
function adr_boss:main/give_id

effect give @s invisibility infinite 0 true

effect give @s fire_resistance infinite 0 true

tag @s remove no_id

tp @s ~ ~6 ~

scoreboard players set @s boss_attack 0

scoreboard players set @s boss_timer 0

scoreboard players operation @e[type=item_display,distance=..10,tag=adr_model,tag=panopticon,tag=no_id,limit=1] boss_id = @s boss_id

tag @e[type=item_display,distance=..10,tag=adr_model,tag=panopticon,tag=no_id,limit=1] remove no_id

#Attributes based on Difficulty
execute if score $difficulty boss_id matches 1 run function p2_boss:bosses/panopticon/difficulty/vanilla

execute if score $difficulty boss_id matches 2 run function p2_boss:bosses/panopticon/difficulty/modded

execute if score $difficulty boss_id matches 3 run function p2_boss:bosses/panopticon/difficulty/boss

execute store result score @s boss_half_hp run attribute @s generic.max_health get

scoreboard players set $int boss_id 2

scoreboard players operation @s boss_half_hp /= $int boss_id

#Bossbar
bossbar add p2:panopticon {"text": "Panopticon","color": "white","bold": true}

bossbar set p2:panopticon color red

bossbar set p2:panopticon style progress

bossbar set p2:panopticon players @a

bossbar set p2:panopticon visible true

#Player count adjusted protection level
execute store result score $player_count boss_id if entity @a[tag=in_boss_sisyphus,tag=inside]

function adr_boss:difficulty/player_count
