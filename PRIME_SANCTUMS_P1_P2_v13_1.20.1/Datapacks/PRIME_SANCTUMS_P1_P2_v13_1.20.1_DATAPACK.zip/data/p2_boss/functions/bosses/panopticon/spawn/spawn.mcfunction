#Spawn
summon slime ~ ~ ~ {Size: 15, Tags: ["adr_boss", "adr_hitbox", "panopticon", "no_id", "clockwise"],ArmorDropChances:[0f], DeathLootTable:"adr_boss:empty", NoAI: 1b, Silent: 1b, PersistenceRequired: 1b, Attributes: [{Name: "generic.max_health", Base: 1000}], Health: 1000, CustomName: "{\"text\": \"Panopticon\"}", Passengers: [{id: "minecraft:item_display",Tags:["adr_model","panopticon","no_id","aj.new","aj.panopticon.rig_entity","aj.panopticon.root","aj.rig_root"],Passengers:[{id:"minecraft:item_display",Tags:["aj.new","aj.panopticon.rig_entity","aj.panopticon.bone","aj.panopticon.bone.frame"],transformation:[-5.125f,0f,1.1379786002407855e-15f,0.004020785934522006f,0f,5.125f,0f,-2.2092156250000006f,-1.1379786002407855e-15f,0f,-5.125f,4.336808689942018e-19f,0f,0f,0f,1f],interpolation_duration:1,item_display:"head",item:{id:"minecraft:white_dye",Count:1b,tag:{CustomModelData:36}},CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"bone\",\"color\":\"white\"},\"[\",{\"text\":\"frame\",\"color\":\"yellow\"},\"]\"]]",height:94.74745f,width:61.54549f},{id:"minecraft:item_display",Tags:["aj.new","aj.panopticon.rig_entity","aj.panopticon.bone","aj.panopticon.bone.panel"],transformation:[-3.5355339059327378f,2.027898938363194f,-2.8961398266978455f,-2.6476296435150313f,0f,4.095760221444959f,2.8678821817552302f,-2.2092156250000006f,3.5355339059327373f,2.0278989383631942f,-2.896139826697846f,-2.6516504294495533f,0f,0f,0f,1f],interpolation_duration:1,item_display:"head",item:{id:"minecraft:white_dye",Count:1b,tag:{CustomModelData:37}},CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"bone\",\"color\":\"white\"},\"[\",{\"text\":\"panel\",\"color\":\"yellow\"},\"]\"]]",height:66.65255f,width:60.04549f},{id:"minecraft:item_display",Tags:["aj.new","aj.panopticon.rig_entity","aj.panopticon.bone","aj.panopticon.bone.panel5"],transformation:[-3.5355339059327378f,2.027898938363195f,2.896139826697844f,-2.6476296435150313f,0f,-4.095760221444957f,2.867882181755232f,-2.2092156250000006f,3.5355339059327373f,2.0278989383631956f,2.896139826697845f,-2.6516504294495533f,0f,0f,0f,1f],interpolation_duration:1,item_display:"head",item:{id:"minecraft:white_dye",Count:1b,tag:{CustomModelData:38}},CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"bone\",\"color\":\"white\"},\"[\",{\"text\":\"panel5\",\"color\":\"yellow\"},\"]\"]]",height:66.65255f,width:60.04549f},{id:"minecraft:item_display",Tags:["aj.new","aj.panopticon.rig_entity","aj.panopticon.bone","aj.panopticon.bone.panel2"],transformation:[3.535533611304911f,2.0278987693716166f,-2.896139585352861f,-2.6476296435150317f,2.775557330266428e-16f,4.095759880131608f,2.8678819427650484f,-2.2092156250000006f,3.535533611304913f,-2.0278987693716157f,2.8961395853528593f,2.651650429449553f,0f,0f,0f,1f],interpolation_duration:1,item_display:"head",item:{id:"minecraft:white_dye",Count:1b,tag:{CustomModelData:39}},CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"bone\",\"color\":\"white\"},\"[\",{\"text\":\"panel2\",\"color\":\"yellow\"},\"]\"]]",height:66.65255f,width:119.9545f},{id:"minecraft:item_display",Tags:["aj.new","aj.panopticon.rig_entity","aj.panopticon.bone","aj.panopticon.bone.panel6"],transformation:[3.5355336113049107f,2.027898769371617f,2.896139585352858f,-2.6476296435150317f,2.775557330266428e-16f,-4.095759880131603f,2.8678819427650497f,-2.2092156250000006f,3.5355336113049125f,-2.0278987693716166f,-2.8961395853528606f,2.651650429449553f,0f,0f,0f,1f],interpolation_duration:1,item_display:"head",item:{id:"minecraft:white_dye",Count:1b,tag:{CustomModelData:40}},CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"bone\",\"color\":\"white\"},\"[\",{\"text\":\"panel6\",\"color\":\"yellow\"},\"]\"]]",height:66.65255f,width:119.9545f},{id:"minecraft:item_display",Tags:["aj.new","aj.panopticon.rig_entity","aj.panopticon.bone","aj.panopticon.bone.panel3"],transformation:[3.5355339059327373f,-2.0278989383631947f,2.896139826697844f,2.655671215384075f,-6.123233995736766e-16f,4.095760221444958f,2.867882181755232f,-2.2092156250000006f,-3.535533905932737f,-2.0278989383631956f,2.896139826697845f,2.6516504294495538f,0f,0f,0f,1f],interpolation_duration:1,item_display:"head",item:{id:"minecraft:white_dye",Count:1b,tag:{CustomModelData:41}},CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"bone\",\"color\":\"white\"},\"[\",{\"text\":\"panel3\",\"color\":\"yellow\"},\"]\"]]",height:66.65255f,width:67.77049f},{id:"minecraft:item_display",Tags:["aj.new","aj.panopticon.rig_entity","aj.panopticon.bone","aj.panopticon.bone.panel7"],transformation:[3.5355339059327378f,-2.0278989383631942f,-2.8961398266978455f,2.655671215384075f,-6.123233995736765e-16f,-4.0957602214449595f,2.8678821817552302f,-2.2092156250000006f,-3.5355339059327373f,-2.027898938363194f,-2.896139826697846f,2.6516504294495538f,0f,0f,0f,1f],interpolation_duration:1,item_display:"head",item:{id:"minecraft:white_dye",Count:1b,tag:{CustomModelData:42}},CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"bone\",\"color\":\"white\"},\"[\",{\"text\":\"panel7\",\"color\":\"yellow\"},\"]\"]]",height:66.65255f,width:60.04549f},{id:"minecraft:item_display",Tags:["aj.new","aj.panopticon.rig_entity","aj.panopticon.bone","aj.panopticon.bone.panel4"],transformation:[-3.5355342005605634f,-2.0278991073547723f,2.896140068042831f,2.6556712153840754f,-2.7755577928593547e-16f,4.0957605627583105f,2.867882420745412f,-2.2092156250000006f,-3.5355342005605626f,2.0278991073547723f,-2.8961400680428318f,-2.6516504294495533f,0f,0f,0f,1f],interpolation_duration:1,item_display:"head",item:{id:"minecraft:white_dye",Count:1b,tag:{CustomModelData:43}},CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"bone\",\"color\":\"white\"},\"[\",{\"text\":\"panel4\",\"color\":\"yellow\"},\"]\"]]",height:66.65255f,width:120.0455f},{id:"minecraft:item_display",Tags:["aj.new","aj.panopticon.rig_entity","aj.panopticon.bone","aj.panopticon.bone.panel8"],transformation:[-3.5355342005605626f,-2.027899107354773f,-2.896140068042832f,2.6556712153840754f,-2.7755577928593547e-16f,-4.095760562758307f,2.867882420745413f,-2.2092156250000006f,-3.535534200560562f,2.027899107354773f,2.896140068042828f,-2.6516504294495533f,0f,0f,0f,1f],interpolation_duration:1,item_display:"head",item:{id:"minecraft:white_dye",Count:1b,tag:{CustomModelData:44}},CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"bone\",\"color\":\"white\"},\"[\",{\"text\":\"panel8\",\"color\":\"yellow\"},\"]\"]]",height:66.65255f,width:120.0455f},{id:"minecraft:item_display",Tags:["aj.new","aj.panopticon.rig_entity","aj.panopticon.bone","aj.panopticon.bone.upper_jaw"],transformation:[-0.15447823315536516f,0.7781985777888202f,-3.507520978730593f,0.012062942793656162f,0.027238769915092678f,3.5109144287659033f,0.7777518180778917f,-2.15625f,3.592708517556256f,0.006842122288512804f,-0.15671203038656528f,1.3793621934076024f,0f,0f,0f,1f],interpolation_duration:1,item_display:"head",item:{id:"minecraft:white_dye",Count:1b,tag:{CustomModelData:45}},CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"bone\",\"color\":\"white\"},\"[\",{\"text\":\"upper_jaw\",\"color\":\"yellow\"},\"]\"]]",height:34.5f,width:65.81089f},{id:"minecraft:item_display",Tags:["aj.new","aj.panopticon.rig_entity","aj.panopticon.bone","aj.panopticon.bone.lower_jaw"],transformation:[-0.14917222363141652f,0.764673187474881f,-3.4466755540709704f,0.021771692793656094f,0.039943970193624924f,3.4498955819329375f,0.7636588007620521f,-2.15625f,3.5302552227733615f,-0.006723175824735621f,-0.15428114585003647f,1.3793621934076024f,0f,0f,0f,1f],interpolation_duration:1,item_display:"head",item:{id:"minecraft:white_dye",Count:1b,tag:{CustomModelData:46}},CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"bone\",\"color\":\"white\"},\"[\",{\"text\":\"lower_jaw\",\"color\":\"yellow\"},\"]\"]]",height:55.5f,width:65.70451f},{id:"minecraft:item_display",Tags:["aj.new","aj.panopticon.rig_entity","aj.panopticon.bone","aj.panopticon.bone.mouth"],transformation:[0f,0f,-3.25f,-0.32543705720634375f,0f,3.25f,0f,-1.709700625f,3.25f,0f,0f,1.9055078184076024f,0f,0f,0f,1f],interpolation_duration:1,item_display:"head",item:{id:"minecraft:white_dye",Count:1b,tag:{CustomModelData:47}},CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"bone\",\"color\":\"white\"},\"[\",{\"text\":\"mouth\",\"color\":\"yellow\"},\"]\"]]",height:58.5f,width:62.27646f}],CustomName:"[{\"text\":\"[\",\"color\":\"gray\"},{\"text\":\"AJ\",\"color\":\"aqua\"},\"] \",[\"\",{\"text\":\"panopticon\",\"color\":\"light_purple\"},\".\",{\"text\":\"root\",\"color\":\"white\"}]]"}]}

#Initialize
execute as @e[type=slime,distance=..1,tag=panopticon,tag=no_id,limit=1] at @s run function p2_boss:bosses/panopticon/spawn/init

execute as @e[type=minecraft:item_display,tag=aj.panopticon.root,tag=aj.new,limit=1,distance=..0.1] run function animated_java:panopticon/zzzzzzzz/summon/as_root



#Anchors
setblock ~ ~ ~ netherrack

setblock ~ ~ ~1 crimson_hyphae

setblock ~ ~ ~-1 stripped_mangrove_wood

setblock ~1 ~ ~ netherrack

setblock ~-1 ~ ~ netherrack

setblock ~1 ~ ~1 stripped_mangrove_wood

setblock ~-1 ~ ~1 stripped_mangrove_wood

setblock ~1 ~ ~-1 crimson_hyphae

setblock ~-1 ~ ~-1 red_nether_bricks

setblock ~2 ~ ~ red_nether_brick_slab

setblock ~-2 ~ ~ red_nether_brick_slab

setblock ~ ~ ~2 mangrove_slab

setblock ~ ~ ~-2 mangrove_slab

setblock ~ ~2 ~ crimson_hyphae

setblock ~ ~1 ~ netherrack

setblock ~ ~1 ~1 red_nether_bricks

setblock ~ ~1 ~-1 netherrack

setblock ~1 ~1 ~ red_nether_bricks

setblock ~-1 ~1 ~ crimson_hyphae

setblock ~ ~3 ~ red_nether_bricks

setblock ~ ~4 ~ red_nether_brick_wall

setblock ~ ~15 ~ red_nether_bricks

setblock ~ ~16 ~ red_nether_brick_wall

setblock ~ ~17 ~ mangrove_fence

setblock ~ ~18 ~ red_nether_brick_wall

setblock ~ ~19 ~ red_nether_bricks

setblock ~ ~20 ~ crimson_hyphae

setblock ~ ~21 ~ crimson_hyphae

setblock ~ ~21 ~1 crimson_hyphae

setblock ~ ~21 ~-1 stripped_mangrove_wood

setblock ~1 ~21 ~ red_nether_bricks

setblock ~-1 ~21 ~ netherrack

setblock ~ ~22 ~ netherrack

setblock ~ ~22 ~1 stripped_mangrove_wood

setblock ~ ~22 ~-1 crimson_hyphae

setblock ~1 ~22 ~ netherrack

setblock ~-1 ~22 ~ crimson_hyphae

setblock ~ ~23 ~ netherrack

setblock ~ ~23 ~1 netherrack

setblock ~ ~23 ~-1 stripped_mangrove_wood

setblock ~1 ~23 ~ netherrack

setblock ~-1 ~23 ~ red_nether_bricks

setblock ~1 ~23 ~1 red_nether_bricks

setblock ~1 ~23 ~-1 crimson_hyphae

setblock ~-1 ~23 ~1 stripped_mangrove_wood

setblock ~-1 ~23 ~-1 netherrack

setblock ~ ~23 ~2 red_nether_brick_slab[type=top]

setblock ~ ~23 ~-2 red_nether_brick_slab[type=top]

setblock ~2 ~23 ~ mangrove_slab[type=top]

setblock ~-2 ~23 ~ mangrove_slab[type=top]

# P-2 Panopticon OST
function p2:music_panopticon_start
