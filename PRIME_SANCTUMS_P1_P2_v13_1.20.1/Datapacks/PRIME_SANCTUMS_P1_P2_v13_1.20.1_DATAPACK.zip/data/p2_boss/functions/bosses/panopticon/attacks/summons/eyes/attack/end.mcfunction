#Attack
scoreboard players set @s boss_attack 0

scoreboard players set @s boss_timer 0
