# Panopticon death sequence
scoreboard players add @s boss_timer 1

# Begin the suspended/shaking death state.
execute if score @s boss_timer matches 2 run function p2_boss:bosses/panopticon/death/start

# Keep the dying ambience while the prison shakes.
execute if score @s boss_timer matches 1..100 run playsound entity.husk.death hostile @a ~ ~ ~ 20 0 0

# Timed chat matching Sp_thisprison.ogg.
execute if score @s boss_timer matches 31 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"To hold...","color":"yellow","italic":true}]
execute if score @s boss_timer matches 58 run tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"ME?","color":"gold","bold":true}]

# Sp_thisprison.ogg is ~4.81 s. It begins at tick 2 and is fully over by ~tick 99.
# Only AFTER it finishes does Panopticon explode and release the yellow orb.
execute if score @s boss_timer matches 101.. run function p2_boss:bosses/panopticon/death/end
