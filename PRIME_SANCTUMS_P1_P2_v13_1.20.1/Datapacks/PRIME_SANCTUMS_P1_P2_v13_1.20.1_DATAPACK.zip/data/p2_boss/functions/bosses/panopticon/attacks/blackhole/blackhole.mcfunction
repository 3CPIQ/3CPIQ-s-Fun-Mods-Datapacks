#Blackhole
scoreboard players add @s boss_timer 1

#Visual
particle dust 0 0 0 1 ^ ^ ^ 1 1 1 0 100 force

particle dust 0.635 0 1 1 ^ ^ ^ 1.5 1.5 1.5 1 50 normal

particle portal ^ ^ ^2 1.5 1.5 1.5 10 10 normal

playsound minecraft:entity.bee.pollinate hostile @a ~ ~ ~ 2 1 0

#Explode
execute positioned ~-1.5 ~-1.5 ~-1.5 if entity @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,type=!ultracraft:shotgun_pellet,type=!ultracraft:thrown_machinesword,type=!ultracraft:ejected_core,type=!ultracraft:magnet,type=!ultracraft:soap,type=!ultracraft:retaliation,type=!ultracraft:interruptable_charge,dx=2,dy=2,dz=2,tag=!panopticon] positioned ~1.5 ~1.5 ~1.5 run function p2_boss:bosses/panopticon/attacks/blackhole/hit

execute if score @s boss_timer matches 1000 run function p2_boss:bosses/panopticon/attacks/blackhole/hit

#Movement
execute anchored eyes facing entity @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,type=!ultracraft:shotgun_pellet,type=!ultracraft:thrown_machinesword,type=!ultracraft:ejected_core,type=!ultracraft:magnet,type=!ultracraft:soap,type=!ultracraft:retaliation,type=!ultracraft:interruptable_charge,tag=!panopticon,sort=nearest,distance=..50,limit=1] eyes positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^7 facing entity @s eyes facing ^ ^ ^-1 positioned as @s run tp @s ^ ^ ^.2 ~ ~

execute if entity @s[tag=phase2] run tp @s ^ ^ ^.2
