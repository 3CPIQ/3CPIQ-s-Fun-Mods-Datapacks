#Divine Beam
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1 run data merge entity @s {transformation: {left_rotation: [0f, 0f, 0f, 1f], right_rotation: [0f, 0f, 0f, 1f], translation: [0f, 0f, 0f], scale: [4f, 10f, 4f]}, start_interpolation: 0, interpolation_duration: 1}

execute if score @s boss_timer matches 55 run data merge entity @s {transformation: {left_rotation: [0f, 0f, 0f, 1f], right_rotation: [0f, 0f, 0f, 1f], translation: [0f, 0f, 0f], scale: [0f, 10f, 0f]}, start_interpolation: 0, interpolation_duration: 1}

execute positioned ~-5.5 ~-50 ~-5.5 if entity @e[type=!#adr_boss:non_living,dx=10,dy=100,dz=10,tag=!panopticon] run function p2_boss:bosses/panopticon/attacks/divine_lights/hit

execute if score @s boss_timer matches 60.. run kill @s
