#Projectile
scoreboard players add @s boss_timer 1

#Visual
particle dust 0 0.969 1 0.5 ^ ^ ^ 0.25 0.25 0.25 0 20 force

#Explode
execute positioned ~-.5 ~-.5 ~-.5 if entity @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,type=!ultracraft:shotgun_pellet,type=!ultracraft:thrown_machinesword,type=!ultracraft:ejected_core,type=!ultracraft:magnet,type=!ultracraft:soap,type=!ultracraft:retaliation,type=!ultracraft:interruptable_charge,dx=0,tag=!panopticon] positioned ~.5 ~.5 ~.5 run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/hit

execute unless block ~ ~ ~ #adr_boss:pseudo_air run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/hit

execute if score @s boss_timer matches 100 run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/hit

#Movement
execute if score @s boss_timer matches 5.. anchored eyes facing entity @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,type=!ultracraft:shotgun_pellet,type=!ultracraft:thrown_machinesword,type=!ultracraft:ejected_core,type=!ultracraft:magnet,type=!ultracraft:soap,type=!ultracraft:retaliation,type=!ultracraft:interruptable_charge,tag=!panopticon,sort=nearest,distance=..50,limit=1] eyes positioned ^ ^ ^1 rotated as @s positioned ^ ^ ^7 facing entity @s eyes facing ^ ^ ^-1 positioned as @s run tp @s ^ ^ ^ ~ ~

execute if score @s boss_timer matches 1.. run tp @s ^ ^ ^0.5

execute if score @s boss_timer matches 20.. run tp @s ^ ^ ^1
