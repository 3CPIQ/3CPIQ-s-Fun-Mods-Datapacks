#Death
particle block nether_wart_block ~ ~ ~ 1 1 1 1 100 force

playsound minecraft:block.stone.break hostile @a ~ ~ ~ 5 0 0

tp @e[type=slime,tag=!panopticon,name="Mini Malicious",distance=..2] ~ ~-1000 ~

kill @s
