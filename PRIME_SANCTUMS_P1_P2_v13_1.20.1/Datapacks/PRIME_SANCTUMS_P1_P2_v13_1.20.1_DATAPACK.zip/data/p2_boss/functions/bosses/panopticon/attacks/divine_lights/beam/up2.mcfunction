#Divine light
scoreboard players add @s boss_timer 1

#Visual
tp @s ~ ~.04 ~ ~20 ~

execute if score @s boss_timer matches 60.. run kill @s
