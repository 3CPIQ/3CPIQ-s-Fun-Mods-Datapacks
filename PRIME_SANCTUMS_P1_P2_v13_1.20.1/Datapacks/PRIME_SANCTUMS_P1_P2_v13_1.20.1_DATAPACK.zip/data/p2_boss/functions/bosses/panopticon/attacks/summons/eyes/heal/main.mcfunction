#Heal
scoreboard players add @s boss_hp 1

execute if score @s boss_hp matches 1 run tag @s remove in_combat

execute if score @s boss_hp matches 1 run function p2_boss:bosses/panopticon/attacks/summons/eyes/attack/end

execute anchored eyes facing entity @e[type=slime,tag=adr_boss,tag=adr_hitbox,tag=panopticon] eyes run function p2_boss:bosses/panopticon/attacks/summons/eyes/heal/ray

particle happy_villager ~ ~.5 ~ 0.2 0.2 0.2 0 1 force

execute if score @s boss_hp matches 100.. run function p2_boss:bosses/panopticon/attacks/summons/eyes/heal/end
