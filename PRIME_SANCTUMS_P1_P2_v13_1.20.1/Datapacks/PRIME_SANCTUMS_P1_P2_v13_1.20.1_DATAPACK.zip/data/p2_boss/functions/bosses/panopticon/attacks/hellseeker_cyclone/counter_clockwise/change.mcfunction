#Change
tag @s add clockwise

tag @s remove counter_clockwise

tag @s remove was_counter_clockwise
