#Initialize
scoreboard players operation @s boss_id = @e[type=slime,tag=adr_hitbox,tag=panopticon,tag=!panopticon_summon,sort=nearest,limit=1,distance=..20] boss_id

effect give @s invisibility infinite 0 true

effect give @s fire_resistance infinite 0 true

tag @s remove no_id

scoreboard players set @s boss_attack 0

scoreboard players set @s boss_timer 0

scoreboard players set @s boss_hp 0

scoreboard players set @s boss_stamina 0

scoreboard players operation @e[type=item_display,distance=..10,tag=adr_model,tag=p2_boss_eyes,tag=no_id,limit=1] boss_id = @s boss_id

tag @e[type=item_display,distance=..10,tag=adr_model,tag=p2_boss_eyes,tag=no_id,limit=1] remove no_id

#Attributes based on Difficulty
execute if score $difficulty boss_id matches 1 run attribute @s generic.attack_damage base set 5

execute if score $difficulty boss_id matches 2 run attribute @s generic.attack_damage base set 10

execute if score $difficulty boss_id matches 3 run attribute @s generic.attack_damage base set 15
