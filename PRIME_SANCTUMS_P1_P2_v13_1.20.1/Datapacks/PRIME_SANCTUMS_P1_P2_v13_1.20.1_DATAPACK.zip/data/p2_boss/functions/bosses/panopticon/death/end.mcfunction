# Panopticon finally breaks AFTER "This prison... To hold... ME?" finishes.
particle block obsidian ~ ~ ~ 2.5 2.5 2.5 0.25 250 force
particle dust 1.000 0.780 0.120 1 ~ ~ ~ 2.5 2.5 2.5 0.15 180 force

playsound entity.generic.explode hostile @a ~ ~ ~ 10 0 0
playsound entity.wither.death hostile @a ~ ~ ~ 10 0 0

# The yellow Sisyphus orb appears only now, above the shattered prison.
function p2:release_sisyphus

fill ~3 ~-12 ~3 ~-3 ~11 ~-3 air

kill @e[type=slime,tag=panopticon_summon,distance=..100]
kill @e[type=marker,tag=p2_boss_blackhole,distance=..100]

function animated_java:panopticon/remove/this
