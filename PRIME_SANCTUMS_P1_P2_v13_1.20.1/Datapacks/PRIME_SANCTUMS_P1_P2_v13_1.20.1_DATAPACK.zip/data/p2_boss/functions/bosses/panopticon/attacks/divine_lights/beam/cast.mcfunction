#Beam
summon item_display ~ ~ ~ {Tags: ["p2_boss_beam", "panopticon","init"], billboard: "fixed", item: {id: "minecraft:black_dye", Count: 1, tag: {CustomModelData: 5}}, transformation: {left_rotation: [0f, 0f, 0f, 1f], right_rotation: [0f, 0f, 0f, 1f], translation: [0f, 0f, 0f], scale: [0f, 50f, 0f]}, shadow_strength: 0, CustomName: "{\"text\": \"Panopticon\"}"}

playsound minecraft:entity.evoker.prepare_summon hostile @a ~ ~ ~ 10 2 0

scoreboard players operation @e[type=item_display,tag=p2_boss_beam,tag=init,distance=..4,sort=nearest,limit=1] boss_attack = @s boss_attack

tag @e[type=item_display,tag=p2_boss_beam,tag=init,distance=..4,sort=nearest,limit=1] remove init

kill @s
