#Damage
execute store result score $damage boss_id run attribute @s generic.attack_damage get 100

playsound minecraft:entity.player.attack.weak hostile @a ~ ~ ~ 5 2 0

execute positioned ~-.5 ~-.5 ~-.5 as @e[type=!#adr_boss:non_living,dx=0,tag=!panopticon] run function adr_boss:main/damage

particle dust 1 1 0 0.5 ~ ~ ~ 0.2 0.2 0.2 1 20 force

# P1 COMPLETE DESTRUCTIVE PATCH
function p2:destruction/r1
