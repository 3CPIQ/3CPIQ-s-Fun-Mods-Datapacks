# Panopticon enters its dead-but-not-yet-exploded state.
function animated_java:panopticon/animations/pause_all
function animated_java:panopticon/animations/shake/play

# Sisyphus speaks FROM INSIDE the still-shaking Panopticon.
execute as @a at @s run playsound minecraft:boss.sisyphus.thisprison voice @s ~ ~ ~ 0.80 1 0
tellraw @a [{"text":"Sisyphus Prime: ","color":"gold","bold":true},{"text":"This prison…","color":"yellow","italic":true}]
