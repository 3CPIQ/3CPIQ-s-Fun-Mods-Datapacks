#Heal Ray
execute positioned ^ ^ ^1 positioned ~-.5 ~-.5 ~-.5 unless entity @e[type=slime,tag=adr_boss,tag=adr_hitbox,tag=panopticon,dx=0] positioned ~.5 ~.5 ~.5 run function p2_boss:bosses/panopticon/attacks/summons/eyes/heal/ray

particle happy_villager ^ ^ ^1 0.2 0.2 0.2 0 1 force
