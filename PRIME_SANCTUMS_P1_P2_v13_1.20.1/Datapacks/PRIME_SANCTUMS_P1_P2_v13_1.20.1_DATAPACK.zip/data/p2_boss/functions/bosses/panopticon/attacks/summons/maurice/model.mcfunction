#Death
execute on vehicle run scoreboard players set $is_alive boss_id 1

execute unless entity @s[tag=dead] if score $is_alive boss_id matches 0 run tag @s add dead

execute if entity @s[tag=dead] run function p2_boss:bosses/panopticon/attacks/summons/maurice/death

scoreboard players set $is_alive boss_id 0
