#Damaging wave
scoreboard players add @s boss_timer 1

#Visual
particle dust 1 1 1 1 ^ ^ ^ 0.75 0.75 0.75 0 10 force

execute if score @s boss_timer matches 1..20 run tp @s ^ ^ ^-.5

execute if score @s boss_timer matches 21..40 run tp @s ^ ^ ^-.25

execute if score @s boss_timer matches 41..60 run tp @s ^ ^ ^-.125

execute if score @s boss_timer matches 40 run kill @s
