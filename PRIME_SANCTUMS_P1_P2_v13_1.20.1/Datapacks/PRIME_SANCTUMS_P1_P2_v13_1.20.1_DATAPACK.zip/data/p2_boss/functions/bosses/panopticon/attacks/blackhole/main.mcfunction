#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1..10 run playsound entity.husk.death hostile @a ~ ~ ~ 20 0 0

execute if score @s boss_timer matches 1 run function p2_boss:bosses/panopticon/attacks/blackhole/wave/vertical

execute if score @s boss_timer matches 1 on passengers if entity @s[type=item_display,tag=adr_model,tag=panopticon] run function animated_java:panopticon/animations/open/play

#Make start up and recovery faster on boss difficulty
scoreboard players add @s[tag=diff_3] boss_timer 1

#Summon blackholes
execute if score @s boss_timer matches 20 positioned ~ ~4 ~ run function p2_boss:bosses/panopticon/attacks/blackhole/summon

#Make recover faster on modded and boss difficulty
execute if score @s[tag=diff_2] boss_timer matches 20.. run scoreboard players add @s boss_timer 1

#End
execute if score @s boss_timer matches 40.. run function p2_boss:bosses/panopticon/attacks/blackhole/end
