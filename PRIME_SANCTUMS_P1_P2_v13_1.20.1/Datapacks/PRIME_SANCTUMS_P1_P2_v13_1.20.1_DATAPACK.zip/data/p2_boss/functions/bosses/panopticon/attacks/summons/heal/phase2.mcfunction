#Heal
execute if score @s boss_timer matches 20..144 run playsound entity.husk.death hostile @a ~ ~ ~ 20 0 0

#Heal from summons
execute if score @s boss_timer matches 20..100 run effect give @s resistance 1 3 true

execute if score @s boss_timer matches 20 run scoreboard players operation $temp boss_id = @s boss_id

execute if score @s boss_timer matches 20 as @e[type=slime,tag=panopticon_summon] if score @s boss_id = $temp boss_id run tag @s add heal

execute if score @s boss_timer matches 120 run function p2_boss:bosses/panopticon/attacks/summons/heal/heal_amount

#Summons
execute if score @s boss_timer matches 120 positioned ^ ^ ^2 rotated ~90 -90 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/maurice/spawn

execute if score @s boss_timer matches 122 positioned ^ ^ ^2 rotated ~90 -60 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 124 positioned ^ ^ ^2 rotated ~90 -30 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 126 positioned ^ ^ ^2 rotated ~90 0 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 128 positioned ^ ^ ^2 rotated ~90 30 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 130 positioned ^ ^ ^2 rotated ~90 60 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/maurice/spawn

execute if score @s boss_timer matches 132 positioned ^ ^ ^2 rotated ~90 90 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 134 positioned ^ ^ ^2 rotated ~90 120 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/maurice/spawn

execute if score @s boss_timer matches 136 positioned ^ ^ ^2 rotated ~90 150 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 138 positioned ^ ^ ^2 rotated ~90 180 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 140 positioned ^ ^ ^2 rotated ~90 210 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 142 positioned ^ ^ ^2 rotated ~90 240 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 144 run scoreboard players operation $temp boss_id = @s boss_id

execute if score @s boss_timer matches 144 as @e[type=slime,tag=panopticon_summon,distance=..20] if score @s boss_id = $temp boss_id run tag @s remove spawned

#Make recover faster on modded difficulty
execute if score @s[tag=diff_2] boss_timer matches 144.. run scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 160.. run function p2_boss:bosses/panopticon/attacks/summons/end
