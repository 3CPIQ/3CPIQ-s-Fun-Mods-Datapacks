#Heal
scoreboard players operation $temp boss_id = @s boss_id

execute as @e[type=slime,tag=adr_boss,tag=adr_hitbox,tag=panopticon,distance=..50] if score @s boss_id = $temp boss_id run scoreboard players add @s boss_stamina_max 1

execute on passengers run tag @s add dead

tp @s ~ ~-1000 ~

kill @s
