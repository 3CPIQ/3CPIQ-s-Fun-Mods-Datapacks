#End
execute if entity @s[tag=was_clockwise] run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/clockwise/change

execute if entity @s[tag=was_counter_clockwise] run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/counter_clockwise/change

execute on passengers if entity @s[type=item_display,tag=adr_model,tag=panopticon] run function animated_java:panopticon/animations/close/play

scoreboard players set @s boss_attack 0

scoreboard players set @s boss_timer 0
