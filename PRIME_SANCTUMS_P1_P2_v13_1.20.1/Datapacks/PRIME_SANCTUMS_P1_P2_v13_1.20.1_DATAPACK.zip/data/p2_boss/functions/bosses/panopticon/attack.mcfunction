#Attacks
scoreboard players set $min boss_rng 1

scoreboard players set $max boss_rng 3

function adr_boss:rng/rng_load

#Blackhole
execute if score $random boss_rng matches 1 if entity @s[tag=!has_blackhole] unless score @s boss_previous_attack matches 1 run scoreboard players set @s boss_attack 1

execute if score $random boss_rng matches 1 unless entity @s[tag=!has_blackhole] run scoreboard players set $random boss_rng 2

execute if score $random boss_rng matches 1 if score @s boss_previous_attack matches 1 run scoreboard players set $random boss_rng 2

#Divine Lights
execute if score $random boss_rng matches 2 unless score @s boss_previous_attack matches 2 run scoreboard players set @s boss_attack 2

execute if score $random boss_rng matches 2 if score @s boss_previous_attack matches 2 run scoreboard players set $random boss_rng 3

#Hellseeker Cyclone
execute if score $random boss_rng matches 3 unless score @s boss_previous_attack matches 3 run scoreboard players set @s boss_attack 3

execute if score $random boss_rng matches 3 if score @s boss_previous_attack matches 3 run scoreboard players set @s boss_attack 2

scoreboard players operation @s boss_previous_attack = @s boss_attack
