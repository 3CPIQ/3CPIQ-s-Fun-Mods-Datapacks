#Heal based on how many minions
execute if score @s boss_stamina_max matches 1 run effect give @s instant_health 1 2 true

execute if score @s boss_stamina_max matches 2 run effect give @s instant_health 1 4 true

execute if score @s boss_stamina_max matches 3 run effect give @s instant_health 1 6 true

execute if score @s boss_stamina_max matches 4 run effect give @s instant_health 1 8 true

execute if score @s boss_stamina_max matches 5 run effect give @s instant_health 1 10 true

execute if score @s boss_stamina_max matches 6 run effect give @s instant_health 1 12 true

execute if score @s boss_stamina_max matches 7 run effect give @s instant_health 1 14 true

execute if score @s boss_stamina_max matches 8 run effect give @s instant_health 1 16 true

execute if score @s boss_stamina_max matches 9 run effect give @s instant_health 1 18 true

execute if score @s boss_stamina_max matches 10 run effect give @s instant_health 1 20 true

execute if score @s boss_stamina_max matches 11 run effect give @s instant_health 1 22 true

execute if score @s boss_stamina_max matches 12 run effect give @s instant_health 1 24 true
