#Movement
scoreboard players set @s boss_stamina 0

scoreboard players set $min boss_rng 1

scoreboard players set $max boss_rng 7

function adr_boss:rng/rng_load

#Direction
execute if score $random boss_rng matches 1 rotated ~ 0 run function p2_boss:bosses/panopticon/attacks/summons/eyes/move/ray

execute if score $random boss_rng matches 2 rotated ~180 0 run function p2_boss:bosses/panopticon/attacks/summons/eyes/move/ray

execute if score $random boss_rng matches 3 rotated ~90 0 run function p2_boss:bosses/panopticon/attacks/summons/eyes/move/ray

execute if score $random boss_rng matches 4 rotated ~-90 0 run function p2_boss:bosses/panopticon/attacks/summons/eyes/move/ray

execute if score $random boss_rng matches 5 rotated ~ 90 run function p2_boss:bosses/panopticon/attacks/summons/eyes/move/ray

execute if score $random boss_rng matches 6 rotated ~ -90 run function p2_boss:bosses/panopticon/attacks/summons/eyes/move/ray

execute if score $random boss_rng matches 7 run scoreboard players add @s boss_attack 10
