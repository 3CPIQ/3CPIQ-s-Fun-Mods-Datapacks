#Heal based on how many minions
execute if score @s boss_stamina_max matches 1 run effect give @s instant_health 1 3 true

execute if score @s boss_stamina_max matches 2 run effect give @s instant_health 1 6 true

execute if score @s boss_stamina_max matches 3 run effect give @s instant_health 1 9 true

execute if score @s boss_stamina_max matches 4 run effect give @s instant_health 1 12 true

execute if score @s boss_stamina_max matches 5 run effect give @s instant_health 1 15 true

execute if score @s boss_stamina_max matches 6 run effect give @s instant_health 1 18 true

execute if score @s boss_stamina_max matches 7 run effect give @s instant_health 1 21 true

execute if score @s boss_stamina_max matches 8 run effect give @s instant_health 1 24 true

execute if score @s boss_stamina_max matches 9 run effect give @s instant_health 1 27 true

execute if score @s boss_stamina_max matches 10 run effect give @s instant_health 1 30 true

execute if score @s boss_stamina_max matches 11 run effect give @s instant_health 1 33 true

execute if score @s boss_stamina_max matches 12 run effect give @s instant_health 1 36 true
