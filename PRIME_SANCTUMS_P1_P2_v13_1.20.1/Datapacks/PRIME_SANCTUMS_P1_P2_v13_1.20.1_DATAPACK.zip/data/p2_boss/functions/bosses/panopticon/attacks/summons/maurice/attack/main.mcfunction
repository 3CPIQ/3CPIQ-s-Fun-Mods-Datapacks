#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1..50 run tp @s ~ ~ ~ facing entity @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,type=!ultracraft:shotgun_pellet,type=!ultracraft:thrown_machinesword,type=!ultracraft:ejected_core,type=!ultracraft:magnet,type=!ultracraft:soap,type=!ultracraft:retaliation,type=!ultracraft:interruptable_charge,distance=..30,tag=!panopticon,sort=nearest,limit=1] eyes

execute if score @s boss_timer matches 1 run playsound minecraft:entity.evoker.prepare_attack hostile @a ~ ~ ~ 10 0.7 0

execute if score @s boss_timer matches 1 run playsound minecraft:entity.illusioner.prepare_blindness hostile @a ~ ~ ~ 10 0.7 0

execute if score @s boss_timer matches 1..5 anchored eyes run particle dust 1 0.769 0 0.2 ^ ^ ^1 0 0 0 0 1 force

execute if score @s boss_timer matches 6..10 anchored eyes run particle dust 1 0.769 0 0.4 ^ ^ ^1 0 0 0 0 1 force

execute if score @s boss_timer matches 11..15 anchored eyes run particle dust 1 0.769 0 0.6 ^ ^ ^1 0 0 0 0 1 force

execute if score @s boss_timer matches 16..20 anchored eyes run particle dust 1 0.769 0 0.8 ^ ^ ^1 0 0 0 0 1 force

execute if score @s boss_timer matches 21..25 anchored eyes run particle dust 1 0.769 0 1.0 ^ ^ ^1 0 0 0 0 1 force

execute if score @s boss_timer matches 26..30 anchored eyes run particle dust 1 0.769 0 1.2 ^ ^ ^1 0 0 0 0 1 force

execute if score @s boss_timer matches 31..35 anchored eyes run particle dust 1 0.769 0 1.4 ^ ^ ^1 0 0 0 0 1 force

execute if score @s boss_timer matches 36..40 anchored eyes run particle dust 1 0.769 0 1.6 ^ ^ ^1 0 0 0 0 1 force

execute if score @s boss_timer matches 41..45 anchored eyes run particle dust 1 0.769 0 1.8 ^ ^ ^1 0 0 0 0 1 force

execute if score @s boss_timer matches 46..50 anchored eyes run particle dust 1 0.769 0 2.0 ^ ^ ^1 0 0 0 0 1 force

execute if score @s boss_timer matches 54..55 anchored eyes run particle dust 1 0.769 0 2.2 ^ ^ ^1 0 0 0 0 1 force

execute if score @s boss_timer matches 56..58 anchored eyes run function p2_boss:bosses/panopticon/attacks/summons/maurice/attack/laser

execute if score @s boss_timer matches 59 anchored eyes run function p2_boss:bosses/panopticon/attacks/summons/maurice/attack/shoot

execute if score @s boss_timer matches 60 run function p2_boss:bosses/panopticon/attacks/summons/maurice/attack/end
