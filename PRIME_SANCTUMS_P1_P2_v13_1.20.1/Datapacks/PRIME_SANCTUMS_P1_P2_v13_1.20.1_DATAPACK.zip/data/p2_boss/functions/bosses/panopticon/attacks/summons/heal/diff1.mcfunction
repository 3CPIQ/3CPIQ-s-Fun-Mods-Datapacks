#Heal based on how many minions
execute if score @s boss_stamina_max matches 1 run effect give @s instant_health 1 1 true

execute if score @s boss_stamina_max matches 2 run effect give @s instant_health 1 2 true

execute if score @s boss_stamina_max matches 3 run effect give @s instant_health 1 3 true

execute if score @s boss_stamina_max matches 4 run effect give @s instant_health 1 4 true

execute if score @s boss_stamina_max matches 5 run effect give @s instant_health 1 5 true

execute if score @s boss_stamina_max matches 6 run effect give @s instant_health 1 6 true

execute if score @s boss_stamina_max matches 7 run effect give @s instant_health 1 7 true

execute if score @s boss_stamina_max matches 8 run effect give @s instant_health 1 8 true

execute if score @s boss_stamina_max matches 9 run effect give @s instant_health 1 9 true

execute if score @s boss_stamina_max matches 10 run effect give @s instant_health 1 10 true

execute if score @s boss_stamina_max matches 11 run effect give @s instant_health 1 11 true

execute if score @s boss_stamina_max matches 12 run effect give @s instant_health 1 12 true
