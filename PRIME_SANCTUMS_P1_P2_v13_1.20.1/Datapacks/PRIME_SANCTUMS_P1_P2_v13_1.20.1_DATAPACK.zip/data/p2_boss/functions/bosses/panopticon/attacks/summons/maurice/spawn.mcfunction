#Spawn
summon slime ~ ~ ~ {Size: 1, Tags: ["p2_boss_maurice", "adr_hitbox", "panopticon", "panopticon_summon", "no_id", "spawned"], DeathLootTable:"adr_boss:empty", NoAI: 1b, Silent: 1b, PersistenceRequired: 1b, Attributes: [{Name: "generic.max_health", Base: 2}], Health: 2, CustomName: "{\"text\": \"Mini Malicious\"}", Passengers: [{id: "minecraft:item_display", Tags: ["adr_model", "p2_boss_maurice", "no_id"], item: {id: "minecraft:black_dye", Count: 1, tag: {CustomModelData: 7, billboard: "fixed"}}}]}

#Initialize
execute as @e[type=slime,distance=..1,tag=p2_boss_maurice,tag=no_id,limit=1] at @s run function p2_boss:bosses/panopticon/attacks/summons/maurice/init

particle reverse_portal ~ ~ ~ 0.5 0.5 0.5 1 50 force

particle flash ~ ~ ~ 0 0 0 1 0 force

playsound block.honey_block.fall hostile @a ~ ~ ~ 10 0 0
