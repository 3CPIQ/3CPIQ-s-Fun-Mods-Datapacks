#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1..10 run playsound entity.husk.death hostile @a ~ ~ ~ 20 0 0

execute if score @s boss_timer matches 1 run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/wave/vertical

execute if score @s boss_timer matches 1 on passengers if entity @s[type=item_display,tag=adr_model,tag=panopticon] run function animated_java:panopticon/animations/open/play

#Make start up faster on boss difficulty
execute if score @s[tag=diff_3] boss_timer matches 1..20 run scoreboard players add @s boss_timer 1

#Check which way intitally going and go reverse
execute if entity @s[tag=clockwise] run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/clockwise/main

execute if entity @s[tag=counter_clockwise] run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/counter_clockwise/main

#Make recover faster on modded and boss difficulty
execute if score @s[tag=!phase2,tag=diff_2] boss_timer matches 80.. run scoreboard players add @s boss_timer 1

execute if score @s[tag=phase2,tag=diff_2] boss_timer matches 105.. run scoreboard players add @s boss_timer 1

execute if score @s[tag=!phase2,tag=diff_3] boss_timer matches 80.. run scoreboard players add @s boss_timer 1

execute if score @s[tag=phase2,tag=diff_3] boss_timer matches 105.. run scoreboard players add @s boss_timer 1

#Shoot more on phase 2 before ending
execute if score @s[tag=!phase2] boss_timer matches 100.. run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/end

execute if score @s[tag=phase2] boss_timer matches 120.. run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/end
