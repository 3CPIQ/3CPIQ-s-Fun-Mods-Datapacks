#Aim
execute positioned ^ ^ ^.5 if block ~ ~ ~ #adr_boss:pseudo_air positioned ~-.5 ~-.5 ~-.5 unless entity @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,tag=!panopticon,dx=0] positioned ~.5 ~.5 ~.5 run function p2_boss:bosses/panopticon/attacks/summons/eyes/attack/aim

particle dust 1 1 0 0.2 ~ ~ ~ 0 0 0 0 1 force
