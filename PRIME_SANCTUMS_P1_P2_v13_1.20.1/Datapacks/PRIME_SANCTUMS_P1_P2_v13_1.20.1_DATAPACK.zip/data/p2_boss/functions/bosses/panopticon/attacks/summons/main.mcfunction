#Attack
scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 1..10 run playsound entity.husk.death hostile @a ~ ~ ~ 20 0 0

execute if score @s boss_timer matches 1 on passengers if entity @s[type=item_display,tag=adr_model,tag=panopticon] run function animated_java:panopticon/animations/open/play

#Make everything faster on boss difficulty
scoreboard players add @s[tag=diff_3] boss_timer 1

#Check for living summons
execute if score @s boss_timer matches 20 run scoreboard players operation $temp boss_id = @s boss_id

execute if score @s boss_timer matches 20 as @e[type=slime,tag=panopticon_summon] if score @s boss_id = $temp boss_id run scoreboard players add $summons boss_id 1

execute if score @s boss_timer matches 20 if score $summons boss_id matches 1.. run tag @s add heal

execute if score @s boss_timer matches 20 run scoreboard players set $summons boss_id 0

#Heal first or summon right away
execute if score @s[tag=heal] boss_timer matches 20.. anchored eyes run function p2_boss:bosses/panopticon/attacks/summons/heal/main

execute if score @s[tag=!heal] boss_timer matches 20.. anchored eyes run function p2_boss:bosses/panopticon/attacks/summons/summon/main
