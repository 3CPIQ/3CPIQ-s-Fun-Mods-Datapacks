#Vanilla Difficulty
attribute @s generic.max_health base set 300

attribute @s generic.attack_damage base set 10

attribute @s generic.armor base set 10

attribute @s generic.armor_toughness base set 10

tag @s add diff_1
