#Damage
scoreboard players operation $damage boss_id = @s boss_attack

particle soul_fire_flame ^ ^ ^ 0.2 0.2 0.2 0.1 10 force

playsound minecraft:entity.evoker.cast_spell hostile @a ~ ~ ~ 5 2 0

execute positioned ~-.5 ~-.5 ~-.5 as @e[type=!#adr_boss:non_living,dx=0,tag=!panopticon] run function adr_boss:main/damage

kill @s

# P1 COMPLETE DESTRUCTIVE PATCH
function p2:destruction/r1
