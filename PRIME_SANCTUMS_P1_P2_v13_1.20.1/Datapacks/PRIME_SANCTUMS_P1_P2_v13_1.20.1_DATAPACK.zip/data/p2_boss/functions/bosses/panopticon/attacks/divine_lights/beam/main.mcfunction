#Divine light
scoreboard players add @s boss_timer 1

tp @s ~ ~ ~ ~20 ~

#Beam
execute if score @s boss_timer matches 60.. run function p2_boss:bosses/panopticon/attacks/divine_lights/beam/cast
