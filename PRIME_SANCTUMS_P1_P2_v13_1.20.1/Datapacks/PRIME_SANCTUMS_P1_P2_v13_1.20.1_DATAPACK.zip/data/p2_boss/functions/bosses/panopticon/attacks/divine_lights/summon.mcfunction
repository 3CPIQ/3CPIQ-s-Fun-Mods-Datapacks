#Summon virtue circles
summon item_display ~ ~ ~ {Tags: ["p2_boss_divine_light","center", "panopticon","init"], billboard: "fixed", item: {id: "minecraft:black_dye", Count: 1, tag: {CustomModelData: 2}}, transformation: {left_rotation: [0f, 0f, 0f, 1f], right_rotation: [0f, 0f, 0f, 1f], translation: [0f, 0f, 0f], scale: [5f, 1f, 5f]}, CustomName: "{\"text\": \"Panopticon\"}"}

summon item_display ~ ~.5 ~ {Tags: ["p2_boss_divine_light", "panopticon","up"], billboard: "fixed", item: {id: "minecraft:black_dye", Count: 1, tag: {CustomModelData: 3}}, transformation: {left_rotation: [0f, 0f, 0f, 1f], right_rotation: [0f, 0f, 0f, 1f], translation: [0f, 0f, 0f], scale: [5f, 1f, 5f]}, CustomName: "{\"text\": \"Panopticon\"}"}

summon item_display ~ ~-.5 ~ {Tags: ["p2_boss_divine_light", "panopticon","down"], billboard: "fixed", item: {id: "minecraft:black_dye", Count: 1, tag: {CustomModelData: 3}}, transformation: {left_rotation: [0f, 0f, 0f, 1f], right_rotation: [0f, 0f, 0f, 1f], translation: [0f, 0f, 0f], scale: [5f, 1f, 5f]}, CustomName: "{\"text\": \"Panopticon\"}"}

summon item_display ~ ~1 ~ {Tags: ["p2_boss_divine_light", "panopticon","up2"], billboard: "fixed", item: {id: "minecraft:black_dye", Count: 1, tag: {CustomModelData: 4}}, transformation: {left_rotation: [0f, 0f, 0f, 1f], right_rotation: [0f, 0f, 0f, 1f], translation: [0f, 0f, 0f], scale: [5f, 1f, 5f]}, CustomName: "{\"text\": \"Panopticon\"}"}

summon item_display ~ ~-1 ~ {Tags: ["p2_boss_divine_light", "panopticon","down2"], billboard: "fixed", item: {id: "minecraft:black_dye", Count: 1, tag: {CustomModelData: 4}}, transformation: {left_rotation: [0f, 0f, 0f, 1f], right_rotation: [0f, 0f, 0f, 1f], translation: [0f, 0f, 0f], scale: [5f, 1f, 5f]}, CustomName: "{\"text\": \"Panopticon\"}"}

playsound minecraft:entity.evoker.prepare_attack hostile @a ~ ~ ~ 50 0.75 0

execute store result score @e[type=item_display,tag=p2_boss_divine_light,tag=init,distance=..30,sort=nearest,limit=1] boss_attack run attribute @s generic.attack_damage get 300

tag @e[type=item_display,tag=p2_boss_divine_light,tag=init,distance=..30,sort=nearest,limit=1] remove init
