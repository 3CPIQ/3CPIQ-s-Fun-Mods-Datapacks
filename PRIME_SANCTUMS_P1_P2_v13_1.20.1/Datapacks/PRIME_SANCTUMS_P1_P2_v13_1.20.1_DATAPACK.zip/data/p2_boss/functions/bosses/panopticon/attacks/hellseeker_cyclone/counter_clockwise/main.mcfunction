#Reverse rotation and gradually speed up
execute if score @s boss_timer matches 2..3 run tp @s ~ ~ ~ ~-1.8 0

execute if score @s boss_timer matches 4..5 run tp @s ~ ~ ~ ~-1.6 0

execute if score @s boss_timer matches 6..7 run tp @s ~ ~ ~ ~-1.5 0

execute if score @s boss_timer matches 8..9 run tp @s ~ ~ ~ ~-1.2 0

execute if score @s boss_timer matches 10..11 run tp @s ~ ~ ~ ~-1.0 0

execute if score @s boss_timer matches 12..13 run tp @s ~ ~ ~ ~-0.8 0

execute if score @s boss_timer matches 14..15 run tp @s ~ ~ ~ ~-0.6 0

execute if score @s boss_timer matches 16..17 run tp @s ~ ~ ~ ~-0.4 0

execute if score @s boss_timer matches 18..19 run tp @s ~ ~ ~ ~-0.2 0

#Phase check
execute if score @s[tag=!phase2] boss_timer matches 20.. run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/counter_clockwise/phase1

execute if score @s[tag=phase2] boss_timer matches 20.. run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/counter_clockwise/phase2
