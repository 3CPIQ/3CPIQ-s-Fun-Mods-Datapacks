#Ray
tag @s add this

execute positioned ^ ^ ^1 if block ~ ~ ~ #adr_boss:pseudo_air positioned ~-.5 ~-.5 ~-.5 unless entity @e[type=!#adr_boss:non_living,tag=!this,dx=0] positioned ~.5 ~.5 ~.5 positioned ^ ^ ^2 if block ~ ~ ~ #adr_boss:pseudo_air positioned ~-.5 ~-.5 ~-.5 unless entity @e[type=!#adr_boss:non_living,tag=!this,dx=0] positioned ~.5 ~.5 ~.5 run tp @s ~ ~ ~

tag @s remove this
