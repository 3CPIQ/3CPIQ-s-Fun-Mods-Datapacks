#Shoot blackhole projectile
summon marker ^ ^ ^ {Tags: ["p2_boss_blackhole", "panopticon", "init"], CustomName: "{\"text\": \"Panopticon\"}"}

playsound minecraft:entity.wither.spawn hostile @a ~ ~ ~ 10 2 0

execute store result score @e[type=marker,tag=p2_boss_blackhole,tag=init,distance=..4,sort=nearest,limit=1] boss_attack run attribute @s generic.attack_damage get 1000

scoreboard players operation @e[type=marker,tag=p2_boss_blackhole,tag=init,distance=..4,sort=nearest,limit=1] boss_id = @s boss_id

execute if entity @s[tag=phase2] run tag @e[type=marker,tag=p2_boss_blackhole,tag=init,distance=..4,sort=nearest,limit=1] add phase2

tag @e[type=marker,tag=p2_boss_blackhole,tag=init,distance=..4,sort=nearest,limit=1] remove init
