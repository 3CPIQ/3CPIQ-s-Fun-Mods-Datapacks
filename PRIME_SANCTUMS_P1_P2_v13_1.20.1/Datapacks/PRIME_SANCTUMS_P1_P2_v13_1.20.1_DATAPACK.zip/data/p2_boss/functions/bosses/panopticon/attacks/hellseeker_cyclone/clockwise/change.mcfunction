#Change
tag @s add counter_clockwise

tag @s remove clockwise

tag @s remove was_clockwise
