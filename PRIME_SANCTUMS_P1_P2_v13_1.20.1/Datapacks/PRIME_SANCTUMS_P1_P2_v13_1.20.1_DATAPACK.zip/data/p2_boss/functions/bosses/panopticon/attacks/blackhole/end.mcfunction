#End
execute on passengers if entity @s[type=item_display,tag=adr_model,tag=panopticon] run function animated_java:panopticon/animations/close/play

tag @s add has_blackhole

scoreboard players set @s boss_attack 0

scoreboard players set @s boss_timer 0
