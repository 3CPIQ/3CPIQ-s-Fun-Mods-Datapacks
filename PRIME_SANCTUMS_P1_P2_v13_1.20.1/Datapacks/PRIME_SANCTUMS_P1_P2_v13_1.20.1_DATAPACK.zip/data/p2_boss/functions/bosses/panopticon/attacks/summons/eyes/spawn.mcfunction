#Spawn
summon slime ~ ~ ~ {Size: 0, Tags: ["p2_boss_eyes", "adr_hitbox", "panopticon", "panopticon_summon", "no_id", "spawned"], DeathLootTable:"adr_boss:empty", NoAI: 1b, Silent: 1b, PersistenceRequired: 1b, Attributes: [{Name: "generic.max_health", Base: 1}], Health: 1, CustomName: "{\"text\": \"Flesh Eyes\"}", Passengers: [{id: "minecraft:item_display", Tags: ["adr_model", "p2_boss_eyes", "no_id"], item: {id: "minecraft:black_dye", Count: 1, tag: {CustomModelData: 6, billboard: "fixed"}}}]}

#Initialize
execute as @e[type=slime,distance=..1,tag=p2_boss_eyes,tag=no_id,limit=1] at @s run function p2_boss:bosses/panopticon/attacks/summons/eyes/init

particle reverse_portal ~ ~ ~ 0.5 0.5 0.5 1 50 force

particle flash ~ ~ ~ 0 0 0 1 0 force

playsound block.honey_block.fall hostile @a ~ ~ ~ 10 0 0
