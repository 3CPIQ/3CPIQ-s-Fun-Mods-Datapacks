##Eyes
#Combat
execute if entity @s[tag=!heal,tag=!spawned] run function p2_boss:bosses/panopticon/attacks/summons/eyes/combat

#Heal Panopticon
execute if entity @s[tag=heal] run function p2_boss:bosses/panopticon/attacks/summons/eyes/heal/main
