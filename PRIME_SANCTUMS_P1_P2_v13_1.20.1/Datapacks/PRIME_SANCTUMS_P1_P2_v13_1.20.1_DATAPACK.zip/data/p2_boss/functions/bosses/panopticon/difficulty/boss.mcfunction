#Boss Difficulty
attribute @s generic.max_health base set 700

attribute @s generic.attack_damage base set 30

attribute @s generic.armor base set 30

attribute @s generic.armor_toughness base set 30

tag @s add diff_3
