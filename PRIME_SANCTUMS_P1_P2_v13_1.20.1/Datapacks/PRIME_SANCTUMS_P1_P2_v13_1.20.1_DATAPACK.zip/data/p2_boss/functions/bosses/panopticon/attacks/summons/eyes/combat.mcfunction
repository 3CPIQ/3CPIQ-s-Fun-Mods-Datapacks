#Attack
execute unless score @s boss_attack matches 50.. run scoreboard players add @s boss_attack 1

execute if entity @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,type=!ultracraft:shotgun_pellet,type=!ultracraft:thrown_machinesword,type=!ultracraft:ejected_core,type=!ultracraft:magnet,type=!ultracraft:soap,type=!ultracraft:retaliation,type=!ultracraft:interruptable_charge,type=!player,distance=..30,tag=!panopticon] run tag @s add in_combat

execute if entity @e[type=player,distance=..30,gamemode=!creative,gamemode=!spectator] run tag @s add in_combat

execute if score @s[tag=in_combat] boss_attack matches 50.. run function p2_boss:bosses/panopticon/attacks/summons/eyes/attack/main

tag @s remove in_combat

#Movement
scoreboard players add @s boss_stamina 1

execute if score @s boss_stamina matches 60.. run function p2_boss:bosses/panopticon/attacks/summons/eyes/move/main
