#Modded Difficulty
attribute @s generic.max_health base set 500

attribute @s generic.attack_damage base set 20

attribute @s generic.armor base set 20

attribute @s generic.armor_toughness base set 20

tag @s add diff_2
