##Panopticon
#Death
execute on vehicle run scoreboard players set $is_alive boss_id 1

execute unless entity @s[tag=dead] if score $is_alive boss_id matches 0 run function p2_boss:bosses/panopticon/death/trigger

execute if entity @s[tag=dead] run function p2_boss:bosses/panopticon/death/main

scoreboard players set $is_alive boss_id 0
