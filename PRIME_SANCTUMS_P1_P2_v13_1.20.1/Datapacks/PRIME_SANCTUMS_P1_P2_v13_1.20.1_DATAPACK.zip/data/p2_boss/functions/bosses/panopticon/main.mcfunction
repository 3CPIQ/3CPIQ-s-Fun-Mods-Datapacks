##Panopticon
#Bossbar
execute store result score @s boss_hp run data get entity @s Health 1

execute store result bossbar p2:panopticon max run attribute @s generic.max_health get

execute store result bossbar p2:panopticon value run scoreboard players get @s boss_hp

#Heal / summon eyes and maurice on a timer
execute if entity @e[type=!#adr_boss:non_living,type=!ultracraft:nail,type=!ultracraft:beam,type=!ultracraft:blood_orb,type=!ultracraft:cancer_bullet,type=!ultracraft:cerberus_ball,type=!ultracraft:harpoon,type=!ultracraft:hell_bullet,type=!ultracraft:mortar,type=!ultracraft:progression_item,type=!ultracraft:shockwave,type=!ultracraft:soul_orb,type=!ultracraft:stained_glass_window,type=!ultracraft:thrown_coin,type=!ultracraft:vertical_shockwave,type=!ultracraft:shotgun_pellet,type=!ultracraft:thrown_machinesword,type=!ultracraft:ejected_core,type=!ultracraft:magnet,type=!ultracraft:soap,type=!ultracraft:retaliation,type=!ultracraft:interruptable_charge,type=!player,distance=..30,tag=!panopticon] run tag @s add in_combat

execute if entity @e[type=player,distance=..30,gamemode=!creative,gamemode=!spectator] run tag @s add in_combat

execute unless score @s[tag=in_combat] boss_stamina matches ..0 run scoreboard players remove @s boss_stamina 10

execute unless score @s[tag=in_combat] boss_attack matches 1.. if score @s boss_stamina matches ..0 run scoreboard players set @s boss_attack 4

#Choose Attack
execute if score @s[tag=in_combat] boss_attack matches 0 run function p2_boss:bosses/panopticon/attack

tag @s remove in_combat

#Attacks
execute if score @s boss_attack matches 1 run function p2_boss:bosses/panopticon/attacks/blackhole/main

execute if score @s boss_attack matches 2 run function p2_boss:bosses/panopticon/attacks/divine_lights/main

execute if score @s boss_attack matches 3 run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/main

execute if score @s boss_attack matches 4 run function p2_boss:bosses/panopticon/attacks/summons/main

#Spin
execute unless score @s[tag=clockwise] boss_attack matches 3..4 run tp @s ~ ~ ~ ~2 0

execute unless score @s[tag=counter_clockwise] boss_attack matches 3..4 run tp @s ~ ~ ~ ~-2 0

#Phase 2
execute unless entity @s[tag=phase2] if score @s boss_hp <= @s boss_half_hp run tag @s add phase2
