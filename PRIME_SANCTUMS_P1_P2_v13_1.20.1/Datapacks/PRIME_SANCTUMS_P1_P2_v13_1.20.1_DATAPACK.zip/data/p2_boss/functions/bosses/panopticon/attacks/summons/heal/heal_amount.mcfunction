#Heal based on difficulty
execute if entity @s[tag=diff_1] run function p2_boss:bosses/panopticon/attacks/summons/heal/diff1

execute if entity @s[tag=diff_2] run function p2_boss:bosses/panopticon/attacks/summons/heal/diff2

execute if entity @s[tag=diff_3] run function p2_boss:bosses/panopticon/attacks/summons/heal/diff3
