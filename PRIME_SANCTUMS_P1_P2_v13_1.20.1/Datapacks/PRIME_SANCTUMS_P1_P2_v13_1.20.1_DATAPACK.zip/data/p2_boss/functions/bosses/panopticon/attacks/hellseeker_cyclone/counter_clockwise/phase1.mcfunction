#Phase 1 shots
execute if score @s boss_timer matches 22..23 run tp @s ~ ~ ~ ~1 0

execute if score @s boss_timer matches 24..25 run tp @s ~ ~ ~ ~2 0

execute if score @s boss_timer matches 26..27 run tp @s ~ ~ ~ ~4 0

execute if score @s boss_timer matches 28..29 run tp @s ~ ~ ~ ~6 0

execute if score @s boss_timer matches 30..31 run tp @s ~ ~ ~ ~10 0

execute if score @s boss_timer matches 32..33 run tp @s ~ ~ ~ ~11.5 0

execute if score @s boss_timer matches 34..35 run tp @s ~ ~ ~ ~13 0

execute if score @s boss_timer matches 36..37 run tp @s ~ ~ ~ ~14.5 0

execute if score @s boss_timer matches 38..39 run tp @s ~ ~ ~ ~16 0

execute if score @s boss_timer matches 40..41 run tp @s ~ ~ ~ ~17.5 0

execute if score @s boss_timer matches 42..43 run tp @s ~ ~ ~ ~18.5 0

execute if score @s boss_timer matches 44..45 run tp @s ~ ~ ~ ~19.5 0

execute if score @s boss_timer matches 46..47 run tp @s ~ ~ ~ ~20.5 0

execute if score @s boss_timer matches 48..49 run tp @s ~ ~ ~ ~21.5 0

execute if score @s boss_timer matches 50..51 run tp @s ~ ~ ~ ~22.5 0

execute if score @s boss_timer matches 52..53 run tp @s ~ ~ ~ ~23 0

execute if score @s boss_timer matches 54..55 run tp @s ~ ~ ~ ~23.5 0

execute if score @s boss_timer matches 56..57 run tp @s ~ ~ ~ ~24 0

execute if score @s boss_timer matches 58..59 run tp @s ~ ~ ~ ~24.5 0

execute if score @s boss_timer matches 60..61 run tp @s ~ ~ ~ ~25 0

execute if score @s boss_timer matches 62..63 run tp @s ~ ~ ~ ~25.1 0

execute if score @s boss_timer matches 64..65 run tp @s ~ ~ ~ ~25.2 0

execute if score @s boss_timer matches 66..67 run tp @s ~ ~ ~ ~25.3 0

execute if score @s boss_timer matches 68..69 run tp @s ~ ~ ~ ~25.4 0

execute if score @s boss_timer matches 70..71 run tp @s ~ ~ ~ ~25.5 0

execute if score @s boss_timer matches 72..73 run tp @s ~ ~ ~ ~25.55 0

execute if score @s boss_timer matches 74..75 run tp @s ~ ~ ~ ~25.6 0

execute if score @s boss_timer matches 76..77 run tp @s ~ ~ ~ ~25.65 0

execute if score @s boss_timer matches 78..79 run tp @s ~ ~ ~ ~25.7 0

execute if score @s boss_timer matches 80..81 run tp @s ~ ~ ~ ~25.75 0

execute if score @s boss_timer matches 82 run tp @s ~ ~ ~ ~18 0

execute if score @s boss_timer matches 83 run tp @s ~ ~ ~ ~13 0

execute if score @s boss_timer matches 84 run tp @s ~ ~ ~ ~12 0

execute if score @s boss_timer matches 85 run tp @s ~ ~ ~ ~9 0

execute if score @s boss_timer matches 86 run tp @s ~ ~ ~ ~7.5 0

execute if score @s boss_timer matches 87 run tp @s ~ ~ ~ ~6 0

execute if score @s boss_timer matches 88 run tp @s ~ ~ ~ ~4 0

execute if score @s boss_timer matches 89.. run tp @s ~ ~ ~ ~2 0

execute if score @s boss_timer matches 20 anchored eyes positioned ^ ^-1 ^3 run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/shoot

execute if score @s boss_timer matches 25 anchored eyes positioned ^ ^-1 ^3 run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/shoot

execute if score @s boss_timer matches 29 anchored eyes positioned ^ ^-1 ^3 run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/shoot

execute if score @s boss_timer matches 32 anchored eyes positioned ^ ^-1 ^3 run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/shoot

execute if score @s boss_timer matches 34 anchored eyes positioned ^ ^-1 ^3 run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/shoot

execute if score @s boss_timer matches 35..80 anchored eyes positioned ^ ^-1 ^3 run function p2_boss:bosses/panopticon/attacks/hellseeker_cyclone/shoot

execute if score @s boss_timer matches 20 run tag @s add was_counter_clockwise
