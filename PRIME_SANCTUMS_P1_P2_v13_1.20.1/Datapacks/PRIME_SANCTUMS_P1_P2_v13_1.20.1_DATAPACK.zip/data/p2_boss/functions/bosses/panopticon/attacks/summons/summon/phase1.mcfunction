#Summon
execute if score @s boss_timer matches 20..40 run playsound entity.husk.death hostile @a ~ ~ ~ 20 0 0

execute if score @s boss_timer matches 20 positioned ^ ^ ^2 rotated ~90 -90 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/maurice/spawn

execute if score @s boss_timer matches 22 positioned ^ ^ ^2 rotated ~90 -54 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 24 positioned ^ ^ ^2 rotated ~90 -18 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 26 positioned ^ ^ ^2 rotated ~90 18 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 28 positioned ^ ^ ^2 rotated ~90 54 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 30 positioned ^ ^ ^2 rotated ~90 90 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/maurice/spawn

execute if score @s boss_timer matches 32 positioned ^ ^ ^2 rotated ~90 126 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 34 positioned ^ ^ ^2 rotated ~90 162 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 36 positioned ^ ^ ^2 rotated ~90 193 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 38 positioned ^ ^ ^2 rotated ~90 234 positioned ^ ^ ^8 run function p2_boss:bosses/panopticon/attacks/summons/eyes/spawn

execute if score @s boss_timer matches 40 run scoreboard players operation $temp boss_id = @s boss_id

execute if score @s boss_timer matches 40 as @e[type=slime,tag=panopticon_summon,distance=..20] if score @s boss_id = $temp boss_id run tag @s remove spawned

#Make recover faster on modded difficulty
execute if score @s[tag=diff_2] boss_timer matches 40.. run scoreboard players add @s boss_timer 1

execute if score @s boss_timer matches 60.. run function p2_boss:bosses/panopticon/attacks/summons/end
