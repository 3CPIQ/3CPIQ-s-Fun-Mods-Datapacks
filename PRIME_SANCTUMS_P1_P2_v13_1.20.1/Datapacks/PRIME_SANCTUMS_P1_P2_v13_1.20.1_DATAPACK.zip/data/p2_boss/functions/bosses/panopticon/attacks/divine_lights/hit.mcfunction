#Damage
scoreboard players operation $damage boss_id = @s boss_attack

execute as @e[type=!#adr_boss:non_living,dx=10,dy=100,dz=10,tag=!panopticon] run function adr_boss:main/damage

execute as @e[type=!#adr_boss:non_living,dx=10,dy=100,dz=10,tag=!panopticon] run effect give @s levitation 1 10 true

# P1 COMPLETE DESTRUCTIVE PATCH
function p2:destruction/r2
