execute store result storage p1:temp saved int 1 run scoreboard players get #saved_time p1_control
# Minecraft 1.20.1 cannot feed a storage integer directly into /time set.
# Use a generated dispatch table to restore the exact saved tick.
function p1:restore_dispatch
scoreboard players set #state p1_control 0
