playsound minecraft:boss.flesh_prison.theme master @s ~ ~ ~ 1 1
