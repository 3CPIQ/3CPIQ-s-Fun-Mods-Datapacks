effect give @e[tag=p1_candidate] minecraft:glowing 3 0 true
