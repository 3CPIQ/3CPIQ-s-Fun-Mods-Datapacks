# P-1 terrified spectator system v6
# Runs EVERY TICK while Minos is active.
# Any eligible mob entering the radius is acquired automatically.
# Players, Wardens, Minos/ADR boss-model entities, displays, projectiles, items, etc. are excluded.

# Acquire eligible nearby living-ish mobs around BOTH the player and Minos.
# First around the nearest player.
execute at @p run tag @e[type=!minecraft:player,type=!minecraft:warden,distance=..32] add p1_candidate
# Then around Minos, so mobs outside the player's radius but near Minos are also acquired.
execute as @e[tag=minos,limit=1,sort=nearest] at @s run tag @e[type=!minecraft:player,type=!minecraft:warden,distance=..32] add p1_candidate

# Never touch Adrenaline Bosses' own entities/models, including Minos/Flesh Prison.
tag @e[tag=adr_model] remove p1_candidate
tag @e[tag=minos] remove p1_candidate
tag @e[tag=flesh_prison] remove p1_candidate

# Exclude non-mob entity classes that must not be frozen/rotated.
tag @e[type=minecraft:armor_stand] remove p1_candidate
tag @e[type=minecraft:item_display] remove p1_candidate
tag @e[type=minecraft:block_display] remove p1_candidate
tag @e[type=minecraft:text_display] remove p1_candidate
tag @e[type=minecraft:item] remove p1_candidate
tag @e[type=minecraft:experience_orb] remove p1_candidate
tag @e[type=minecraft:area_effect_cloud] remove p1_candidate
tag @e[type=minecraft:marker] remove p1_candidate
tag @e[type=minecraft:interaction] remove p1_candidate
tag @e[type=minecraft:arrow] remove p1_candidate
tag @e[type=minecraft:spectral_arrow] remove p1_candidate
tag @e[type=minecraft:trident] remove p1_candidate
tag @e[type=minecraft:fireball] remove p1_candidate
tag @e[type=minecraft:small_fireball] remove p1_candidate
tag @e[type=minecraft:dragon_fireball] remove p1_candidate
tag @e[type=minecraft:wither_skull] remove p1_candidate
tag @e[type=minecraft:snowball] remove p1_candidate
tag @e[type=minecraft:egg] remove p1_candidate
tag @e[type=minecraft:ender_pearl] remove p1_candidate
tag @e[type=minecraft:experience_bottle] remove p1_candidate
tag @e[type=minecraft:potion] remove p1_candidate
tag @e[type=minecraft:falling_block] remove p1_candidate
tag @e[type=minecraft:tnt] remove p1_candidate
tag @e[type=minecraft:lightning_bolt] remove p1_candidate
tag @e[type=minecraft:boat] remove p1_candidate
tag @e[type=minecraft:chest_boat] remove p1_candidate
tag @e[type=minecraft:minecart] remove p1_candidate
tag @e[type=minecraft:chest_minecart] remove p1_candidate
tag @e[type=minecraft:furnace_minecart] remove p1_candidate
tag @e[type=minecraft:hopper_minecart] remove p1_candidate
tag @e[type=minecraft:tnt_minecart] remove p1_candidate
tag @e[type=minecraft:command_block_minecart] remove p1_candidate

# Newly acquired mobs immediately become spectators.
execute as @e[tag=p1_candidate,tag=!p1_touched] if data entity @s {NoAI:1b} run tag @s add p1_had_noai
tag @e[tag=p1_candidate] add p1_touched
execute as @e[tag=p1_candidate] run data merge entity @s {NoAI:1b}

# Every tick, continuously update where EVERY current spectator is looking.
# Default focus: nearest player.
execute as @e[tag=p1_touched] at @s facing entity @p eyes run tp @s ~ ~ ~ ~ ~

# Approximate "whichever is closer" with fine 2-block bands.
# Minos wins focus only when he is inside a band and the player is not inside that same band.
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..2,limit=1,sort=nearest] unless entity @p[distance=..2] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..4,limit=1,sort=nearest] unless entity @p[distance=..4] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..6,limit=1,sort=nearest] unless entity @p[distance=..6] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..8,limit=1,sort=nearest] unless entity @p[distance=..8] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..10,limit=1,sort=nearest] unless entity @p[distance=..10] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..12,limit=1,sort=nearest] unless entity @p[distance=..12] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..14,limit=1,sort=nearest] unless entity @p[distance=..14] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..16,limit=1,sort=nearest] unless entity @p[distance=..16] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..20,limit=1,sort=nearest] unless entity @p[distance=..20] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..24,limit=1,sort=nearest] unless entity @p[distance=..24] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..28,limit=1,sort=nearest] unless entity @p[distance=..28] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..32,limit=1,sort=nearest] unless entity @p[distance=..32] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~

# Fear movement. Because NoAI is active, this is the ONLY movement spectators perform.
# Player too close -> step directly away from player.
execute as @e[tag=p1_touched] at @s if entity @p[distance=..4] facing entity @p eyes run tp @s ^ ^ ^-0.30

# Minos too close -> step directly away from Minos.
execute as @e[tag=p1_touched] at @s if entity @e[tag=minos,distance=..6,limit=1,sort=nearest] facing entity @e[tag=minos,limit=1,sort=nearest] eyes run tp @s ^ ^ ^-0.36

# Candidate is only a per-tick acquisition tag.
tag @e[tag=p1_candidate] remove p1_candidate
