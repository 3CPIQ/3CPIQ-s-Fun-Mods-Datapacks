# Restore the exact saved daytime by moving the clock forward smoothly.
execute store result score #now p1_control run time query daytime

# Calculate forward modular distance: diff = saved - now; if negative, add 24000.
scoreboard players operation #diff p1_control = #saved_time p1_control
scoreboard players operation #diff p1_control -= #now p1_control
execute if score #diff p1_control matches ..-1 run scoreboard players add #diff p1_control 24000

# If close enough, set exact saved time and finish.
execute if score #diff p1_control matches 0..20 run function p1:finish_restore
# Otherwise move forward rapidly but visibly/smoothly.
execute if score #diff p1_control matches 21.. run time add 20
