scoreboard players set #state p1_control 2
function p1:music_stop
function adr_boss:admin/summon/minos_orb
weather thunder 1000000
