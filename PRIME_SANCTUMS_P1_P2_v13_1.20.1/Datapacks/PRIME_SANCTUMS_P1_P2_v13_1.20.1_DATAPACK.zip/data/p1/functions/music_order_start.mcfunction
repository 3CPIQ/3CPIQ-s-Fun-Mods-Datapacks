stopsound @a music p1music:chaos
stopsound @a music p1music:order
execute as @a at @s run playsound p1music:order music @s ~ ~ ~ 1 1 0
scoreboard players set #music_timer p1_control 6765
