function p1:music_stop
function p1:restore_mobs
execute store result score #saved_time p1_control run time query daytime
scoreboard players set #state p1_control 1
weather clear
function adr_boss:admin/summon/flesh_prison
function p1:music_flesh_start
