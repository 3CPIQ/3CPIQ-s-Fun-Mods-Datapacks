# Controller transition: Flesh Prison death -> Minos Orb.
execute if score #state p1_control matches 1 as @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=dead,limit=1] at @s run function p1:release_minos

# Smooth midnight transition while Minos stage is active.
execute if score #state p1_control matches 2 run function p1:to_midnight

# Minos death.
execute if score #state p1_control matches 2 if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=dead,limit=1] run function p1:minos_dead

# Smoothly return to the saved time.
execute if score #state p1_control matches 3 run function p1:restore_time

# These two systems DO NOT depend on #state.
# They detect the bosses themselves every tick, including bosses summoned manually.
function p1:music_auto
function p1:spectator_auto

# Living Minos Prime blue light/aura.
function p1:minos_light_tick
