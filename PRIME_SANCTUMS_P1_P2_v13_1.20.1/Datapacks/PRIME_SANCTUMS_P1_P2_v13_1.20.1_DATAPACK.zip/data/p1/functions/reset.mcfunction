function p1:title_clear
stopsound @a master minecraft:boss.minos.order_intro
function p1:music_stop
function p1:restore_mobs
scoreboard players set #state p1_control 0
weather clear
execute as @e[type=minecraft:marker,tag=p1_minos_light] at @s if block ~ ~ ~ minecraft:light run setblock ~ ~ ~ air
kill @e[type=minecraft:marker,tag=p1_minos_light]
