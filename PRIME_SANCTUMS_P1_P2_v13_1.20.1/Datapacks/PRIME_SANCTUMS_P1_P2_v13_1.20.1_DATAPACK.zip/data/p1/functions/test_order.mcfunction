playsound minecraft:boss.minos.theme master @s ~ ~ ~ 1 1
