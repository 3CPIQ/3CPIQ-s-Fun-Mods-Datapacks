execute as @e[type=!minecraft:player,type=!minecraft:warden,distance=..32] if data entity @s Health run tag @s add p1_candidate
