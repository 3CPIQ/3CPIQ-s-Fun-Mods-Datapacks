execute if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1] run tellraw @s {"text":"Live Flesh Prison detected","color":"red"}
execute if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1] run tellraw @s {"text":"Live Minos detected","color":"aqua"}
