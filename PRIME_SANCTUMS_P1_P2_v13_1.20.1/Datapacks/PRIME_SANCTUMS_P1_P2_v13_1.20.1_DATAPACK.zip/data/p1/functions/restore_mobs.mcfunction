execute as @e[tag=p1_touched,tag=!p1_had_noai] run data merge entity @s {NoAI:0b}
tag @e[tag=p1_touched] remove p1_touched
tag @e[tag=p1_had_noai] remove p1_had_noai
tag @e[tag=p1_candidate] remove p1_candidate
