function p1:title_clear
stopsound @a master minecraft:boss.minos.order_intro
function p1:music_stop
function p1:restore_mobs
scoreboard players set #state p1_control 3
weather clear
