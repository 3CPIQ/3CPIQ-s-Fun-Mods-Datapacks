scoreboard players remove #music_timer p1_control 1
execute if score #state p1_control matches 1 if score #music_timer p1_control matches ..0 run function p1:music_chaos_start
execute if score #state p1_control matches 2 if score #music_timer p1_control matches ..0 run function p1:music_order_start
