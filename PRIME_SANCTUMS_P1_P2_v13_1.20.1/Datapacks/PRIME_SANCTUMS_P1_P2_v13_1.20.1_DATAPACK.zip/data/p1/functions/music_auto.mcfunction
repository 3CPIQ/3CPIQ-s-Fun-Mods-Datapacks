# v3 NOTE: ORDER intro is started by the actual Minos Orb impact function.
# Automatic boss music detector.
# Flesh Prison can begin immediately.
execute if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1] unless entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1] unless score #music_phase p1_control matches 1 run function p1:music_flesh_start

# Minos battle ORDER must WAIT until his 46-second monologue/spawn sequence is finished.
# The root Minos hitbox carries tag=spawned during the monologue.
execute if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1] unless entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=minos,tag=spawned,limit=1] unless score #music_phase p1_control matches 2 run function p1:music_minos_start

# Loop battle tracks only.
execute if score #music_phase p1_control matches 1..2 run scoreboard players remove #music_timer p1_control 1
execute if score #music_phase p1_control matches 1 if score #music_timer p1_control matches ..0 if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1] run function p1:music_flesh_start
execute if score #music_phase p1_control matches 2 if score #music_timer p1_control matches ..0 if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1] unless entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=minos,tag=spawned,limit=1] run function p1:music_minos_start

# Stop only when both bosses are completely gone/dead.
execute unless entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1] unless entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1] unless score #music_phase p1_control matches 0 run function p1:music_stop
