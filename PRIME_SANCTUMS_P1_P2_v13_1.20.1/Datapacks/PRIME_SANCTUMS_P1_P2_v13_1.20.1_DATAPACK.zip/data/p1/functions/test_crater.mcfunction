execute positioned ^ ^ ^4 run function p1:destruction/r1
