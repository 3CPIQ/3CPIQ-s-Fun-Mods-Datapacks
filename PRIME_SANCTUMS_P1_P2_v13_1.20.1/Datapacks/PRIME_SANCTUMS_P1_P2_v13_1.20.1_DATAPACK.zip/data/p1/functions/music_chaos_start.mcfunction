stopsound @a music p1music:order
stopsound @a music p1music:chaos
execute as @a at @s run playsound p1music:chaos music @s ~ ~ ~ 1 1 0
scoreboard players set #music_timer p1_control 2820
