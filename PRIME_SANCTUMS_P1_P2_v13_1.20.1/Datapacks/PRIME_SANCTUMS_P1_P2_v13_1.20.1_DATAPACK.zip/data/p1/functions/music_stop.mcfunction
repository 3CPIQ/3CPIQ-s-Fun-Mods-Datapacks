stopsound @a master minecraft:boss.minos.order_intro
stopsound @a master minecraft:boss.flesh_prison.theme
stopsound @a master minecraft:boss.minos.theme
stopsound @a record minecraft:boss.flesh_prison.theme
stopsound @a record minecraft:boss.minos.theme
scoreboard players set #music_phase p1_control 0
scoreboard players set #music_timer p1_control 0
