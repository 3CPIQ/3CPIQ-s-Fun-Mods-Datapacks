schedule clear p1:title/finish
schedule clear p1:title/fade_00
schedule clear p1:title/fade_01
schedule clear p1:title/fade_02
schedule clear p1:title/fade_03
schedule clear p1:title/fade_04
schedule clear p1:title/fade_05
schedule clear p1:title/fade_06
schedule clear p1:title/fade_07
schedule clear p1:title/fade_08
schedule clear p1:title/fade_09
bossbar set p1:soul_survivor visible false
bossbar set p1:soul_survivor players
