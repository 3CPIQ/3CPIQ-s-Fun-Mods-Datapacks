scoreboard objectives add p1_control dummy
scoreboard players add #state p1_control 0
scoreboard players add #music_phase p1_control 0
scoreboard players add #music_timer p1_control 0
execute unless data storage p1:internal bossbar_created run bossbar add p1:soul_survivor {"text":"Minecraft","color":"dark_red","bold":true}
execute unless data storage p1:internal bossbar_created run data modify storage p1:internal bossbar_created set value 1b
bossbar set p1:soul_survivor max 100
bossbar set p1:soul_survivor value 100
bossbar set p1:soul_survivor color white
bossbar set p1:soul_survivor style progress
bossbar set p1:soul_survivor visible false
