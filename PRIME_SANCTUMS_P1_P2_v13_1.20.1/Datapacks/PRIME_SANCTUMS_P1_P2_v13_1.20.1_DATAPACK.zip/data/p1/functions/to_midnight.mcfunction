# Smoothly move forward toward midnight (18000).
execute store result score #now p1_control run time query daytime
execute if score #now p1_control matches 0..17979 run time add 20
execute if score #now p1_control matches 18021..23999 run time add 20
# Snap only the final <=20 tick difference so it lands exactly on midnight.
execute if score #now p1_control matches 17980..18020 run time set midnight
