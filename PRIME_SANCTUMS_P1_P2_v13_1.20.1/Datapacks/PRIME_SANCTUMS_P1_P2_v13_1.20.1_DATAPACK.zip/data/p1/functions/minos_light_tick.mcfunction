# Moving light + blue aura for living Minos Prime.

# Clear our previous light position before moving it.
execute as @e[type=minecraft:marker,tag=p1_minos_light] at @s if block ~ ~ ~ minecraft:light run setblock ~ ~ ~ air

# Create tracker if Minos is alive.
execute unless entity @e[type=minecraft:marker,tag=p1_minos_light,limit=1] if entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=minos,limit=1] at @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=minos,limit=1] run summon minecraft:marker ~ ~1.25 ~ {Tags:["p1_minos_light"]}

# Follow living Minos.
execute as @e[type=minecraft:marker,tag=p1_minos_light] at @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=minos,limit=1,sort=nearest] run tp @s ~ ~1.25 ~

# Place actual invisible light only in air.
execute as @e[type=minecraft:marker,tag=p1_minos_light] at @s if block ~ ~ ~ air run setblock ~ ~ ~ minecraft:light[level=13]

# Blue Prime Soul aura during spawn + battle.
execute at @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=minos,limit=1] run particle dust 0.120 0.550 1.000 0.75 ~ ~1.55 ~ 0.48 0.95 0.48 0.015 10 force

# Death / disappearance cleanup.
execute unless entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=minos,limit=1] as @e[type=minecraft:marker,tag=p1_minos_light] at @s if block ~ ~ ~ minecraft:light run setblock ~ ~ ~ air
execute unless entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=minos,limit=1] run kill @e[type=minecraft:marker,tag=p1_minos_light]
