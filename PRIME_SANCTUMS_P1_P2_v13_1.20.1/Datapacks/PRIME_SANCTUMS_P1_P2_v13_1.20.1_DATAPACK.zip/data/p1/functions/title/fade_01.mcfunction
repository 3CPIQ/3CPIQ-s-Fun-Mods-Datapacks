bossbar set p1:soul_survivor visible true
bossbar set p1:soul_survivor name [{"text":"Minecraft","color":"#880000","bold":true},{"text":" - Soul Survivor","color":"#888888","bold":false}]
schedule function p1:title/fade_02 2t replace
