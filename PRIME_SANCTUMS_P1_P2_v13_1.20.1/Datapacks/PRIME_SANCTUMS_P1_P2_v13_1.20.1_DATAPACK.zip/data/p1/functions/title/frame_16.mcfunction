bossbar set p1:soul_survivor players @a
bossbar set p1:soul_survivor visible true
bossbar set p1:soul_survivor name [{"text":"Minecraft","color":"#AA0000","bold":true},{"text":" - Soul Survivor","color":"#AAAAAA","bold":false}]
schedule function p1:title/fade_00 45t replace
