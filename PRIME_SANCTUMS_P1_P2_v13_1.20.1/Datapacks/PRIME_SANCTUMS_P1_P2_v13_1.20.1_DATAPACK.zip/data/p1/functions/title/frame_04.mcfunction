bossbar set p1:soul_survivor players @a
bossbar set p1:soul_survivor visible true
bossbar set p1:soul_survivor name [{"text":"Minecraft","color":"dark_red","bold":true},{"text":" - S","color":"gray","bold":false}]
schedule function p1:title/frame_05 2t replace
