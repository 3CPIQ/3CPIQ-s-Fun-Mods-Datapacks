bossbar set p1:soul_survivor visible true
bossbar set p1:soul_survivor name [{"text":"Minecraft","color":"#110000","bold":true},{"text":" - Soul Survivor","color":"#111111","bold":false}]
schedule function p1:title/fade_09 2t replace
