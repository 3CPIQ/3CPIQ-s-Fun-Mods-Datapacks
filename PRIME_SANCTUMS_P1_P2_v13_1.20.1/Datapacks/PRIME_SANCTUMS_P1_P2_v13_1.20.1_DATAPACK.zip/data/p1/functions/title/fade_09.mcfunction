bossbar set p1:soul_survivor visible true
bossbar set p1:soul_survivor name [{"text":"Minecraft","color":"#000000","bold":true},{"text":" - Soul Survivor","color":"#000000","bold":false}]
schedule function p1:title/finish 2t replace
