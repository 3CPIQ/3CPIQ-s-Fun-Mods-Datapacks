bossbar set p1:soul_survivor visible true
bossbar set p1:soul_survivor name [{"text":"Minecraft","color":"#990000","bold":true},{"text":" - Soul Survivor","color":"#999999","bold":false}]
schedule function p1:title/fade_01 2t replace
