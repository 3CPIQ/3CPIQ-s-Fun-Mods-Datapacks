bossbar set p1:soul_survivor visible true
bossbar set p1:soul_survivor name [{"text":"Minecraft","color":"#440000","bold":true},{"text":" - Soul Survivor","color":"#444444","bold":false}]
schedule function p1:title/fade_06 2t replace
