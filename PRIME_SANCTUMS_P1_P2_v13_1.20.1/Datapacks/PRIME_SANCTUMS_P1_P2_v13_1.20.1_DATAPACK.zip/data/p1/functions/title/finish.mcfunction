bossbar set p1:soul_survivor visible false
bossbar set p1:soul_survivor players
