bossbar set p1:soul_survivor visible true
bossbar set p1:soul_survivor name [{"text":"Minecraft","color":"#330000","bold":true},{"text":" - Soul Survivor","color":"#333333","bold":false}]
schedule function p1:title/fade_07 2t replace
