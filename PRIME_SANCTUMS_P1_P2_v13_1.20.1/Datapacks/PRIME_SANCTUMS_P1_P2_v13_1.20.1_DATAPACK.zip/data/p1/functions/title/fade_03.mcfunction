bossbar set p1:soul_survivor visible true
bossbar set p1:soul_survivor name [{"text":"Minecraft","color":"#660000","bold":true},{"text":" - Soul Survivor","color":"#666666","bold":false}]
schedule function p1:title/fade_04 2t replace
