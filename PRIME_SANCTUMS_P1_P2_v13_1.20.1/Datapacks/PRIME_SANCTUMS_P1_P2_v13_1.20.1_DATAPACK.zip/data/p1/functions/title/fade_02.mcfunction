bossbar set p1:soul_survivor visible true
bossbar set p1:soul_survivor name [{"text":"Minecraft","color":"#770000","bold":true},{"text":" - Soul Survivor","color":"#777777","bold":false}]
schedule function p1:title/fade_03 2t replace
