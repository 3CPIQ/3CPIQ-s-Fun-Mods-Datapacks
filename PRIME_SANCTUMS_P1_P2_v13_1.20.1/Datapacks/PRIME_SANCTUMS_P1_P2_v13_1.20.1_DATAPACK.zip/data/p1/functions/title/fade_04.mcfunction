bossbar set p1:soul_survivor visible true
bossbar set p1:soul_survivor name [{"text":"Minecraft","color":"#550000","bold":true},{"text":" - Soul Survivor","color":"#555555","bold":false}]
schedule function p1:title/fade_05 2t replace
