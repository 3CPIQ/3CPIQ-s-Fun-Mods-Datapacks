bossbar set p1:soul_survivor visible true
bossbar set p1:soul_survivor name [{"text":"Minecraft","color":"#220000","bold":true},{"text":" - Soul Survivor","color":"#222222","bold":false}]
schedule function p1:title/fade_08 2t replace
