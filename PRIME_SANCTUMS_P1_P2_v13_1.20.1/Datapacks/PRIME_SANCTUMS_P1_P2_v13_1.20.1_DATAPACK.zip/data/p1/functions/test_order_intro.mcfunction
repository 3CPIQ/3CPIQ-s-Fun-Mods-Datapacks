playsound minecraft:boss.minos.order_intro master @s ~ ~ ~ 0.35 1 0
