stopsound @a master minecraft:boss.minos.theme
stopsound @a master minecraft:boss.flesh_prison.theme
execute as @a at @s run playsound minecraft:boss.flesh_prison.theme master @s ~ ~ ~ 1 1
scoreboard players set #music_phase p1_control 1
scoreboard players set #music_timer p1_control 2810
