# Rebuilt spectator system. Runs every tick whenever Flesh Prison or Minos exists.
tag @e[tag=p1_candidate] remove p1_candidate

# Acquire mobs around nearest player.
execute at @p run function p1:spectator_acquire_player
# Acquire mobs around every live Flesh Prison / Minos model.
execute as @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead] at @s run function p1:spectator_acquire_here
execute as @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead] at @s run function p1:spectator_acquire_here

# Never touch boss entities themselves.
tag @e[tag=adr_model] remove p1_candidate
tag @e[tag=flesh_prison] remove p1_candidate
tag @e[tag=minos] remove p1_candidate
tag @e[tag=adr_boss] remove p1_candidate
tag @e[tag=adr_hitbox] remove p1_candidate

# Preserve original NoAI state, then freeze normal AI.
execute as @e[tag=p1_candidate,tag=!p1_touched] if data entity @s {NoAI:1b} run tag @s add p1_had_noai
tag @e[tag=p1_candidate] add p1_touched
execute as @e[tag=p1_candidate] run data merge entity @s {NoAI:1b}

# Mobs that have LEFT the active radius get their AI back immediately.
execute as @e[tag=p1_touched,tag=!p1_candidate,tag=!p1_had_noai] run data merge entity @s {NoAI:0b}
tag @e[tag=p1_touched,tag=!p1_candidate] remove p1_touched
tag @e[tag=p1_had_noai,tag=!p1_candidate] remove p1_had_noai

# Recalculate gaze EVERY SINGLE TICK. Default target = player.
execute as @e[tag=p1_candidate] at @s facing entity @p eyes run tp @s ~ ~ ~ ~ ~

# If Flesh Prison is closer than the player, look at Flesh Prison.
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..2,limit=1,sort=nearest] unless entity @p[distance=..2] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..4,limit=1,sort=nearest] unless entity @p[distance=..4] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..6,limit=1,sort=nearest] unless entity @p[distance=..6] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..8,limit=1,sort=nearest] unless entity @p[distance=..8] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..10,limit=1,sort=nearest] unless entity @p[distance=..10] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..12,limit=1,sort=nearest] unless entity @p[distance=..12] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..14,limit=1,sort=nearest] unless entity @p[distance=..14] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..16,limit=1,sort=nearest] unless entity @p[distance=..16] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..20,limit=1,sort=nearest] unless entity @p[distance=..20] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..24,limit=1,sort=nearest] unless entity @p[distance=..24] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..28,limit=1,sort=nearest] unless entity @p[distance=..28] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..32,limit=1,sort=nearest] unless entity @p[distance=..32] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~

# If Minos is closer than the player, look at Minos.
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..2,limit=1,sort=nearest] unless entity @p[distance=..2] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..4,limit=1,sort=nearest] unless entity @p[distance=..4] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..6,limit=1,sort=nearest] unless entity @p[distance=..6] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..8,limit=1,sort=nearest] unless entity @p[distance=..8] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..10,limit=1,sort=nearest] unless entity @p[distance=..10] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..12,limit=1,sort=nearest] unless entity @p[distance=..12] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..14,limit=1,sort=nearest] unless entity @p[distance=..14] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..16,limit=1,sort=nearest] unless entity @p[distance=..16] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..20,limit=1,sort=nearest] unless entity @p[distance=..20] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..24,limit=1,sort=nearest] unless entity @p[distance=..24] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..28,limit=1,sort=nearest] unless entity @p[distance=..28] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..32,limit=1,sort=nearest] unless entity @p[distance=..32] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes run tp @s ~ ~ ~ ~ ~

# Flee HORIZONTALLY when the player gets too close.
# Pitch is forced to 0 and destination must have solid floor, so spectators do not dive underground.
execute as @e[tag=p1_candidate] at @s if entity @p[distance=..4] facing entity @p eyes rotated ~ 0 if block ^ ^ ^-0.6 #adr_boss:pseudo_air unless block ^ ^-1 ^-0.6 #adr_boss:pseudo_air run tp @s ^ ^ ^-0.30
# Flee when Flesh Prison gets too close.
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,distance=..6,limit=1,sort=nearest] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=flesh_prison,tag=!dead,limit=1,sort=nearest] eyes rotated ~ 0 if block ^ ^ ^-0.7 #adr_boss:pseudo_air unless block ^ ^-1 ^-0.7 #adr_boss:pseudo_air run tp @s ^ ^ ^-0.36
# Flee when Minos gets too close.
execute as @e[tag=p1_candidate] at @s if entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,distance=..6,limit=1,sort=nearest] facing entity @e[type=minecraft:item_display,tag=adr_model,tag=minos,tag=!dead,limit=1,sort=nearest] eyes rotated ~ 0 if block ^ ^ ^-0.7 #adr_boss:pseudo_air unless block ^ ^-1 ^-0.7 #adr_boss:pseudo_air run tp @s ^ ^ ^-0.36
