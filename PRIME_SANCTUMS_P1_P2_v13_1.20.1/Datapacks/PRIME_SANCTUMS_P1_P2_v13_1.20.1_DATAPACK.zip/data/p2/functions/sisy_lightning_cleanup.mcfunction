# End Sisyphus's temporary self-lightning protection.
# Remove our tagged lightning entities before making him vulnerable again.
kill @e[type=minecraft:lightning_bolt,tag=p2_sisy_lightning]
data merge entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,limit=1] {Invulnerable:0b}
