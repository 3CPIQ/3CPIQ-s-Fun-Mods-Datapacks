bossbar set p2:wait_of_world visible true
bossbar set p2:wait_of_world name [{"text":"Minecraft","color":"#770000","bold":true},{"text":" - Wait of the World","color":"#777777","bold":false}]
schedule function p2:title/fade_03 2t replace
