bossbar set p2:wait_of_world visible true
bossbar set p2:wait_of_world name [{"text":"Minecraft","color":"#220000","bold":true},{"text":" - Wait of the World","color":"#222222","bold":false}]
schedule function p2:title/fade_08 2t replace
