bossbar set p2:wait_of_world visible true
bossbar set p2:wait_of_world name [{"text":"Minecraft","color":"#880000","bold":true},{"text":" - Wait of the World","color":"#888888","bold":false}]
schedule function p2:title/fade_02 2t replace
