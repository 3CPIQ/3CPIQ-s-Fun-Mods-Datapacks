schedule clear p2:title/finish
schedule clear p2:title/fade_00
schedule clear p2:title/fade_01
schedule clear p2:title/fade_02
schedule clear p2:title/fade_03
schedule clear p2:title/fade_04
schedule clear p2:title/fade_05
schedule clear p2:title/fade_06
schedule clear p2:title/fade_07
schedule clear p2:title/fade_08
schedule clear p2:title/fade_09
bossbar set p2:wait_of_world color white
bossbar set p2:wait_of_world style progress
bossbar set p2:wait_of_world players @a
bossbar set p2:wait_of_world visible true
function p2:title/frame_00
