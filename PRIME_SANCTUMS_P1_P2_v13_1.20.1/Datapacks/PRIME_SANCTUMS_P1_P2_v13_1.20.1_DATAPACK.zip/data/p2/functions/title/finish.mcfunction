bossbar set p2:wait_of_world visible false
bossbar set p2:wait_of_world players
