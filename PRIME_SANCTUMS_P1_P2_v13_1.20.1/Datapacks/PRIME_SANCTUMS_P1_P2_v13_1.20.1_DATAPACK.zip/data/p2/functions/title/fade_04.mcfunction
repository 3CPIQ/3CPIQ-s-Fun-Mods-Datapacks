bossbar set p2:wait_of_world visible true
bossbar set p2:wait_of_world name [{"text":"Minecraft","color":"#550000","bold":true},{"text":" - Wait of the World","color":"#555555","bold":false}]
schedule function p2:title/fade_05 2t replace
