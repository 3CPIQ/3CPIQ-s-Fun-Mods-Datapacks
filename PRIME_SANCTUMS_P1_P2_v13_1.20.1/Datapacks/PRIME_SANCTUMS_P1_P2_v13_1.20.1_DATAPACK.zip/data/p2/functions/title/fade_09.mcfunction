bossbar set p2:wait_of_world visible true
bossbar set p2:wait_of_world name [{"text":"Minecraft","color":"#000000","bold":true},{"text":" - Wait of the World","color":"#000000","bold":false}]
schedule function p2:title/finish 2t replace
