bossbar set p2:wait_of_world visible true
bossbar set p2:wait_of_world name [{"text":"Minecraft","color":"#990000","bold":true},{"text":" - Wait of the World","color":"#999999","bold":false}]
schedule function p2:title/fade_01 2t replace
