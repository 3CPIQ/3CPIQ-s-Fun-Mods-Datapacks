bossbar set p2:wait_of_world visible true
bossbar set p2:wait_of_world name [{"text":"Minecraft","color":"#660000","bold":true},{"text":" - Wait of the World","color":"#666666","bold":false}]
schedule function p2:title/fade_04 2t replace
