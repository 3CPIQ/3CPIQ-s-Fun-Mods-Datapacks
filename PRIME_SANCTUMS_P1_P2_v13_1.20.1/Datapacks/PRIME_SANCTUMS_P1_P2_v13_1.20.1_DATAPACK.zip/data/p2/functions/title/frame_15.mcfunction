bossbar set p2:wait_of_world players @a
bossbar set p2:wait_of_world visible true
bossbar set p2:wait_of_world name [{"text":"Minecraft","color":"#AA0000","bold":true},{"text":" - Wait of the ","color":"#AAAAAA","bold":false}]
schedule function p2:title/frame_16 2t replace
