bossbar set p2:wait_of_world visible true
bossbar set p2:wait_of_world name [{"text":"Minecraft","color":"#110000","bold":true},{"text":" - Wait of the World","color":"#111111","bold":false}]
schedule function p2:title/fade_09 2t replace
