bossbar set p2:wait_of_world visible true
bossbar set p2:wait_of_world name [{"text":"Minecraft","color":"#330000","bold":true},{"text":" - Wait of the World","color":"#333333","bold":false}]
schedule function p2:title/fade_07 2t replace
