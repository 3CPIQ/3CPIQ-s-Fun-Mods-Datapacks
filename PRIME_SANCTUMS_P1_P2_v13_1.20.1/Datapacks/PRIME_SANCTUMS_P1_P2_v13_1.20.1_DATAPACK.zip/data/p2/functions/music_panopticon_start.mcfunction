stopsound @a master minecraft:boss.sisyphus.war_intro
stopsound @a master minecraft:boss.sisyphus.war
execute as @a at @s run playsound minecraft:boss.panopticon.theme master @s ~ ~ ~ 0.65 1 0
scoreboard players set #music_phase p2_control 1
scoreboard players set #music_timer p2_control 4208
