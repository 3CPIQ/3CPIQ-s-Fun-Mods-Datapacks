# Moving light + golden aura for living Sisyphus Prime.

# Clear our previous light position before moving it.
execute as @e[type=minecraft:marker,tag=p2_sisy_light] at @s if block ~ ~ ~ minecraft:light run setblock ~ ~ ~ air

# Create tracker if Sisyphus is alive.
execute unless entity @e[type=minecraft:marker,tag=p2_sisy_light,limit=1] if entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,limit=1] at @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,limit=1] run summon minecraft:marker ~ ~1.65 ~ {Tags:["p2_sisy_light"]}

# Follow living Sisyphus.
execute as @e[type=minecraft:marker,tag=p2_sisy_light] at @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,limit=1,sort=nearest] run tp @s ~ ~1.65 ~

# Place actual invisible light only in air.
execute as @e[type=minecraft:marker,tag=p2_sisy_light] at @s if block ~ ~ ~ air run setblock ~ ~ ~ minecraft:light[level=14]

# Gold Prime Soul aura during spawn + battle.
execute at @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,limit=1] run particle dust 1.000 0.720 0.080 0.80 ~ ~1.85 ~ 0.58 1.15 0.58 0.015 12 force

# Death / disappearance cleanup.
execute unless entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,limit=1] as @e[type=minecraft:marker,tag=p2_sisy_light] at @s if block ~ ~ ~ minecraft:light run setblock ~ ~ ~ air
execute unless entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,limit=1] run kill @e[type=minecraft:marker,tag=p2_sisy_light]
