# Panopticon -> Sisyphus transition.

# Night transition during the Sisyphus phase.
execute if score #state p2_control matches 2 run function p2:to_midnight


# Restore saved time afterward.
execute if score #state p2_control matches 3 run function p2:restore_time



# P-2 ambient systems.
function p2:music_tick
function p2:spectator_auto

# KEEP 'EM COMING after player death during Sisyphus.
execute if entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,limit=1] if entity @a[scores={p2_sisy_deaths=1..},limit=1] run schedule function p2:sisy_keepemcoming 30t replace
execute as @a[scores={p2_sisy_deaths=1..}] run scoreboard players set @s p2_sisy_deaths 0

# Living Sisyphus Prime gold light/aura.
function p2:sisy_light_tick
