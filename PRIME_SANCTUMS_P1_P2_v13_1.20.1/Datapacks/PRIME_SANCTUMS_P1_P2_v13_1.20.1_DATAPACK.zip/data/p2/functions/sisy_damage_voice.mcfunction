execute if score @s p2_sisy_voice_cd matches 1.. run scoreboard players remove @s p2_sisy_voice_cd 1
scoreboard players operation @s p2_sisy_damage = @s p2_sisy_prev_hp
scoreboard players operation @s p2_sisy_damage -= @s boss_hp

execute if score @s p2_sisy_damage matches 35.. unless score @s p2_sisy_voice_cd matches 1.. as @a at @s run playsound minecraft:boss.sisyphus.grunt voice @s ~ ~ ~ 0.82 1 0
execute if score @s p2_sisy_damage matches 35.. unless score @s p2_sisy_voice_cd matches 1.. run scoreboard players set @s p2_sisy_voice_cd 30

scoreboard players operation @s p2_sisy_prev_hp = @s boss_hp
