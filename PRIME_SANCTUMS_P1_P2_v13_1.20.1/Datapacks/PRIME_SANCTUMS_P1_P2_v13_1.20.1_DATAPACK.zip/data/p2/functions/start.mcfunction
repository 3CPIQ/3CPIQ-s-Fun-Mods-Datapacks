stopsound @a voice minecraft:boss.sisyphus.intro
stopsound @a voice minecraft:boss.sisyphus.outro
stopsound @a voice minecraft:boss.sisyphus.thisprison
# Clean stale P-2 entities/bossbars from previous tests.
bossbar remove p2:sisyphus
bossbar remove p2:panopticon
kill @e[tag=sisyphus]
kill @e[tag=sisyphus_orb]
kill @e[tag=panopticon]
kill @e[tag=p2_boss_wave]
kill @e[tag=p2_boss_serpent]
kill @e[tag=p2_boss_hellseeker]
kill @e[tag=p2_boss_blackhole]
kill @e[tag=p2_boss_divine_light]
kill @e[tag=p2_boss_beam]
kill @e[tag=p2_purple_wave]
kill @e[tag=p2_white_wave]
kill @e[tag=p2_cyan_wave]
kill @e[tag=p2_boss_eyes]
kill @e[tag=p2_boss_maurice]

function p2:music_stop
function p2:restore_mobs
function p2:title_clear
execute store result score #saved_time p2_control run time query daytime
scoreboard players set #state p2_control 1
weather clear
function p2_boss:admin/summon/panopticon
