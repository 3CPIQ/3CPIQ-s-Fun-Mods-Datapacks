# Sisyphus phase-2 impact lightning.
# Called AT the hit/crater position after a successful 50% roll.

# Protect Sisyphus from his own real lightning for the brief bolt lifetime.
data merge entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,limit=1,sort=nearest] {Invulnerable:1b}
schedule function p2:sisy_lightning_cleanup 4t replace

# Two guaranteed REAL bolts. These can damage other entities and ignite terrain.
summon minecraft:lightning_bolt ~ ~ ~ {Tags:["p2_sisy_lightning"]}
summon minecraft:lightning_bolt ~1.35 ~ ~0.55 {Tags:["p2_sisy_lightning"]}

# Optional third and fourth bolts -> total is always 2-4.
execute if predicate adr_boss:rng/50 run summon minecraft:lightning_bolt ~-1.30 ~ ~0.95 {Tags:["p2_sisy_lightning"]}
execute if predicate adr_boss:rng/50 run summon minecraft:lightning_bolt ~0.55 ~ ~-1.40 {Tags:["p2_sisy_lightning"]}

# Gold impact flash.
particle dust 1.000 0.780 0.120 1 ~ ~1 ~ 1.2 1.3 1.2 0.03 45 force

# Guarantee some fire when there is exposed solid ground at/around the impact.
execute if block ~ ~ ~ air unless block ~ ~-1 ~ #adr_boss:pseudo_air run setblock ~ ~ ~ minecraft:fire keep
execute positioned ~1 ~ ~ if block ~ ~ ~ air unless block ~ ~-1 ~ #adr_boss:pseudo_air run setblock ~ ~ ~ minecraft:fire keep
execute positioned ~-1 ~ ~1 if block ~ ~ ~ air unless block ~ ~-1 ~ #adr_boss:pseudo_air run setblock ~ ~ ~ minecraft:fire keep
