function p2:music_stop
function p2:restore_mobs
function p2:title_clear
scoreboard players set #state p2_control 3
weather clear
