stopsound @a master minecraft:boss.panopticon.theme
stopsound @a master minecraft:boss.sisyphus.war_intro
stopsound @a master minecraft:boss.sisyphus.war
scoreboard players set #music_phase p2_control 0
scoreboard players set #music_timer p2_control 0
