execute if score #music_phase p2_control matches 1..3 run scoreboard players remove #music_timer p2_control 1

execute if score #music_phase p2_control matches 1 if score #music_timer p2_control matches ..0 if entity @e[type=minecraft:item_display,tag=adr_model,tag=panopticon,tag=!dead,limit=1] run function p2:music_panopticon_start

execute if score #music_phase p2_control matches 3 if score #music_timer p2_control matches ..0 if entity @e[type=minecraft:item_display,tag=adr_model,tag=sisyphus,tag=!dead,limit=1] run function p2:music_sisyphus_battle

execute unless entity @e[type=minecraft:item_display,tag=adr_model,tag=panopticon,tag=!dead,limit=1] unless entity @e[type=minecraft:item_display,tag=adr_model,tag=sisyphus,tag=!dead,limit=1] unless score #music_phase p2_control matches 0 run function p2:music_stop
