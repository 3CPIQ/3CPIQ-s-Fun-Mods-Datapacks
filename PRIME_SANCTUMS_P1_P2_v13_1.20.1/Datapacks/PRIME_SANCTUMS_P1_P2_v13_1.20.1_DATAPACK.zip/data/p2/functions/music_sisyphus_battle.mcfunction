weather thunder 1000000
stopsound @a master minecraft:boss.sisyphus.war_intro
stopsound @a master minecraft:boss.panopticon.theme
stopsound @a master minecraft:boss.sisyphus.war
execute as @a at @s run playsound minecraft:boss.sisyphus.war master @s ~ ~ ~ 0.65 1 0
scoreboard players set #music_phase p2_control 3
scoreboard players set #music_timer p2_control 6599
