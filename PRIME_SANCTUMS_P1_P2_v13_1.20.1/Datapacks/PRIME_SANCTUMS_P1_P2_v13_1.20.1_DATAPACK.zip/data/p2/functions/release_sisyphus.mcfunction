scoreboard players set #state p2_control 2
stopsound @a master minecraft:boss.panopticon.theme

# Called directly from Panopticon's death/end, so this position IS the prison.
execute positioned ~ ~2.25 ~ run function p2_boss:admin/summon/sisyphus_orb

weather thunder 1000000
