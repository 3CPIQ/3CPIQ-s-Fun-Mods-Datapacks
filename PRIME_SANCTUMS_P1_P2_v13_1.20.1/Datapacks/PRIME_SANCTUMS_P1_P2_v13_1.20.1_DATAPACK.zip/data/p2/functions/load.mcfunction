scoreboard objectives add p2_control dummy
scoreboard players add #state p2_control 0
scoreboard players add #music_phase p2_control 0
scoreboard players add #music_timer p2_control 0

scoreboard objectives add p2_sisy_deaths deathCount
scoreboard objectives add p2_sisy_prev_hp dummy
scoreboard objectives add p2_sisy_damage dummy
scoreboard objectives add p2_sisy_voice_cd dummy

execute unless data storage p2:internal bossbar_created run bossbar add p2:wait_of_world {"text":"Minecraft","color":"dark_red","bold":true}
execute unless data storage p2:internal bossbar_created run data modify storage p2:internal bossbar_created set value 1b
bossbar set p2:wait_of_world max 100
bossbar set p2:wait_of_world value 100
bossbar set p2:wait_of_world color white
bossbar set p2:wait_of_world style progress
bossbar set p2:wait_of_world visible false
