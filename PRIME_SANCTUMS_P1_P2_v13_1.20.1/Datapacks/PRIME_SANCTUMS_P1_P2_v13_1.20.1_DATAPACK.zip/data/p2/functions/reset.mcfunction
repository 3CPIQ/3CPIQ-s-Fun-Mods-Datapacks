stopsound @a voice minecraft:boss.sisyphus.intro
stopsound @a voice minecraft:boss.sisyphus.outro
stopsound @a voice minecraft:boss.sisyphus.thisprison
function p2:music_stop
function p2:restore_mobs
function p2:title_clear
scoreboard players set #state p2_control 0
weather clear

bossbar remove p2:sisyphus
bossbar remove p2:panopticon
kill @e[tag=sisyphus]
kill @e[tag=sisyphus_orb]
kill @e[tag=panopticon]
kill @e[tag=p2_boss_wave]
kill @e[tag=p2_boss_serpent]
kill @e[tag=p2_boss_hellseeker]
kill @e[tag=p2_boss_blackhole]
kill @e[tag=p2_boss_divine_light]
kill @e[tag=p2_boss_beam]
kill @e[tag=p2_purple_wave]
kill @e[tag=p2_white_wave]
kill @e[tag=p2_cyan_wave]
kill @e[tag=p2_boss_eyes]
kill @e[tag=p2_boss_maurice]
execute as @e[type=minecraft:marker,tag=p2_sisy_light] at @s if block ~ ~ ~ minecraft:light run setblock ~ ~ ~ air
kill @e[type=minecraft:marker,tag=p2_sisy_light]
