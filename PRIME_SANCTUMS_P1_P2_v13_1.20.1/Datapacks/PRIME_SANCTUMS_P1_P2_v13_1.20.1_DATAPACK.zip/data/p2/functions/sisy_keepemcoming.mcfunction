execute if entity @e[type=minecraft:iron_golem,tag=adr_hitbox,tag=sisyphus,limit=1] as @a at @s run playsound minecraft:boss.sisyphus.keepthemcoming voice @s ~ ~ ~ 0.88 1 0
