execute as @e[tag=p2_touched,tag=!p2_had_noai] run data merge entity @s {NoAI:0b}
tag @e[tag=p2_touched] remove p2_touched
tag @e[tag=p2_had_noai] remove p2_had_noai
tag @e[tag=p2_candidate] remove p2_candidate
