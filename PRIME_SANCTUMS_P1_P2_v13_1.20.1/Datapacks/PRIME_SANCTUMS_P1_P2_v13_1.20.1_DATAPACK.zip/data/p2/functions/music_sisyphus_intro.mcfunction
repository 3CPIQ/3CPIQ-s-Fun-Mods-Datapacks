stopsound @a master minecraft:boss.panopticon.theme
stopsound @a master minecraft:boss.sisyphus.war
stopsound @a master minecraft:boss.sisyphus.war_intro
execute as @a at @s run playsound minecraft:boss.sisyphus.war_intro master @s ~ ~ ~ 0.45 1 0
scoreboard players set #music_phase p2_control 2
scoreboard players set #music_timer p2_control 808
