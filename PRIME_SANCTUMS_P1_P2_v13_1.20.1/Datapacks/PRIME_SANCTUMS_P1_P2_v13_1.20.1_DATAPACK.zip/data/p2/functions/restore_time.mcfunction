# Restore the exact saved daytime by moving the clock forward smoothly.
execute store result score #now p2_control run time query daytime

# Calculate forward modular distance: diff = saved - now; if negative, add 24000.
scoreboard players operation #diff p2_control = #saved_time p2_control
scoreboard players operation #diff p2_control -= #now p2_control
execute if score #diff p2_control matches ..-1 run scoreboard players add #diff p2_control 24000

# If close enough, set exact saved time and finish.
execute if score #diff p2_control matches 0..20 run function p2:finish_restore
# Otherwise move forward rapidly but visibly/smoothly.
execute if score #diff p2_control matches 21.. run time add 20
