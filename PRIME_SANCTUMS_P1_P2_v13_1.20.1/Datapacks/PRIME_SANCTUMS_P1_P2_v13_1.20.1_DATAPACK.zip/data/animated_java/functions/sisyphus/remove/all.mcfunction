execute as @e[type=minecraft:item_display,tag=aj.sisyphus.root] run function animated_java:sisyphus/zzzzzzzz/remove/as_root
kill @e[tag=aj.sisyphus.rig_entity]
