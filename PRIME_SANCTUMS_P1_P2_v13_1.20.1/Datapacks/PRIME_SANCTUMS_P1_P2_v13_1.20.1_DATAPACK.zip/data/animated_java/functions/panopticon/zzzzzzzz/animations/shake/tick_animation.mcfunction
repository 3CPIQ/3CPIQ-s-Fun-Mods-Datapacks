scoreboard players add @s aj.panopticon.animation.shake.local_anim_time 1
scoreboard players operation @s aj.anim_time = @s aj.panopticon.animation.shake.local_anim_time
function animated_java:panopticon/zzzzzzzz/animations/shake/apply_frame_as_root
execute if score @s aj.panopticon.animation.shake.local_anim_time matches 6.. run function animated_java:panopticon/zzzzzzzz/animations/shake/end
