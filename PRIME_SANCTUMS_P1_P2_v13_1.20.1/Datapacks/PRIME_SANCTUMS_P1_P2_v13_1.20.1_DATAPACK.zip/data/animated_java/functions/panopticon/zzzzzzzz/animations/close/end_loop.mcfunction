scoreboard players set @s aj.panopticon.animation.close.local_anim_time 0
scoreboard players set @s aj.anim_time 0
function animated_java:panopticon/zzzzzzzz/animations/close/tree/leaf_0
