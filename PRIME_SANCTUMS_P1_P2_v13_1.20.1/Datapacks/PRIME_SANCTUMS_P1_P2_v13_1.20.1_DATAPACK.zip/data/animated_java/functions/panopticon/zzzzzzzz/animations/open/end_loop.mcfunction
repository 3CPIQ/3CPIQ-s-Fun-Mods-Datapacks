scoreboard players set @s aj.panopticon.animation.open.local_anim_time 0
scoreboard players set @s aj.anim_time 0
function animated_java:panopticon/zzzzzzzz/animations/open/tree/leaf_0
