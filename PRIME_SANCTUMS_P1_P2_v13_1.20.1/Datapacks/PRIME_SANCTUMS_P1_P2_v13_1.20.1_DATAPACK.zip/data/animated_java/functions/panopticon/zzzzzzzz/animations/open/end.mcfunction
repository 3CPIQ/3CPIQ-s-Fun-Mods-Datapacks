execute if score @s aj.panopticon.animation.open.loop_mode = $aj.loop_mode.loop aj.i run function animated_java:panopticon/zzzzzzzz/animations/open/end_loop
execute if score @s aj.panopticon.animation.open.loop_mode = $aj.loop_mode.once aj.i run function animated_java:panopticon/animations/open/stop
execute if score @s aj.panopticon.animation.open.loop_mode = $aj.loop_mode.hold aj.i run function animated_java:panopticon/animations/open/pause
