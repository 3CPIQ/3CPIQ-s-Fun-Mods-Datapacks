execute on passengers run function animated_java:panopticon/zzzzzzzz/animations/shake/tree/leaf_4_as_bone
