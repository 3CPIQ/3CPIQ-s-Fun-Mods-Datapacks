execute on passengers run function animated_java:panopticon/zzzzzzzz/animations/shake/tree/leaf_1_as_bone
