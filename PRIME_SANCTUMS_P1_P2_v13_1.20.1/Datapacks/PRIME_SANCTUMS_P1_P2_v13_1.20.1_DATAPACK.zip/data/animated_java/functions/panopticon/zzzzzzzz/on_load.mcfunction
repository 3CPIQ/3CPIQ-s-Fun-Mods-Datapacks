scoreboard players set @s aj.panopticon.rig_loaded 1
