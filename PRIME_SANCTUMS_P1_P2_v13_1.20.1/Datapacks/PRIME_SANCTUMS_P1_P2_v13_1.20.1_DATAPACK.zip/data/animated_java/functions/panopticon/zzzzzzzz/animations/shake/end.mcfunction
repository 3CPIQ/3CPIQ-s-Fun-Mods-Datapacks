execute if score @s aj.panopticon.animation.shake.loop_mode = $aj.loop_mode.loop aj.i run function animated_java:panopticon/zzzzzzzz/animations/shake/end_loop
execute if score @s aj.panopticon.animation.shake.loop_mode = $aj.loop_mode.once aj.i run function animated_java:panopticon/animations/shake/stop
execute if score @s aj.panopticon.animation.shake.loop_mode = $aj.loop_mode.hold aj.i run function animated_java:panopticon/animations/shake/pause
