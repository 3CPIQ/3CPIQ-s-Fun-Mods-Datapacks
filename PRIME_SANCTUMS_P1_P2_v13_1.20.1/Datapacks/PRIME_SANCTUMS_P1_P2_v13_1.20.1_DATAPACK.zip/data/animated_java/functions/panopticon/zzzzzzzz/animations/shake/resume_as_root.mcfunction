scoreboard players set @s aj.panopticon.animation.shake.loop_mode 0
execute on passengers run data modify entity @s interpolation_duration set value 1
tag @s add aj.panopticon.animation.shake
