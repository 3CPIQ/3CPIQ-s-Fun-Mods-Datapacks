execute if score @s aj.tween_time matches 1.. run function animated_java:panopticon/zzzzzzzz/animations/close/tick_tween
execute unless score @s aj.tween_time matches 1.. run function animated_java:panopticon/zzzzzzzz/animations/close/tick_animation
