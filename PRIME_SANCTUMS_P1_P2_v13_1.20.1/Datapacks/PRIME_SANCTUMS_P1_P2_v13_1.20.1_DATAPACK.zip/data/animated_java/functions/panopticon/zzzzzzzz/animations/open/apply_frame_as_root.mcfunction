execute if score @s aj.anim_time matches 0..2 run function animated_java:panopticon/zzzzzzzz/animations/open/tree/branch_0_2
