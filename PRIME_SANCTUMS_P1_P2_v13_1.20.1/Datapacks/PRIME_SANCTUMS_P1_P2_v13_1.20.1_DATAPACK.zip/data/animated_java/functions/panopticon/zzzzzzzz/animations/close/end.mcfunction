execute if score @s aj.panopticon.animation.close.loop_mode = $aj.loop_mode.loop aj.i run function animated_java:panopticon/zzzzzzzz/animations/close/end_loop
execute if score @s aj.panopticon.animation.close.loop_mode = $aj.loop_mode.once aj.i run function animated_java:panopticon/animations/close/stop
execute if score @s aj.panopticon.animation.close.loop_mode = $aj.loop_mode.hold aj.i run function animated_java:panopticon/animations/close/pause
