execute if score @s aj.anim_time matches 0..6 run function animated_java:panopticon/zzzzzzzz/animations/shake/tree/branch_0_6
