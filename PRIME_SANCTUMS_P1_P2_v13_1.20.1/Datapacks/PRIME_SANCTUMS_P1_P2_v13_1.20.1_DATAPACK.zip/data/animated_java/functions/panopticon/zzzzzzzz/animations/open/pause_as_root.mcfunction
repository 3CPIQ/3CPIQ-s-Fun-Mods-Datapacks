tag @s remove aj.panopticon.animation.open
