scoreboard players set @s aj.panopticon.animation.open.local_anim_time 0
tag @s remove aj.panopticon.animation.open
execute on passengers run data modify entity @s interpolation_duration set value 0
tag @s add aj.panopticon.disable_command_keyframes
function animated_java:panopticon/zzzzzzzz/animations/open/tree/leaf_0
tag @s remove aj.panopticon.disable_command_keyframes
