execute if entity @s[tag=aj.panopticon.root] run function animated_java:panopticon/zzzzzzzz/tick_as_root
