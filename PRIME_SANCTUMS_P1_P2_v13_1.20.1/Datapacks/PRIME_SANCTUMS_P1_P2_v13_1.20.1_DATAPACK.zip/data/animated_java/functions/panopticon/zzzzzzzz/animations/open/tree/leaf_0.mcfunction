execute on passengers run function animated_java:panopticon/zzzzzzzz/animations/open/tree/leaf_0_as_bone
