execute if score @s aj.anim_time matches 0 run function animated_java:panopticon/zzzzzzzz/animations/close/tree/leaf_0
execute if score @s aj.anim_time matches 1 run function animated_java:panopticon/zzzzzzzz/animations/close/tree/leaf_1
execute if score @s aj.anim_time matches 2 run function animated_java:panopticon/zzzzzzzz/animations/close/tree/leaf_2
