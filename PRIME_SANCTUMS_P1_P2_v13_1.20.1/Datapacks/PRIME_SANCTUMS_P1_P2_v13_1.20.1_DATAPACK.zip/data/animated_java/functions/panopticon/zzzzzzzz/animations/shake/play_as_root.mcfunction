scoreboard players set @s aj.anim_time 0
scoreboard players set @s aj.panopticon.animation.shake.local_anim_time 0
scoreboard players set @s aj.panopticon.animation.shake.loop_mode 0
execute on passengers run data modify entity @s interpolation_duration set value 0
function animated_java:panopticon/zzzzzzzz/animations/shake/tree/leaf_0
execute on passengers run data modify entity @s interpolation_duration set value 1
tag @s add aj.panopticon.animation.shake
