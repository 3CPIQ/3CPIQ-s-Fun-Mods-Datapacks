scoreboard objectives add aj.i dummy
scoreboard objectives add aj.id dummy
scoreboard objectives add aj.tween_time dummy
scoreboard objectives add aj.anim_time dummy
scoreboard objectives add aj.life_time dummy
scoreboard objectives add aj.panopticon.export_version dummy
scoreboard objectives add aj.panopticon.rig_loaded dummy
scoreboard objectives add aj.panopticon.animation.open.local_anim_time dummy
scoreboard objectives add aj.panopticon.animation.close.local_anim_time dummy
scoreboard objectives add aj.panopticon.animation.shake.local_anim_time dummy
scoreboard objectives add aj.panopticon.animation.open.loop_mode dummy
scoreboard objectives add aj.panopticon.animation.close.loop_mode dummy
scoreboard objectives add aj.panopticon.animation.shake.loop_mode dummy
scoreboard players set $aj.panopticon.animation.open aj.id 0
scoreboard players set $aj.panopticon.animation.close aj.id 1
scoreboard players set $aj.panopticon.animation.shake aj.id 2
scoreboard players set $aj.panopticon.variant.default aj.id 0
scoreboard players add .aj.last_id aj.id 0
scoreboard players set $aj.loop_mode.loop aj.i 0
scoreboard players set $aj.loop_mode.once aj.i 1
scoreboard players set $aj.loop_mode.hold aj.i 2
scoreboard players set aj.panopticon.export_version aj.i 956243222
scoreboard players reset * aj.panopticon.rig_loaded
execute as @e[type=minecraft:item_display,tag=aj.panopticon.root] run function animated_java:panopticon/zzzzzzzz/on_load
