execute unless score @s aj.panopticon.rig_loaded = @s aj.panopticon.rig_loaded run function animated_java:panopticon/zzzzzzzz/on_load
scoreboard players add @s aj.life_time 1
execute at @s on passengers run tp @s ~ ~ ~ ~ ~
function animated_java:panopticon/zzzzzzzz/animations/tick
function #animated_java:panopticon/on_tick/as_root
