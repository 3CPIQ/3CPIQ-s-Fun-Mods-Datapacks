execute on passengers run function animated_java:panopticon/zzzzzzzz/apply_variant/default/as_bone
