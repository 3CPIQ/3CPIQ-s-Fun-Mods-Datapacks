tag @s remove aj.panopticon.animation.shake
