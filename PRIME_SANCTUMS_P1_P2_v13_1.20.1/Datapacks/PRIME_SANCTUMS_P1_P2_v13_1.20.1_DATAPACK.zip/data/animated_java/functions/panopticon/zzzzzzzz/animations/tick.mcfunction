execute if entity @s[tag=aj.panopticon.animation.open] run function animated_java:panopticon/zzzzzzzz/animations/open/tick
execute if entity @s[tag=aj.panopticon.animation.close] run function animated_java:panopticon/zzzzzzzz/animations/close/tick
execute if entity @s[tag=aj.panopticon.animation.shake] run function animated_java:panopticon/zzzzzzzz/animations/shake/tick
