tag @s remove aj.panopticon.animation.close
