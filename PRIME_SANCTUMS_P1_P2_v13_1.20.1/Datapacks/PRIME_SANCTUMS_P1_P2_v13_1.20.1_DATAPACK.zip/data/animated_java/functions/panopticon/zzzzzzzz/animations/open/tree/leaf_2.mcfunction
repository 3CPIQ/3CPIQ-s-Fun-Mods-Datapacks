execute on passengers run function animated_java:panopticon/zzzzzzzz/animations/open/tree/leaf_2_as_bone
