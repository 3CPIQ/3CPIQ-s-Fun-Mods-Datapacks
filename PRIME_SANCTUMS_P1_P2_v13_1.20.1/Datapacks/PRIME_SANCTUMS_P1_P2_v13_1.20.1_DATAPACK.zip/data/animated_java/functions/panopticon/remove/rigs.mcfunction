execute as @e[type=minecraft:item_display,tag=aj.panopticon.root] run function animated_java:panopticon/zzzzzzzz/remove/as_root
