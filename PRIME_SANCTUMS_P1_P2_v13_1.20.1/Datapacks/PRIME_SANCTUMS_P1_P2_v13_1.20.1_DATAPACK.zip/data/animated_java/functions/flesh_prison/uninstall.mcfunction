scoreboard objectives remove aj.i
scoreboard objectives remove aj.id
scoreboard objectives remove aj.tween_time
scoreboard objectives remove aj.anim_time
scoreboard objectives remove aj.life_time
scoreboard objectives remove aj.flesh_prison.export_version
scoreboard objectives remove aj.flesh_prison.rig_loaded
scoreboard objectives remove aj.flesh_prison.animation.open.local_anim_time
scoreboard objectives remove aj.flesh_prison.animation.close.local_anim_time
scoreboard objectives remove aj.flesh_prison.animation.shake.local_anim_time
scoreboard objectives remove aj.flesh_prison.animation.open.loop_mode
scoreboard objectives remove aj.flesh_prison.animation.close.loop_mode
scoreboard objectives remove aj.flesh_prison.animation.shake.loop_mode
tellraw @a ["",{"text":"["},{"text":"Animated Java","color":"aqua"},{"text":"] "},[{"text":"INFO ℹ","color":"green"},{"text":" > ","color":"gray"},{"text":"The flesh_prison Rig has been uninstalled successfully.\n"},{"text":"Please remove the Rig's functions from the datapack before reloading.","color":"gray"}]]
