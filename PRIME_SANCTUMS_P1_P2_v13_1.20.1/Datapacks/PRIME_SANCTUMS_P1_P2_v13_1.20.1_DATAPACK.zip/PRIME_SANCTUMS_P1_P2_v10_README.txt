PRIME SANCTUMS P-1 + P-2 v10 — Minecraft 1.20.1

P-1:
  /function p1:start

P-2:
  /function p2:start

V10 — FAKE CRIMSON RAIN (NOT GLOBAL)
====================================
You asked for a fake resource-pack-based crimson rain that only appears
when Sisyphus is active, instead of globally recoloring all rain.

CHANGES
=======
- Removed the global red environment rain texture from v9.
- Added a custom particle texture:
    assets/minecraft/textures/particle/crimson_rain.png
- Overrode:
    assets/minecraft/particles/ash.json
  so the vanilla ash particle now renders as a crimson rain streak.
- Re-added the P-2-only datapack blood-rain controller:
    data/p2/functions/blood_rain.mcfunction
- P-2 tick now runs that function ONLY while:
    #state p2_control = 2
    AND a living Sisyphus model exists

RESULT
======
- Sisyphus phase gets fake crimson "rain"
- It is controlled by the datapack, so it appears only during P-2 Sisyphus
- Normal rain stays normal again
- P-1 Minos storms stay normal
- World rain outside P-2 is not recolored

IMPORTANT NOTE
==============
Because we override the vanilla ASH particle appearance, any place in Minecraft
that naturally uses ash particles will also show crimson streaks. In normal play
that is much rarer than global rain recoloring, and the fake rain itself only
appears when the datapack emits ash during Sisyphus.

All v8 size/spawn fixes and earlier P-1/P-2 boss features remain.
