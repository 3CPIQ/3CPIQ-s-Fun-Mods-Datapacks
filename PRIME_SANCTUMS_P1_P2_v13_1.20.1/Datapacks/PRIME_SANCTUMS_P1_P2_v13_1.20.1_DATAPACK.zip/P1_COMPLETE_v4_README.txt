P1 COMPLETE v4 — Minecraft 1.20.1

CHANGE FROM v3:
- ORDER intro volume reduced from the previous huge 100 value to 0.35.
- The sound is played locally at each player, so it stays audible without using
  an enormous volume/range value.
- Combat ORDER and CHAOS volumes were NOT changed.

Test:
  /reload
  /function p1:test_order_intro

Normal:
  /function p1:start

Keep using the same P1 COMPLETE v2 resource pack.
