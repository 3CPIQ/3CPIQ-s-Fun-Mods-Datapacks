PRIME SANCTUMS P-1 + P-2 v7 — Minecraft 1.20.1

P-1:
  /function p1:start

P-2:
  /function p2:start

V7 — HERESY / BLOOD RAIN
========================
During the live Sisyphus Prime battle:
- the normal P-2 thunderstorm remains active
- a dense red falling-dust layer appears around every player
- a darker red secondary layer adds depth
- a subtle dark-red mist sits nearer to eye level

The effect is intentionally tied ONLY to P-2's live Sisyphus phase:
  #state p2_control = 2
  AND a living Sisyphus visual model exists

Therefore:
- Panopticon does not get blood rain
- P-1 Flesh Prison/Minos do not get blood rain
- ordinary world rain is not globally recolored
- the blood-rain particles stop immediately when Sisyphus dies or P-2 resets

This uses particles rather than replacing Minecraft's global rain texture,
because a resource-pack rain texture would make ALL rain in P-1 and the world red.

All v6 and earlier fixes remain.
