P1 COMPLETE v3 — Minecraft 1.20.1

FIX:
The ORDER intro no longer waits for boss_timer 40.

It now starts INSIDE:
data/adr_boss/functions/bosses/minos/spawn/spawn.mcfunction

That is the exact function executed when the Minos Orb touches the ground,
plays the explosion, and creates/reveals Minos Prime.

Sequence:
1. Flesh Prison dies.
2. Minos Orb falls.
3. Orb touches ground.
4. Explosion sound/particles happen.
5. ORDER intro starts ON THAT SAME TICK.
6. Minos appears and performs the monologue.
7. At the end of the monologue, intro stops.
8. Loopable ORDER battle theme begins.

KEEP USING the P1 COMPLETE v2 resource pack because it already contains:
minecraft:boss.minos.order_intro

Test resource-pack sound manually:
  /function p1:test_order_intro

Normal sequence:
  /reload
  /function p1:start
