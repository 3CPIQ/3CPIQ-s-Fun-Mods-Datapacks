P1 COMPLETE v6 — Minecraft 1.20.1

TITLE UPDATE
============
The Minos Orb reveal title is now permanently:

Minecraft - Soul Survivor

No world-name setup command is required anymore.

The title still appears when the Minos Orb hits the ground and reveals Minos,
and " - Soul Survivor" still types in character-by-character.

Normal start:
  /reload
  /function p1:start

Resource pack:
Keep using P1_COMPLETE_v2_1.20.1_RESOURCEPACK.zip
