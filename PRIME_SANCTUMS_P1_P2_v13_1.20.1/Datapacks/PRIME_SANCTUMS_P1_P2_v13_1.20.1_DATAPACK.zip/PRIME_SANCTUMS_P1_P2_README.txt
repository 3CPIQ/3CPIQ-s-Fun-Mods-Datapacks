PRIME SANCTUMS P-1 + P-2 — Minecraft 1.20.1

THIS COMBINED BUILD SUPPORTS BOTH:
  /function p1:start
  /function p2:start

P-1
====
Uses the existing working setup:
- Flesh Prison
- Minos Prime
- CHAOS / ORDER
- Minecraft - Soul Survivor
- destructive attacks
- spectators
- weather/time effects

P-2
====
/function p2:start

PANOPTICON:
- visible name: Panopticon
- uses the original Flesh Prison texture
- has its OWN P-2 AnimatedJava/model IDs
- main body model is reshaped into a large SQUARE/CUBE shell
- P-1 Flesh Prison model is NOT changed
- battle OST: Pandemonium (~210.4s), loops if needed

SISYPHUS PRIME:
- visible name: Sisyphus Prime
- has its OWN P-2 AnimatedJava/model IDs
- uses the Steve-format Sisyphus skin rig
- full 15-file Sisyphus voice set remains wired in
- reveal music: WAR intro (~40.4s)
- battle music: WAR (~329.9s), loops if needed
- reveal title:
      Minecraft - Wait of the World
  shown at the TOP using the transparent-white cinematic bossbar,
  with typewriter + fade effect

IMPORTANT
=========
This is intentionally a COMBINED replacement pack. Use the included datapack
and resource pack together instead of stacking the old separate P1/Sisyphus
packs. That prevents model-ID and resource-pack priority conflicts.

INSTALL
=======
Datapack:
  saves/<WORLD>/datapacks/PRIME_SANCTUMS_P1_P2_v1_1.20.1_DATAPACK.zip

Resource pack:
  .minecraft/resourcepacks/PRIME_SANCTUMS_P1_P2_v1_1.20.1_RESOURCEPACK.zip

Enable the resource pack, then:
  /reload

Start P-1:
  /function p1:start

Start P-2:
  /function p2:start


V2 CHANGE
=========
- P-1 Minos Prime orb remains BLUE.
- P-2 Sisyphus Prime orb is now a bright YELLOW/GOLD:
  dust RGB = 1.000 0.780 0.120
