PRIME SANCTUMS P-1 + P-2 v13 — Minecraft 1.20.1

P-1:
  /function p1:start

P-2:
  /function p2:start

V13 — SISYPHUS "DESTROY" FIX
=============================
The inherited Minos Judgement/dropkick code had this behavior:

  air below Sisyphus -> CANCEL attack

That is wrong for Sisyphus's aerial "DESTROY!" dropkick because he is
supposed to be airborne immediately before hitting the terrain.

NEW BEHAVIOR
============
When DESTROY reaches its impact frame:

1. Sisyphus scans downward in 0.25-block steps.
2. The search can reach up to 48 blocks below his aerial position.
3. If real terrain is found:
   - Sisyphus snaps to the terrain impact position.
   - DESTROY is committed.
   - damage/explosion occurs there.
   - crater destruction occurs there.
   - phase-2 50% lightning occurs there.
   - the attack does NOT cancel.
4. Only if there is genuinely no terrain within 48 blocks does the old
   fallback cancel into DIE/Overhead remain available.

IMPORTANT
=========
This fix applies only to P-2 Sisyphus Prime.
P-1 Minos's original Judgement behavior is unchanged.

All v12 features remain:
- phase-2 2-4 impact lightning
- real fire/lightning
- Sisyphus self-lightning protection
- blue Minos living aura/light
- gold Sisyphus living aura/light
- normal rain
- all music, monologue, Panopticon, sizing and bossbar fixes
