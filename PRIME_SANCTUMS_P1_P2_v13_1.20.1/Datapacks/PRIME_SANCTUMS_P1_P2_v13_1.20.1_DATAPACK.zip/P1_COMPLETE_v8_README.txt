P1 COMPLETE v8 — Minecraft 1.20.1

CINEMATIC TITLE FIX
===================
The Minos reveal still displays at the TOP:

Minecraft - Soul Survivor

BUT the cinematic bar underneath is now invisible.

How:
- The cinematic p1:soul_survivor bossbar uses WHITE.
- P1 COMPLETE v3 resource pack makes only the WHITE bossbar texture transparent.
- Flesh Prison and Minos use RED bossbars, so their REAL health bars remain visible.

IMPORTANT:
Use BOTH:
- P1_COMPLETE_v8_1.20.1_DATAPACK.zip
- P1_COMPLETE_v3_1.20.1_RESOURCEPACK.zip

Replace the older v7 datapack and v2 resource pack.

Start:
  /reload
  /function p1:start
