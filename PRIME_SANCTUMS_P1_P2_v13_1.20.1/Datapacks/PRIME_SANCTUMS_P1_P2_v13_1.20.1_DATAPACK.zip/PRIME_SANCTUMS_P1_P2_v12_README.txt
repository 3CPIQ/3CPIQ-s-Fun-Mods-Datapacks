PRIME SANCTUMS P-1 + P-2 v12 — Minecraft 1.20.1

P-1:
  /function p1:start

P-2:
  /function p2:start

V12 — SISYPHUS PHASE-2 IMPACT LIGHTNING
========================================
The v11 target/player lightning has been removed.

Now the 50% lightning roll happens at the ACTUAL IMPACT:
- crater center for Crush / DIE
- Judgement blast point
- kick / axe kick impact
- combo jab / chop / final impact
- uppercut / overhead impact
- serpent projectile impact

On a successful 50% roll:
- 2 lightning bolts are guaranteed
- the 3rd has a 50% chance
- the 4th has a 50% chance
- therefore each successful lightning event produces 2-4 bolts
- bolts are REAL lightning, not visual_only
- they can ignite terrain
- exposed ground around the impact also receives guaranteed fire attempts

SISYPHUS SELF-PROTECTION
========================
Before his lightning appears, Sisyphus's living iron-golem hitbox becomes
temporarily invulnerable.

After 4 ticks:
- the custom lightning entities are removed
- Sisyphus becomes vulnerable again

This prevents his own lightning cluster from damaging him while still allowing
the lightning to damage/ignite everything else around the impact.

V12 — PRIME SOUL LIGHT / AURA
=============================
While the bosses are ALIVE:
- Minos Prime has a blue particle aura and a moving invisible light level 13
- Sisyphus Prime has a gold particle aura and a moving invisible light level 14
- the light follows them during spawn AND battle

When their living hitbox disappears for death:
- colored battle aura stops
- the moving light is removed
- the tracker marker is killed

Old static spawn/death light logic was removed so the light no longer continues
through their death sequences.

Rain remains completely vanilla.
All prior P-1/P-2 boss/music/model/voice/monologue fixes remain.
