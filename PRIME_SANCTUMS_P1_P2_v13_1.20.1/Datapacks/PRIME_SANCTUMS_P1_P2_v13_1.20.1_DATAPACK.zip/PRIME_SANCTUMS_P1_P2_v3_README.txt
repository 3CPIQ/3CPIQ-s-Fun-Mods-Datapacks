PRIME SANCTUMS P-1 + P-2 v3 — Minecraft 1.20.1

P-1:
  /function p1:start

P-2:
  /function p2:start

V3 FIXES
========
- Sisyphus orb transition now executes at the dead Panopticon.
- Orb spawns 2.25 blocks above Panopticon, then drops normally.
- Duplicate Panopticon death orb removed.
- Sisyphus no longer updates Minos's bossbar.
- P-2 bossbars are isolated as p2:panopticon and p2:sisyphus.
- P-2 start/reset cleans stale bossbars and P-2 entities.
- Sisyphus cyan/blue supernatural attack telegraphs recolored gold/yellow.
- Light-blue glass effects changed to yellow glass.
- Soul-fire visual effects changed to warm flame.
- Panopticon model is now literally an obsidian cube.
- P-1 Flesh Prison and Minos remain unchanged.
- NICE TRY removed from uppercut/overhead spam.
- YOU CAN'T ESCAPE / BE GONE / DESTROY / THIS WILL HURT are guaranteed
  on their main attack equivalents, with alternate takes in phase 2.
- NICE TRY variants moved to the less-frequent serpent attack.
- Sisyphus chat monologue is split and timed against the actual silence/onset
  timing measured from Sp_thisprison.ogg and Sp_intro.ogg.
