P1 COMPLETE v2 — Minecraft 1.20.1

NEW IN v2
=========
1. MINOS CRATERS ARE MUCH BIGGER
   DIE / CRUSH:
     difficulty 1 -> radius 6, depth 4
     difficulty 2 -> radius 8, depth 5
     difficulty 3 -> radius 10, depth 6

   JUDGEMENT:
     difficulty 1 -> radius 4 blast
     difficulty 2 -> radius 6 blast
     difficulty 3 -> radius 8 blast

   Several smaller Minos melee attacks were upgraded too.
   Blocks are still set to AIR, so there are NO ITEM DROPS.
   Obsidian/bedrock/barriers/technical containment blocks remain protected.

2. SPECTATORS DO NOT FLEE UNDERGROUND
   Flee movement is now forcibly horizontal (pitch = 0).
   They only step backward when the destination is open AND has a solid floor.
   They still update where they look every tick.

3. ORDER INTRO PLAYS UNDER MINOS' MONOLOGUE
   At boss_timer 40, alongside Minos' speech, boss.minos.order_intro begins.
   The supplied clip is ~46.2 seconds, matching the monologue almost perfectly.
   At the end of the monologue the intro is stopped and loopable ORDER begins.

TEST COMMAND:
   /function p1:test_order_intro

NORMAL START:
   /reload
   /function p1:start

IMPORTANT:
Replace P1 COMPLETE v1 with v2. Do not keep both enabled.
Terrain destruction is permanent: keep a world backup.
