P1 COMPLETE FIXED — Minecraft 1.20.1

THIS ZIP REPLACES:
- the original Adrenaline Bosses datapack
- every old P1 Storm Controller v1-v7 zip
- the previous destructive patch zip

Use ONLY this datapack for those features.

Start:
  /reload
  /function p1:start

Diagnostics:
  /function p1:status
  /function p1:test_chaos
  /function p1:test_order
  /function p1:debug_spectators
  /function p1:test_crater

FIXES:
- P1 tick is merged into Adrenaline's own minecraft:tick function tag.
- Music detects live Flesh Prison / Minos entities automatically.
- Spectators detect bosses automatically every tick, independent of controller state.
- New mobs entering 32 blocks of player or boss are acquired immediately.
- Mobs leaving the radius get their AI back immediately.
- Wardens, players, Flesh Prison, Minos, ADR models and hitboxes are never frozen.
- Minos/Flesh Prison attacks now call destruction directly from their REAL hit/slam functions.
- Destruction uses setblock air, so destroyed blocks produce NO DROPS.
- Bedrock, obsidian, barriers and technical blocks are protected.

IMPORTANT: terrain destruction is permanent. Back up the world.
