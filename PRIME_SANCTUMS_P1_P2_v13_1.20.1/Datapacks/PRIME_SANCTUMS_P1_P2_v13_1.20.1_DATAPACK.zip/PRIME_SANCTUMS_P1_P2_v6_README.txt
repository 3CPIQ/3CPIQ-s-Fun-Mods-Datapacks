PRIME SANCTUMS P-1 + P-2 v6 — Minecraft 1.20.1

P-1:
  /function p1:start

P-2:
  /function p2:start

V6 — SISYPHUS SIZE
==================
Sisyphus Prime is now visually approximately 2× the scale of the original
Minos-sized rig.

This was NOT done by merely making the skin cubes bigger.

The complete P-2 Sisyphus AnimatedJava rig was scaled:
- every animated bone's visual basis = 2×
- every animated bone's translation from the rig root = 2×
- therefore arms, legs, head and torso remain correctly separated throughout
  the existing animations

EXTRA BULK
==========
On top of the 2× overall rig scale:
- torso is significantly broader/deeper
- pelvis is broader
- upper arms are thicker
- forearms are thicker
- legs are slightly thicker
- head is only slightly wider/deeper so it stays proportionate

P-1 MINOS
=========
Minos Prime is completely unchanged.
Only the separate P-2 Sisyphus AnimatedJava rig and Sisyphus resource models
were modified.

NOTE
====
This changes Sisyphus's VISUAL model. The underlying 1.20.1 iron-golem AI
hitbox remains the same boss-mechanics hitbox so the existing Adrenaline
attacks/pathfinding are not broken.

All v5 intro/death/voice/music/Panopticon fixes remain.
