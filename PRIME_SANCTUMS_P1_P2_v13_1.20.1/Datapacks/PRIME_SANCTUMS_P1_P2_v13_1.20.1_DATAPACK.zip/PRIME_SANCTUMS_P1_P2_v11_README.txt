PRIME SANCTUMS P-1 + P-2 v11 — Minecraft 1.20.1

P-1:
  /function p1:start

P-2:
  /function p2:start

V11 — NORMAL RAIN RESTORED
==========================
All custom/fake crimson-rain logic has been removed.

Removed:
- p2:blood_rain function
- Sisyphus blood-rain tick hook
- custom ash particle override
- crimson_rain.png
- any custom/global rain.png override

Result:
- Minecraft rain is completely vanilla again.
- Vanilla ash particle is completely vanilla again.
- P-1 and P-2 weather use normal Minecraft rain/thunder visuals.

V11 — SISYPHUS PHASE-2 LIGHTNING
================================
When Sisyphus enters phase 2 ("YES! THAT'S IT!"):
- Every attack activation makes one independent 50% roll.
- On success, a lightning bolt strikes at his current attack target.
- If no target is tagged, it strikes roughly 2 blocks in front of Sisyphus.
- The lightning is visual-only so it does not add random vanilla lightning
  damage/fire on top of the boss's own attack damage.
- A small gold flash accompanies the bolt to match Sisyphus's gold effects.

The lightning is NOT active:
- during Sisyphus phase 1
- during Panopticon
- during Minos / P-1

All previous size, spawn, bossbar, music, monologue, Panopticon and voice fixes remain.
