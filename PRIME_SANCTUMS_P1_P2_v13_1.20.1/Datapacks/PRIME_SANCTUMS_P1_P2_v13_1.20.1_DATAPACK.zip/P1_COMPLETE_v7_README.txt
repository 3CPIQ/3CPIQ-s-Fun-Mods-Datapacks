P1 COMPLETE v7 — Minecraft 1.20.1

TITLE UPDATE
============
The Minos reveal text is now shown at the TOP of the screen using a bossbar,
instead of a centered Minecraft title.

It types:
Minecraft - Soul Survivor

The sequence is still triggered on the exact Minos Orb impact/reveal tick.

Normal start:
  /reload
  /function p1:start

Resource pack:
Keep using P1_COMPLETE_v2_1.20.1_RESOURCEPACK.zip
