P1 COMPLETE v5 — Minecraft 1.20.1

CHANGES
=======
- Removed the P1 controller/status chat messages during the fight.
- Added a cinematic title when the Minos Orb impacts and reveals Minos.
- Title format:
    <YOUR WORLD NAME> - Soul Survivor
- The suffix types in character-by-character.
- The title uses compact styling and a short hold so it stays readable.
- ORDER intro still starts on the exact Minos Orb impact tick.

IMPORTANT VANILLA LIMITATION
============================
Minecraft 1.20.1 datapacks cannot automatically read the save-folder/world name.
Set it once per world with:

/data modify storage p1:config world_name set value "YOUR ACTUAL WORLD NAME"

Example:
/data modify storage p1:config world_name set value "LandsCraft"

After that, every Minos reveal automatically uses:
LandsCraft - Soul Survivor

Normal start:
/reload
/function p1:start

Resource pack:
Keep using P1_COMPLETE_v2_1.20.1_RESOURCEPACK.zip
