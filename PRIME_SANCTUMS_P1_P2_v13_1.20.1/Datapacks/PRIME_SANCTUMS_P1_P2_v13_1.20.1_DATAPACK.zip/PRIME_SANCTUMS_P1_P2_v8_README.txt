PRIME SANCTUMS P-1 + P-2 v8 — Minecraft 1.20.1

P-1:
  /function p1:start

P-2:
  /function p2:start

V8 — SISYPHUS RESIZE / GROUND FIX
=================================
- Sisyphus reduced from 2.0x to approximately 1.5x Minos's visual scale.
- His thicker/more muscular proportions from v6/v7 are retained.
- The complete Sisyphus AnimatedJava rig was rescaled, including all
  animation frames, not merely the static model.
- A +0.71875 block visual Y correction is applied to every Sisyphus
  bone transform so the larger model scales upward from the floor instead
  of extending underground.
- The initial spawn pose is also lifted, preventing the underground flash
  before AnimatedJava begins the monologue animation.
- Minos remains unchanged.
- Sisyphus's combat hitbox remains unchanged to preserve boss AI/attacks.
- Heresy-style blood rain from v7 remains enabled during Sisyphus.

All previous P-1/P-2 music, voice, monologue, Panopticon and bossbar fixes remain.
