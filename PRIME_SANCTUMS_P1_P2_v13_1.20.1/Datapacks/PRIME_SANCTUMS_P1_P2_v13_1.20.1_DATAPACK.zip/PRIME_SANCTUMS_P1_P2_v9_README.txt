PRIME SANCTUMS P-1 + P-2 v9 — Minecraft 1.20.1

P-1:
  /function p1:start

P-2:
  /function p2:start

V9 — REAL RED RAIN TEXTURE
==========================
You asked for the actual rain to be red via resource pack, not extra particles.

Changes:
- Added:
    assets/minecraft/textures/environment/rain.png
  as a crimson / blood-red rain texture.
- Removed the v7-v8 particle-based blood-rain overlay from the datapack
  so the effect does not stack with the red rain texture.

IMPORTANT LIMITATION
====================
Minecraft rain textures in a resource pack are GLOBAL.

That means:
- ALL rain in Minecraft is now red
- P-1 rain is red
- P-2 rain is red
- normal overworld rain is red

The datapack can still control WHEN it rains/thunders, but the resource-pack
rain texture itself cannot be switched only for Sisyphus without changing packs.

All v8 Sisyphus size/spawn fixes remain.
All previous P-1/P-2 voice/music/Panopticon/monologue fixes remain.
